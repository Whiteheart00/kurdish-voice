#!/usr/bin/env python3
"""سکریپتی ژێرنووس (txt یان vtt) پاک دەکاتەوە و دەیکات بە پاکێجی یاری بۆ ئەپەکە.
بەکارهێنان:  python3 make_pack.py input.txt output.txt
"""
import re, sys, collections

src, dst = sys.argv[1], sys.argv[2]
raw = open(src, encoding="utf-8").read().splitlines()
lines = []
for l in raw:
    l = l.strip()
    if not l or l == "WEBVTT" or "-->" in l or re.fullmatch(r"\d+", l):
        continue
    l = re.sub(r"\[[^\]]*\]", " ", l)      # [music] [gasps] ...
    l = l.replace(">>", " ")
    l = re.sub(r"\s+", " ", l).strip()
    if not l or re.fullmatch(r"(Heat\.?\s*)+", l):  # هەڵەی ناسراوی کاپشنی یوتیوب بۆ مۆسیقا
        continue
    lines.append(l)

# لێکدانەوەی هێڵە پچڕاوەکان بۆ ڕستە، لابردنی دووبارەی ڕێز
text = " ".join(lines)
sents = re.split(r"(?<=[.!?])\s+", text)
out, prev = [], None
for s in sents:
    s = s.strip()
    if len(s) < 2 or s == prev:
        continue
    out.append(s); prev = s

# ناوە گوماناوییەکان (وشەی گەورە لە ناوەڕاستی ڕستە)
names = collections.Counter()
for s in out:
    for w in re.findall(r"(?<!^)(?<![.!?] )\b[A-Z][a-z]{2,}\b", s):
        names[w] += 1

with open(dst, "w", encoding="utf-8") as f:
    f.write("\n".join(out))
print(f"ڕستە: {len(out)} | وشە: {sum(len(s.split()) for s in out)} | پیت: {sum(len(s) for s in out)}")
print("ناوە باوەکان:", ", ".join(f"{w}({c})" for w, c in names.most_common(25)))

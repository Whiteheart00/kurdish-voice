plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.hardi.kurdishtranslator"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.hardi.kurdishtranslator"
        minSdk = 29
        targetSdk = 34
        // every GitHub Actions run has a higher number, so a new APK always installs over the old one
        versionCode = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 1
        versionName = "1.0." + (System.getenv("GITHUB_RUN_NUMBER") ?: "0")
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    // a fixed signing key (committed in the repo), so every build is signed the same way and updates install over the old app
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    // دەنگی کوردیی ئۆفلاین (Piper/VITS ONNX)
    implementation("com.microsoft.onnxruntime:onnxruntime-android:1.19.2")
    // گوێگرتنی ئینگلیزیی ئۆفلاین (Vosk)
    implementation("net.java.dev.jna:jna:5.13.0@aar")
    implementation("com.alphacephei:vosk-android:0.3.47")
}

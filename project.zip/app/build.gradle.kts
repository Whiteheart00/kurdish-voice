plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.mangatranslator.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.mangatranslator.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 10
        versionName = "0.9.0"

        // تەنها مۆبایلی ٦٤ بیت: APK بچووکتر دەبێت
        ndk {
            abiFilters += listOf("arm64-v8a")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    // مۆدێلە ONNX ـەکان لە APK دا فشار نادرێن (خێراتر)
    androidResources {
        noCompress += listOf("onnx")
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")

    // Piper TTS (ONNX) بە sherpa-onnx: فایلی sherpa-onnx-<وەشان>.aar لە app/libs دابنێ (بڕوانە README)
    implementation(fileTree(mapOf("dir" to "libs", "include" to listOf("*.aar"))))

    // OCR ئۆفلاین بۆ پیتی لاتین (ئینگلیزی)
    implementation("com.google.mlkit:text-recognition:16.0.0")
}

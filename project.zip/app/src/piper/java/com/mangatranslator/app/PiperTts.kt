package com.mangatranslator.app

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Log
import com.k2fsa.sherpa.onnx.OfflineTts
import com.k2fsa.sherpa.onnx.OfflineTtsConfig
import com.k2fsa.sherpa.onnx.OfflineTtsModelConfig
import com.k2fsa.sherpa.onnx.OfflineTtsVitsModelConfig
import java.io.File

/**
 * خوێندنەوەی ئۆفلاینی نیورالی (Piper / VITS بە ONNX، لە ڕێگەی sherpa-onnx).
 * مۆدێلی کوردیی Piper بوونی نییە، بۆیە مۆدێلی فارسی (fa_IR-amir-medium) بەکاردێت و
 * دەقی سۆرانی بە KurdishVoiceText.toPersian دەکرێت بە فارسی بۆ ئەوەی نزیکترین دەنگی بۆ بێت.
 *
 * شوێنی مۆدێل: app/src/main/assets/piper/ (یان filesDir/piper/) کە تێیدا دەبێت:
 *   *.onnx ، tokens.txt ، espeak-ng-data/
 * (بڕوانە README.md)
 */
class PiperTts(private val ctx: Context) {

    @Volatile private var tts: OfflineTts? = null
    @Volatile private var track: AudioTrack? = null
    @Volatile private var cancelled = false

    @Volatile var speaking = false
        private set

    /** پەیام دەگەڕێنێتەوە ئەگەر مۆدێل نەدۆزرایەوە یان بار نەبوو. */
    private fun ensureLoaded(): String? {
        if (tts != null) return null
        val dir = File(ctx.filesDir, "piper")
        if (!hasModel(dir)) {
            try { copyAssetDir("piper", dir) } catch (e: Exception) { Log.w(TAG, "copy assets: $e") }
        }
        if (!hasModel(dir)) {
            return "مۆدێلی Piper نەدۆزرایەوە. فۆڵدەری piper (فایلی .onnx و tokens.txt و espeak-ng-data) " +
                "لە app/src/main/assets/piper دابنێ و ئەپەکە دووبارە بنیات بنێ (بڕوانە README)"
        }
        val onnx = dir.listFiles { f -> f.extension == "onnx" }?.firstOrNull()
            ?: return "فایلی .onnx لە فۆڵدەری piper نییە"
        return try {
            val vits = OfflineTtsVitsModelConfig(
                model = onnx.absolutePath,
                tokens = File(dir, "tokens.txt").absolutePath,
                dataDir = File(dir, "espeak-ng-data").absolutePath
            )
            val cfg = OfflineTtsConfig(
                model = OfflineTtsModelConfig(vits = vits, numThreads = 2, debug = false, provider = "cpu"),
                maxNumSentences = 1
            )
            tts = OfflineTts(config = cfg)
            null
        } catch (e: Throwable) {
            Log.e(TAG, "load failed", e)
            "بارکردنی مۆدێلی Piper سەرنەکەوت: ${e.message}"
        }
    }

    private fun hasModel(dir: File) =
        dir.isDirectory && File(dir, "tokens.txt").exists() &&
            File(dir, "espeak-ng-data").isDirectory &&
            (dir.listFiles { f -> f.extension == "onnx" }?.isNotEmpty() == true)

    private fun copyAssetDir(assetPath: String, dest: File) {
        val list = ctx.assets.list(assetPath) ?: return
        if (list.isEmpty()) {
            dest.parentFile?.mkdirs()
            ctx.assets.open(assetPath).use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
        } else {
            dest.mkdirs()
            for (name in list) copyAssetDir("$assetPath/$name", File(dest, name))
        }
    }

    /** بە ڕیز دەخوێنێتەوە؛ لەسەر thread ی کار بانگ بکرێت. null = سەرکەوتوو. */
    fun speakBlocking(texts: List<String>, speed: Float, isCurrent: () -> Boolean): String? {
        ensureLoaded()?.let { return it }
        val engine = tts ?: return "Piper ئامادە نییە"
        cancelled = false
        speaking = true
        try {
            for (t in texts) {
                for (sentence in splitSentences(KurdishVoiceText.convert(t, KurdishVoiceText.FA))) {
                    if (cancelled || !isCurrent()) return null
                    Log.d(TAG, "fa: $sentence")
                    val audio = try {
                        engine.generate(sentence, 0, speed)
                    } catch (e: Throwable) {
                        return "Piper: ${e.message}"
                    }
                    if (audio.samples.isEmpty()) continue
                    play(audio.samples, audio.sampleRate, isCurrent)
                }
            }
        } finally {
            speaking = false
        }
        return null
    }

    private fun splitSentences(s: String): List<String> =
        s.split(Regex("(?<=[.!?؟،؛:\\n])\\s*")).map { it.trim() }.filter { it.length >= 2 }

    private fun play(samples: FloatArray, rate: Int, isCurrent: () -> Boolean) {
        val pcm = ShortArray(samples.size) { i ->
            (samples[i].coerceIn(-1f, 1f) * 32767f).toInt().toShort()
        }
        val minBuf = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val at = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(rate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .build()
            )
            .setBufferSizeInBytes(maxOf(minBuf, pcm.size * 2))
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        track = at
        try {
            at.write(pcm, 0, pcm.size)
            at.play()
            val totalMs = pcm.size * 1000L / rate
            val start = System.currentTimeMillis()
            while (!cancelled && isCurrent() && System.currentTimeMillis() - start < totalMs + 150) {
                Thread.sleep(40)
            }
        } finally {
            try { at.stop() } catch (_: Exception) {}
            at.release()
            if (track === at) track = null
        }
    }

    fun stop() {
        cancelled = true
        speaking = false
        try { track?.pause(); track?.flush() } catch (_: Exception) {}
    }

    fun shutdown() {
        stop()
        try { tts?.release() } catch (_: Throwable) {}
        tts = null
    }

    companion object { private const val TAG = "PiperTts" }
}

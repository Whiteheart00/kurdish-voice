package com.mangatranslator.app

import android.content.Context

/**
 * جێگرەوە کاتێک app/libs/*.aar ی sherpa-onnx نییە: بیناکردن سەرکەوتوو دەبێت و Piper تەنها پەیامێک پیشان دەدات.
 * کاتێک AAR لە app/libs دانرا، بە خۆکار PiperTts ی ڕاستەقینە (src/piper) بەکاردێت.
 */
class PiperTts(@Suppress("UNUSED_PARAMETER") ctx: Context) {
    @Volatile var speaking = false
        private set

    fun speakBlocking(texts: List<String>, speed: Float, isCurrent: () -> Boolean): String? =
        "Piper دانەمەزراوە: فایلی sherpa-onnx .aar لە app/libs دابنێ و مۆدێلەکە لە assets/piper (بڕوانە README)، " +
            "یان دەنگێکی تر لە ڕێکخستنی دەنگ هەڵبژێرە"

    fun stop() {}
    fun shutdown() {}
}

package com.mangatranslator.app

/**
 * کوردیی سۆرانی (پیتی عەرەبی) ← پیتی لاتینی، بە شێوەیەک کە دەنگی تورکی (tr-TR) بە ئۆفلاین
 * نزیکترین دەنگ بۆ کوردی بخوێنێتەوە. تەنها بۆ خوێندنەوەیە، نەک نووسینی ڕەسمیی کوردی.
 *
 * ڕێساکان:
 *  - پیتی نەبوو لە تورکی دەگۆڕدرێت بۆ نزیکترینی: خ→h  غ→g  ق→k  ع→(هیچ)  ڤ→v  ڕ→r  ڵ→l
 *  - «و» ئەگەر پیتی دەنگدار لە دوای بێت = v، ئەگەر نا u؛  «وو» = u
 *  - «ی» لە سەرەتا یان پێش پیتی دەنگدار = y، ئەگەر نا i
 *  - سۆرانی دەنگی کورتی «i» نانووسێت (برا = bra): لە سەرەتای وشە و لە کۆمەڵە پیتی بێدەنگی ٣+ دا i زیاد دەکرێت
 */
object KurdishLatin {

    private val vowelLetters = setOf('ا', 'ە', 'ێ', 'ۆ', 'ی', 'و', 'ە', 'ؤ', 'ێ')

    private val consonants = mapOf(
        'ب' to "b", 'پ' to "p", 'ت' to "t", 'ج' to "c", 'چ' to "ç",
        'ح' to "h", 'خ' to "h", 'د' to "d", 'ر' to "r", 'ڕ' to "r",
        'ز' to "z", 'ژ' to "j", 'س' to "s", 'ش' to "ş", 'غ' to "g",
        'ف' to "f", 'ڤ' to "v", 'ق' to "k", 'ک' to "k", 'گ' to "g",
        'ل' to "l", 'ڵ' to "l", 'م' to "m", 'ن' to "n", 'ه' to "h",
        'ھ' to "h", 'ث' to "s", 'ذ' to "z", 'ص' to "s", 'ض' to "z",
        'ط' to "t", 'ظ' to "z", 'ك' to "k", 'ڪ' to "k", 'ع' to ""
    )

    private val digits = mapOf(
        '٠' to '0', '١' to '1', '٢' to '2', '٣' to '3', '٤' to '4',
        '٥' to '5', '٦' to '6', '٧' to '7', '٨' to '8', '٩' to '9',
        '۰' to '0', '۱' to '1', '۲' to '2', '۳' to '3', '۴' to '4',
        '۵' to '5', '۶' to '6', '۷' to '7', '۸' to '8', '۹' to '9'
    )

    private val punct = mapOf('،' to ",", '؟' to "?", '؛' to ";", '۔' to ".", '«' to "\"", '»' to "\"")

    private fun isArabicLetter(c: Char) = c in '\u0600'..'\u06FF' || c in '\u0750'..'\u077F'
    private fun isVowelLatin(c: Char) = c in "aeiouıöüâêîû"

    fun toLatin(text: String): String {
        val sb = StringBuilder()
        var i = 0
        val n = text.length
        while (i < n) {
            if (!isArabicLetter(text[i]) || text[i] in punct || text[i] in digits) {
                val c = text[i]
                sb.append(digits[c] ?: punct[c] ?: c)
                i++
                continue
            }
            var j = i
            while (j < n && isArabicLetter(text[j]) && text[j] !in punct && text[j] !in digits) j++
            sb.append(convertWord(text.substring(i, j)))
            i = j
        }
        return sb.toString().replace(Regex("\\s+"), " ").trim()
    }

    private fun convertWord(raw: String): String {
        // نیشانەکانی ڕێزمان (تەشدید، فەتحە...) و ئەلف لەگەڵ هەمزە لادەبرێن
        val w = raw.filter { it !in '\u064B'..'\u065F' && it != 'ـ' && it != '\u200c' && it != '\u200d' }
        val out = StringBuilder()
        var i = 0
        while (i < w.length) {
            val c = w[i]
            val next = w.getOrNull(i + 1)
            when {
                c == 'و' && next == 'و' -> { out.append('u'); i += 2; continue }
                c == 'و' -> {
                    val nextIsVowel = next != null && next in vowelLetters
                    val prev = w.getOrNull(i - 1)
                    val afterVowel = prev != null && prev in setOf('ا', 'ە', 'ێ', 'ۆ')
                    // سڵاو = slav ، ئاو = av ، دەوڵەت = devlet
                    out.append(if (nextIsVowel || afterVowel) 'v' else 'u')
                }
                c == 'ی' -> {
                    val nextIsVowel = next != null && next in vowelLetters && next != 'ی'
                    out.append(if (i == 0 || nextIsVowel) 'y' else 'i')
                }
                c == 'ێ' -> out.append('e')
                c == 'ە' -> out.append('e')
                c == 'ۆ' -> out.append('o')
                c == 'ا' -> out.append('a')
                c == 'ئ' || c == 'ء' -> { /* هەمزە: بێدەنگ */ }
                c == 'ؤ' -> out.append('o')
                else -> out.append(consonants[c] ?: "")
            }
            i++
        }
        return fixClusters(out.toString())
    }

    /** دەنگی کورتی «i» کە سۆرانی ناینووسێت دەخاتە ناو کۆمەڵە پیتی بێدەنگەکان. */
    private fun fixClusters(s: String): String {
        if (s.length < 2) return s
        val o = StringBuilder()
        var run = 0
        for ((idx, ch) in s.withIndex()) {
            if (!isVowelLatin(ch)) {
                run++
                // کۆمەڵەی دوو پیت لە سەرەتای وشە (bra → bira) و سێ پیت لە ناوەڕاست
                if ((run == 2 && idx == 1) || run == 3) {
                    o.append('i')
                    run = 1
                }
            } else run = 0
            o.append(ch)
        }
        return o.toString()
    }
}

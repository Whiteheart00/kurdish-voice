package com.mangatranslator.app

/**
 * دەقی سۆرانی ← دەقێک کە دەنگی ئۆفلاینی ناو مۆبایل (ئینگلیزی / عەرەبی / تورکی) بە نزیکترین
 * دەنگ بۆ کوردی بیخوێنێتەوە. تەنها بۆ خوێندنەوەیە.
 *
 * mode: 0 = ئینگلیزی (لاتینیی کوردی بە نووسینی ئینگلیزی: sh, ch, kh, oo, ee)
 *       1 = عەرەبی (پیتی کوردیی نەبووی عەرەبی دەگۆڕدرێت: پ→ب، چ→تش ...)
 *       2 = تورکی (شێوازی کۆن، KurdishLatin)
 *       3 = فارسی (نزیکترین پیتی عەرەبی بە کوردی: ڕ→ر، ڵ→ل، ێ→ی، ڤ→و ...)
 */
object KurdishVoiceText {

    const val EN = 0
    const val AR = 1
    const val TR = 2
    const val FA = 3

    fun convert(text: String, mode: Int): String = when (mode) {
        AR -> toArabic(text)
        FA -> toPersian(text)
        TR -> KurdishLatin.toLatin(text)
        else -> toEnglish(text)
    }

    // ───────────────────────── ئینگلیزی ─────────────────────────

    private val vowelLetters = setOf('ا', 'ە', 'ێ', 'ۆ', 'ی', 'و', 'ؤ')

    private val enCons = mapOf(
        'ب' to "b", 'پ' to "p", 'ت' to "t", 'ج' to "j", 'چ' to "ch",
        'ح' to "h", 'خ' to "kh", 'د' to "d", 'ر' to "r", 'ڕ' to "r",
        'ز' to "z", 'ژ' to "zh", 'س' to "s", 'ش' to "sh", 'غ' to "gh",
        'ف' to "f", 'ڤ' to "v", 'ق' to "k", 'ک' to "k", 'گ' to "g",
        'ل' to "l", 'ڵ' to "l", 'م' to "m", 'ن' to "n", 'ه' to "h",
        'ھ' to "h", 'ث' to "s", 'ذ' to "z", 'ص' to "s", 'ض' to "z",
        'ط' to "t", 'ظ' to "z", 'ك' to "k", 'ڪ' to "k", 'ع' to ""
    )

    private val digits = mapOf(
        '٠' to '0', '١' to '1', '٢' to '2', '٣' to '3', '٤' to '4',
        '٥' to '5', '٦' to '6', '٧' to '7', '٨' to '8', '٩' to '9',
        '۰' to '0', '۱' to '1', '۲' to '2', '۳' to '3', '۴' to '4',
        '۵' to '5', '۶' to '6', '۷' to '7', '۸' to '8', '۹' to '9'
    )

    private val punct = mapOf('،' to ",", '؟' to "?", '؛' to ";", '۔' to ".", '«' to "\"", '»' to "\"")

    private fun isArabicLetter(c: Char) = c in '\u0600'..'\u06FF' || c in '\u0750'..'\u077F'

    fun toEnglish(text: String): String {
        val sb = StringBuilder()
        var i = 0
        val n = text.length
        while (i < n) {
            val c = text[i]
            if (!isArabicLetter(c) || c in punct || c in digits) {
                sb.append(digits[c] ?: punct[c] ?: c)
                i++
                continue
            }
            var j = i
            while (j < n && isArabicLetter(text[j]) && text[j] !in punct && text[j] !in digits) j++
            sb.append(englishWord(text.substring(i, j)))
            i = j
        }
        return sb.toString().replace(Regex("\\s+"), " ").trim()
    }

    private class Tok(val s: String, val vowel: Boolean)

    private fun englishWord(raw: String): String {
        val w = raw.filter { it !in '\u064B'..'\u065F' && it != 'ـ' && it != '\u200c' && it != '\u200d' }
        val toks = ArrayList<Tok>()
        var i = 0
        while (i < w.length) {
            val c = w[i]
            val next = w.getOrNull(i + 1)
            val prev = w.getOrNull(i - 1)
            val last = i == w.length - 1
            when {
                c == 'و' && next == 'و' -> { toks.add(Tok("oo", true)); i += 2; continue }
                c == 'و' -> {
                    val nextIsVowel = next != null && next in vowelLetters
                    val afterVowel = prev != null && prev in setOf('ا', 'ە', 'ێ', 'ۆ')
                    if (nextIsVowel || afterVowel) toks.add(Tok("w", false)) else toks.add(Tok("oo", true))
                }
                c == 'ی' -> {
                    val nextIsVowel = next != null && next in vowelLetters && next != 'ی'
                    if (i == 0 || nextIsVowel) toks.add(Tok("y", false)) else toks.add(Tok("ee", true))
                }
                c == 'ێ' -> toks.add(Tok("ay", true))
                c == 'ە' -> toks.add(Tok(if (last && i > 0) "eh" else "e", true))
                c == 'ۆ' || c == 'ؤ' -> toks.add(Tok("oh", true))
                c == 'ا' -> toks.add(Tok("ah", true))
                c == 'ئ' || c == 'ء' -> { }
                else -> {
                    val s = enCons[c]
                    if (!s.isNullOrEmpty()) toks.add(Tok(s, false))
                }
            }
            i++
        }
        // دەنگی کورتی «i» کە سۆرانی ناینووسێت: bra → bira ، سێ بێدەنگ لە ڕیز → i لە ناوەڕاست
        val o = StringBuilder()
        var run = 0
        for ((idx, t) in toks.withIndex()) {
            if (!t.vowel) {
                run++
                if ((run == 2 && idx == 1) || run == 3) {
                    o.append('i')
                    run = 1
                }
            } else run = 0
            o.append(t.s)
        }
        return o.toString()
    }

    // ───────────────────────── عەرەبی ─────────────────────────

    private val arMap = mapOf(
        'پ' to "ب", 'چ' to "تش", 'ژ' to "ج", 'گ' to "غ", 'ڤ' to "ف",
        'ڕ' to "ر", 'ڵ' to "ل", 'ک' to "ك", 'ێ' to "ي", 'ی' to "ي",
        'ۆ' to "و", 'ؤ' to "و", 'ھ' to "ه", 'ڪ' to "ك", 'ئ' to "", 'ء' to ""
    )

    fun toArabic(text: String): String {
        val sb = StringBuilder()
        var i = 0
        val n = text.length
        while (i < n) {
            val c = text[i]
            if (!isArabicLetter(c) || c in punct || c in digits) {
                sb.append(digits[c] ?: c)
                i++
                continue
            }
            var j = i
            while (j < n && isArabicLetter(text[j]) && text[j] !in punct && text[j] !in digits) j++
            sb.append(arabicWord(text.substring(i, j)))
            i = j
        }
        return sb.toString().replace(Regex("\\s+"), " ").trim()
    }

    private fun arabicWord(raw: String): String {
        val w = raw.filter { it !in '\u064B'..'\u065F' && it != 'ـ' && it != '\u200c' && it != '\u200d' }
        val o = StringBuilder()
        for ((i, c) in w.withIndex()) {
            when {
                c == 'ە' -> o.append(
                    when {
                        i == 0 -> "أَ"
                        i == w.length - 1 -> "ة"
                        else -> "َ"
                    }
                )
                else -> o.append(arMap[c] ?: c.toString())
            }
        }
        return o.toString()
    }
}

// ───────────────────────── فارسی ─────────────────────────

private val faMap = mapOf(
    'ڕ' to "ر", 'ڵ' to "ل", 'ێ' to "ی", 'ۆ' to "و", 'ؤ' to "و", 'ڤ' to "و",
    'ك' to "ک", 'ڪ' to "ک", 'ي' to "ی", 'ھ' to "ه", 'ة' to "ه", 'ئ' to "", 'ء' to ""
)

fun KurdishVoiceText.toPersian(text: String): String {
    val sb = StringBuilder()
    var i = 0
    val n = text.length
    while (i < n) {
        val c = text[i]
        val isLetter = c in '\u0600'..'\u06FF' || c in '\u0750'..'\u077F'
        val isPunctOrDigit = c in "،؟؛۔«»" || c in '\u0660'..'\u0669' || c in '\u06F0'..'\u06F9'
        if (!isLetter || isPunctOrDigit) {
            sb.append(c)
            i++
            continue
        }
        var j = i
        while (j < n) {
            val d = text[j]
            val l = d in '\u0600'..'\u06FF' || d in '\u0750'..'\u077F'
            val po = d in "،؟؛۔«»" || d in '\u0660'..'\u0669' || d in '\u06F0'..'\u06F9'
            if (!l || po) break
            j++
        }
        sb.append(persianWord(text.substring(i, j)))
        i = j
    }
    return sb.toString().replace(Regex("\\s+"), " ").trim()
}

private fun persianWord(raw: String): String {
    val w = raw.filter { it !in '\u064B'..'\u065F' && it != 'ـ' && it != '\u200c' && it != '\u200d' }
    val o = StringBuilder()
    for ((i, c) in w.withIndex()) {
        if (c == 'ە') {
            o.append(
                when {
                    i == 0 -> "اَ"
                    i == w.length - 1 -> "ه"
                    else -> "َ"
                }
            )
        } else o.append(faMap[c] ?: c.toString())
    }
    return o.toString()
}

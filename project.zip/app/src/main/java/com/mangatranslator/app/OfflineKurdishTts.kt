package com.mangatranslator.app

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * خوێندنەوەی کوردی بێ ئینتەرنێت: دەقی سۆرانی دەکرێت بە پیتی لاتینی (KurdishLatin) و بە دەنگی
 * ئۆفلاینی تورکیی ناو مۆبایلەکە (Android TextToSpeech) دەخوێندرێتەوە، چونکە دەنگی تورکی
 * نزیکترین دەنگە لە دەنگی کوردی (لاتینی).
 * پێویستی: دەنگی تورکی لەسەر مۆبایلەکە دابەزێنرابێت
 * (Settings ← Text-to-speech ← Google ← Install voice data ← Turkish).
 */
class OfflineKurdishTts(private val ctx: Context) {

    private var engine: TextToSpeech? = null
    @Volatile private var ready = false
    @Volatile private var failMsg: String? = null
    private val initLatch = CountDownLatch(1)
    @Volatile private var done: CountDownLatch? = null

    @Volatile var speaking = false
        private set

    init {
        engine = TextToSpeech(ctx.applicationContext) { status ->
            if (status != TextToSpeech.SUCCESS) {
                failMsg = "ئامێری TextToSpeech ی مۆبایلەکە کارا نەبوو"
            } else {
                failMsg = pickOfflineVoice()
                ready = failMsg == null
            }
            initLatch.countDown()
        }
        engine?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { done?.countDown() }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { done?.countDown() }
        })
    }

    /** دەنگێکی تورکیی ئۆفلاین هەڵدەبژێرێت؛ ئەگەر نەبوو، پەیامی هەڵە دەگەڕێنێتەوە. */
    private fun pickOfflineVoice(): String? {
        val tts = engine ?: return "TTS نییە"
        val voices = try { tts.voices.orEmpty() } catch (_: Exception) { emptySet() }
        val offlineTr = voices
            .filter { it.locale.language == "tr" && !it.isNetworkConnectionRequired }
            .sortedBy { it.quality * -1 }
        val v = offlineTr.firstOrNull()
        if (v != null) {
            tts.voice = v
            return null
        }
        val r = tts.setLanguage(Locale("tr", "TR"))
        return if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            "دەنگی تورکیی ئۆفلاین نییە. لە Settings ← Text-to-speech ← Google ← Install voice data ← Turkish دایبەزێنە"
        } else null
    }

    /** بە ڕیز دەخوێنێتەوە؛ لەسەر thread ی کار (نەک main) بانگ بکرێت. true = سەرکەوتوو. */
    fun speakBlocking(texts: List<String>, isCurrent: () -> Boolean): String? {
        if (!initLatch.await(8, TimeUnit.SECONDS)) return "TTS ی ئۆفلاین ئامادە نەبوو"
        failMsg?.let { return it }
        val tts = engine ?: return "TTS نییە"
        speaking = true
        try {
            tts.setSpeechRate(0.9f)
            for ((i, t) in texts.withIndex()) {
                if (!isCurrent()) break
                val latin = KurdishLatin.toLatin(t)
                if (latin.isBlank()) continue
                Log.d(TAG, "latin: $latin")
                val latch = CountDownLatch(1)
                done = latch
                val params = Bundle()
                val r = tts.speak(latin, TextToSpeech.QUEUE_FLUSH, params, "ku$i")
                if (r != TextToSpeech.SUCCESS) return "TTS سەرنەکەوت"
                while (isCurrent() && !latch.await(100, TimeUnit.MILLISECONDS)) { /* چاوەڕێ */ }
            }
        } finally {
            speaking = false
        }
        return null
    }

    fun stop() {
        speaking = false
        done?.countDown()
        try { engine?.stop() } catch (_: Exception) {}
    }

    fun shutdown() {
        stop()
        try { engine?.shutdown() } catch (_: Exception) {}
        engine = null
    }

    companion object { private const val TAG = "OfflineKurdishTts" }
}

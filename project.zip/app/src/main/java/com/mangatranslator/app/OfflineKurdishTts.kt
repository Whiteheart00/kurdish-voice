package com.mangatranslator.app

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * خوێندنەوەی کوردی بێ ئینتەرنێت: دەقی سۆرانی دەگۆڕدرێت (KurdishVoiceText) و بە دەنگی ئۆفلاینی
 * ناو مۆبایلەکە (Android TextToSpeech) دەخوێندرێتەوە. دەنگەکە دەکرێت ئینگلیزی، عەرەبی، تورکی یان فارسی بێت.
 * پێویستی: دەنگەکە لەسەر مۆبایلەکە دابەزێنرابێت (Settings ← Text-to-speech ← Google ← Install voice data).
 */
class OfflineKurdishTts(private val ctx: Context) {

    private var engine: TextToSpeech? = null
    @Volatile private var ready = false
    @Volatile private var failMsg: String? = null
    private val initLatch = CountDownLatch(1)
    @Volatile private var done: CountDownLatch? = null

    @Volatile var speaking = false
        private set

    init {
        engine = TextToSpeech(ctx.applicationContext) { status ->
            if (status != TextToSpeech.SUCCESS) {
                failMsg = "ئامێری TextToSpeech ی مۆبایلەکە کارا نەبوو"
            } else {
                ready = true
            }
            initLatch.countDown()
        }
        engine?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { done?.countDown() }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { done?.countDown() }
        })
    }

    @Volatile private var voiceMode = -1

    /** دەنگێکی ئۆفلاین بۆ دۆخەکە (ئینگلیزی/عەرەبی/تورکی) هەڵدەبژێرێت؛ ئەگەر نەبوو، پەیامی هەڵە دەگەڕێنێتەوە. */
    private fun pickOfflineVoice(mode: Int): String? {
        val tts = engine ?: return "TTS نییە"
        val lang = when (mode) { KurdishVoiceText.AR -> "ar"; KurdishVoiceText.TR -> "tr"; KurdishVoiceText.FA -> "fa"; else -> "en" }
        val name = when (mode) { KurdishVoiceText.AR -> "عەرەبی"; KurdishVoiceText.TR -> "تورکی"; KurdishVoiceText.FA -> "فارسی"; else -> "ئینگلیزی" }
        val voices = try { tts.voices.orEmpty() } catch (_: Exception) { emptySet() }
        val best = voices
            .filter {
                it.locale.language == lang && !it.isNetworkConnectionRequired &&
                    !it.features.contains("notInstalled")
            }
            .sortedWith(
                compareByDescending<android.speech.tts.Voice> { if (lang == "en" && it.locale.country == "US") 1 else 0 }
                    .thenByDescending { it.quality }
            )
            .firstOrNull()
        if (best != null) {
            tts.voice = best
            return null
        }
        val r = tts.setLanguage(Locale(lang))
        return if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            "دەنگی $name ی ئۆفلاین نییە. لە Settings ← Text-to-speech ← Google ← Install voice data دایبەزێنە"
        } else null
    }

    /** بە ڕیز دەخوێنێتەوە؛ لەسەر thread ی کار (نەک main) بانگ بکرێت. true = سەرکەوتوو. */
    fun speakBlocking(texts: List<String>, mode: Int, isCurrent: () -> Boolean): String? {
        if (!initLatch.await(8, TimeUnit.SECONDS)) return "TTS ی ئۆفلاین ئامادە نەبوو"
        failMsg?.let { return it }
        val tts = engine ?: return "TTS نییە"
        if (voiceMode != mode) {
            pickOfflineVoice(mode)?.let { return it }
            voiceMode = mode
        }
        speaking = true
        try {
            tts.setSpeechRate(0.9f)
            for ((i, t) in texts.withIndex()) {
                if (!isCurrent()) break
                val latin = KurdishVoiceText.convert(t, mode)
                if (latin.isBlank()) continue
                Log.d(TAG, "latin: $latin")
                val latch = CountDownLatch(1)
                done = latch
                val params = Bundle()
                val r = tts.speak(latin, TextToSpeech.QUEUE_FLUSH, params, "ku$i")
                if (r != TextToSpeech.SUCCESS) return "TTS سەرنەکەوت"
                while (isCurrent() && !latch.await(100, TimeUnit.MILLISECONDS)) { /* چاوەڕێ */ }
            }
        } finally {
            speaking = false
        }
        return null
    }

    fun stop() {
        speaking = false
        done?.countDown()
        try { engine?.stop() } catch (_: Exception) {}
    }

    fun shutdown() {
        stop()
        try { engine?.shutdown() } catch (_: Exception) {}
        engine = null
    }

    companion object { private const val TAG = "OfflineKurdishTts" }
}

package com.hardi.kurdishtranslator

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Handler
import android.os.IBinder
import android.os.Looper

/**
 * داگرتنی خۆکاریی مۆدێلەکان (دەنگی کوردی + گوێگرتنی ئینگلیزی) لە پاشبنەمادا.
 * - بەستراوە بە شاشەی ئامادەکردنەوە نییە: «تێپەڕاندن» دابگریت یان ئەپەکە دابخەیت، داگرتن بەردەوام دەبێت.
 * - ئەگەر ئینتەرنێت پچڕا، خۆی دووبارە هەوڵ دەداتەوە و لەو شوێنەوە بەردەوام دەبێت کە وەستابوو.
 * - هەر جارێک ئەپەکە دەکرێتەوە و مۆدێلێک کەم بوو، خۆی دەست پێدەکاتەوە.
 */
class SetupService : Service() {
    companion object {
        private const val CH = "setup"
        private const val ID = 77

        @Volatile var running = false
        @Volatile var gaveUp = false           // هەڵەی هەمیشەیی (لینکی هەڵە)؛ تا دەستی نەکرێتەوە دووبارە نابێتەوە
        @Volatile var kuPct = 0
        @Volatile var stPct = 0
        @Volatile var kuMsg = ""
        @Volatile var stMsg = ""
        @Volatile var listener: (() -> Unit)? = null
        private val main = Handler(Looper.getMainLooper())

        fun missing(ctx: Context) = !KuVoice.isInstalled(ctx.filesDir) || !Stt.isInstalled(ctx)

        /** Call from a foreground activity. Does nothing if everything is installed or a run is already going. */
        fun start(ctx: Context) {
            if (running || !missing(ctx)) return
            running = true
            try {
                ctx.startForegroundService(Intent(ctx, SetupService::class.java))
            } catch (_: Throwable) {
                running = false
            }
        }

        private fun ping() { main.post { listener?.invoke() } }
    }

    @Volatile private var stop = false
    private var worker: Thread? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        running = true
        try {
            startForeground(ID, note("ئامادەکردنی مۆدێلە ئۆفلاینەکان...", -1), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } catch (_: Throwable) {
            running = false
            stopSelf()
            return START_NOT_STICKY
        }
        if (worker?.isAlive != true) {
            gaveUp = false
            worker = Thread({ work() }, "setup").also { it.start() }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        stop = true
        running = false
        ping()
        super.onDestroy()
    }

    private fun work() {
        val app = applicationContext
        val fd = app.filesDir
        val sp = app.getSharedPreferences("p", MODE_PRIVATE)
        var kuDead = false
        var stDead = false
        var attempts = 0
        var wait = 5_000L
        try {
            while (!stop) {
                val needKu = !KuVoice.isInstalled(fd) && !kuDead
                val needSt = !Stt.isInstalled(app) && !stDead
                if (!needKu && !needSt) break
                var failed = false

                if (needKu) {
                    if (!KuVoice.isInstalled(fd)) KuVoice.installBundled(app)
                    if (!KuVoice.isInstalled(fd)) {
                        val def = MainActivity.DEFAULT_VOICE_URL
                        val url = (sp.getString("kuurl", def) ?: def).ifBlank { def }
                        kuMsg = "⬇️ داگرتن..."; ping()
                        val e = KuVoice.download(app, url) { p -> kuPct = p; kuMsg = "⬇️ $p%"; update(); ping() }
                        if (e == null) { KuVoice.warmUp(fd) } else {
                            failed = true
                            kuMsg = "⚠️ $e"
                            if (Downloader.permanent) kuDead = true
                        }
                    }
                    if (KuVoice.isInstalled(fd)) { kuPct = 100; kuMsg = "✅ ئامادەیە" }
                    ping()
                }

                if (needSt && !stop) {
                    stMsg = "⬇️ داگرتن..."; ping()
                    val e = Stt.download(app) { p -> stPct = p; stMsg = "⬇️ $p%"; update(); ping() }
                    if (e != null && !Stt.isInstalled(app)) {
                        failed = true
                        stMsg = "⚠️ $e"
                        if (Downloader.permanent) stDead = true
                    }
                    if (Stt.isInstalled(app)) { stPct = 100; stMsg = "✅ ئامادەیە" }
                    ping()
                }

                if (!failed) { attempts = 0; wait = 5_000L; continue }
                if ((kuDead || KuVoice.isInstalled(fd)) && (stDead || Stt.isInstalled(app))) break
                if (++attempts >= 40) break

                // ئینتەرنێت نییە یان سێرڤەر ڕاگیراوە: چاوەڕێ بکە و لەو شوێنەوە بەردەوام بە کە وەستابوو
                var left = wait
                while (left > 0 && !stop) { Thread.sleep(500); left -= 500 }
                wait = minOf(wait * 2, 60_000L)
            }
        } catch (_: InterruptedException) {
        } catch (t: Throwable) {
            kuMsg = "⚠️ " + (t.message ?: t.toString()).take(100)
        }
        gaveUp = missing(app)
        running = false
        ping()
        finish(app)
    }

    private fun finish(app: Context) {
        val nm = getSystemService(NotificationManager::class.java)
        stopForeground(STOP_FOREGROUND_REMOVE)
        if (!missing(app)) {
            nm.cancel(ID)
        } else {
            nm.notify(ID, note("⚠️ داگرتنی مۆدێلەکان تەواو نەبوو — ئەپەکە بکەرەوە بۆ دووبارەهەوڵدان", -1, ongoing = false))
        }
        stopSelf()
    }

    private fun update() {
        val ku = KuVoice.isInstalled(filesDir)
        val st = Stt.isInstalled(applicationContext)
        val txt = when {
            !ku && !st -> "🔊 دەنگی کوردی $kuPct%  •  👂 گوێگرتن $stPct%"
            !ku -> "🔊 دەنگی کوردی $kuPct%"
            else -> "👂 گوێگرتنی ئینگلیزی $stPct%"
        }
        val pct = if (!ku) kuPct else stPct
        getSystemService(NotificationManager::class.java).notify(ID, note(txt, pct))
    }

    private fun note(text: String, pct: Int, ongoing: Boolean = true): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Model download", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 3, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val b = Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("وەرگێڕی دەنگی کوردی")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(ongoing)
            .setOnlyAlertOnce(true)
        if (pct >= 0 && ongoing) b.setProgress(100, pct, false) else if (ongoing) b.setProgress(0, 0, true)
        return b.build()
    }
}

package com.hardi.kurdishtranslator

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager

/**
 * Silences the phone's ORIGINAL sound while the translator is running, so only the Kurdish voice is heard.
 *
 * How it works:
 *  - the original game/video sound is on the MEDIA volume (STREAM_MUSIC) -> it is set to 0 while translating
 *    (the playback-capture still receives the sound, so the English can be recognised);
 *  - the Kurdish voice is played on the ALARM volume (STREAM_ALARM) instead, which is a separate volume,
 *    so it stays audible. The alarm volume is set to the same level the media volume had.
 *  - the old volumes are saved on disk, and put back when the translator stops (or when the app is opened
 *    again after a crash), so the phone never stays silent.
 */
object OrigMute {
    private const val PF = "ovol"

    private fun am(c: Context) = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    /** True while the original sound is muted by us. */
    fun isActive(c: Context): Boolean = c.getSharedPreferences(PF, Context.MODE_PRIVATE).getInt("m", -1) >= 0

    fun apply(c: Context) {
        try {
            val a = am(c)
            val sp = c.getSharedPreferences(PF, Context.MODE_PRIVATE)
            if (sp.getInt("m", -1) < 0) {
                // remember the real volumes only once (never overwrite them with the muted 0)
                sp.edit()
                    .putInt("m", a.getStreamVolume(AudioManager.STREAM_MUSIC))
                    .putInt("a", a.getStreamVolume(AudioManager.STREAM_ALARM))
                    .commit()
            }
            val m = sp.getInt("m", 0)
            val mMax = a.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
            val aMax = a.getStreamMaxVolume(AudioManager.STREAM_ALARM).coerceAtLeast(1)
            // Kurdish voice loudness = the media loudness the user had (at least 60% so it is never too quiet)
            val ratio = maxOf(m.toFloat() / mMax, 0.6f)
            a.setStreamVolume(AudioManager.STREAM_ALARM, Math.round(ratio * aMax).coerceIn(1, aMax), 0)
            a.setStreamVolume(AudioManager.STREAM_MUSIC, 0, 0)
            // the user's chosen volume is used, except "media" (it is muted now), which becomes the alarm volume
            Bus.outUsage = if (Bus.outPref == 0) AudioAttributes.USAGE_ALARM else Bus.usageFor(Bus.outPref)
        } catch (e: Throwable) {
            Bus.outUsage = Bus.usageFor(Bus.outPref)
        }
    }

    fun restore(c: Context) {
        Bus.outUsage = Bus.usageFor(Bus.outPref)
        try {
            val sp = c.getSharedPreferences(PF, Context.MODE_PRIVATE)
            val m = sp.getInt("m", -1)
            val al = sp.getInt("a", -1)
            val a = am(c)
            if (m >= 0) a.setStreamVolume(AudioManager.STREAM_MUSIC, m, 0)
            if (al >= 0) a.setStreamVolume(AudioManager.STREAM_ALARM, al, 0)
            sp.edit().clear().commit()
        } catch (e: Throwable) {
        }
    }
}

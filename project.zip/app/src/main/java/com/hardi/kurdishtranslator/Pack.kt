package com.hardi.kurdishtranslator

import java.io.File

/** Pre-translated game lines (pack.tsv: english<TAB>kurdish) and fuzzy matching. */
object Pack {
    class L(val en: String, val ku: String, val toks: Set<String>)

    /** A match: [count] consecutive lines starting at [start]; [score] is a Dice score (+ small order bonus). */
    class M(val start: Int, val count: Int, val score: Double, val items: List<L>)

    @Volatile var lines: List<L> = emptyList()

    /** Index of the last matched line: the story moves forward, so nearby following lines are preferred. */
    @Volatile var last = -1

    private val nonWord = Regex("[^a-z0-9 ]")
    private val spaces = Regex("\\s+")

    // apostrophes are dropped (don't -> dont) so that "dont"/"don't" from captions vs. speech recognition agree
    fun norm(s: String): List<String> =
        s.lowercase().replace("'", "").replace("’", "").replace(nonWord, " ").split(spaces).filter { it.isNotEmpty() }

    fun load(dir: File) {
        last = -1
        val f = File(dir, "pack.tsv")
        if (!f.exists()) {
            lines = emptyList()
            return
        }
        lines = f.readLines().mapNotNull {
            val i = it.indexOf('\t')
            if (i <= 0) null else {
                val en = it.substring(0, i)
                L(en, it.substring(i + 1), norm(en).toSet())
            }
        }
    }

    /** Equal, or (for words of 5+ letters) at most one edit apart: tolerates small recognition errors. */
    private fun near(a: String, b: String): Boolean {
        if (a == b) return true
        if (a.length < 5 || b.length < 5) return false
        val d = a.length - b.length
        if (d > 1 || d < -1) return false
        var i = 0
        var j = 0
        var edits = 0
        while (i < a.length && j < b.length) {
            if (a[i] == b[j]) {
                i++
                j++
            } else {
                edits++
                if (edits > 1) return false
                if (a.length > b.length) i++
                else if (a.length < b.length) j++
                else {
                    i++
                    j++
                }
            }
        }
        edits += (a.length - i) + (b.length - j)
        return edits <= 1
    }

    private fun overlap(qt: Set<String>, s: Set<String>): Int {
        var o = 0
        for (t in qt) {
            if (t in s) {
                o++
                continue
            }
            if (t.length >= 5) {
                for (x in s) {
                    if (near(t, x)) {
                        o++
                        break
                    }
                }
            }
        }
        return o
    }

    /**
     * Best matching run of 1..3 consecutive script lines for the heard English [q].
     * Lines shortly after the previously matched one get a small bonus (story order).
     */
    fun match(q: String): M? {
        val qt = norm(q).toSet()
        val ls = lines
        if (qt.isEmpty() || ls.isEmpty()) return null
        val from = last
        var best: M? = null
        var bs = 0.0
        for (i in ls.indices) {
            if (ls[i].toks.isEmpty()) continue
            var s: Set<String> = ls[i].toks
            var span = 1
            while (true) {
                val o = overlap(qt, s)
                var d = 2.0 * o / (qt.size + s.size)
                if (i > from && i <= from + 30) d += 0.05
                if (d > bs) {
                    bs = d
                    best = M(i, span, d, ls.subList(i, i + span))
                }
                if (span >= 3 || i + span >= ls.size) break
                if (o == 0 || o * 4 < qt.size) break
                s = s + ls[i + span].toks
                span++
            }
        }
        return best
    }
}

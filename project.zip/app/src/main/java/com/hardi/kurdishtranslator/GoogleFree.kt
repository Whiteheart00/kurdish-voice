package com.hardi.kurdishtranslator

import android.util.Log
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * Fast English -> Sorani via Google Translate (no key).
 * Connection-pooled OkHttp, short timeouts, big in-memory cache.
 */
object GoogleFree {
    private const val TAG = "GoogleFree"

    private val http = OkHttpClient.Builder()
        .connectTimeout(2, TimeUnit.SECONDS)
        .readTimeout(4, TimeUnit.SECONDS)
        .writeTimeout(4, TimeUnit.SECONDS)
        .callTimeout(5, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private val cache = object : LinkedHashMap<String, String>(512, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?) = size > 1200
    }

    fun enToKu(text: String): String {
        val t = text.trim()
        if (t.isEmpty()) return ""
        synchronized(cache) { cache[t] }?.let { return it }
        val out = try {
            gtx(t)
        } catch (e: Exception) {
            Log.w(TAG, "gtx: ${e.message}")
            try {
                dictChrome(t)
            } catch (e2: Exception) {
                throw IOException("وەرگێڕان: " + (e2.message ?: e.message))
            }
        }
        if (out.isBlank()) throw IOException("وەرگێڕان بەتاڵە")
        synchronized(cache) { cache[t] = out }
        return out
    }

    private val batchPool = java.util.concurrent.Executors.newFixedThreadPool(6)

    /** Many lines at once: cache hits + parallel HTTP (wall time ≈ one request). */
    fun enToKuBatch(lines: List<String>): List<String> {
        if (lines.isEmpty()) return emptyList()
        if (lines.size == 1) return listOf(enToKu(lines[0]))
        val result = arrayOfNulls<String>(lines.size)
        val need = ArrayList<Int>()
        for (i in lines.indices) {
            val t = lines[i].trim()
            val hit = synchronized(cache) { cache[t] }
            if (hit != null) result[i] = hit else need.add(i)
        }
        if (need.isNotEmpty()) {
            val futs = need.map { i ->
                batchPool.submit<Pair<Int, String>> {
                    i to enToKu(lines[i])
                }
            }
            for (f in futs) {
                val (i, ku) = f.get()
                result[i] = ku
            }
        }
        return result.map { it ?: "" }
    }

    private fun gtx(text: String): String {
        val q = URLEncoder.encode(text, "UTF-8")
        val res = get("https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=ckb&dt=t&q=$q")
        val parts = JSONArray(res).getJSONArray(0)
        val sb = StringBuilder(parts.length() * 16)
        for (i in 0 until parts.length()) {
            val seg = parts.optJSONArray(i) ?: continue
            if (!seg.isNull(0)) sb.append(seg.getString(0))
        }
        return sb.toString().trim()
    }

    private fun dictChrome(text: String): String {
        val q = URLEncoder.encode(text, "UTF-8")
        val res = get("https://clients5.google.com/translate_a/t?client=dict-chrome-ex&sl=en&tl=ckb&q=$q").trim()
        return if (res.startsWith("{")) {
            val ss = JSONObject(res).getJSONArray("sentences")
            val sb = StringBuilder()
            for (i in 0 until ss.length()) sb.append(ss.getJSONObject(i).optString("trans", ""))
            sb.toString().trim()
        } else {
            val first = JSONArray(res).opt(0)
            when (first) {
                is String -> first
                is JSONArray -> first.optString(0, "")
                else -> ""
            }.trim()
        }
    }

    private fun get(url: String): String {
        val req = Request.Builder()
            .url(url)
            .header("User-Agent", "Mozilla/5.0")
            .get()
            .build()
        http.newCall(req).execute().use { r ->
            val body = r.body?.string() ?: ""
            if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
            return body
        }
    }
}

package com.hardi.kurdishtranslator

import java.util.concurrent.CompletableFuture
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.Semaphore
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * Hybrid offline + online English -> Sorani translation.
 *
 *  1. DRAFT   : the local NLLB model translates each sentence at once (no network), so the text/voice never waits.
 *  2. REFINE  : drafts are collected; on a natural pause (or when a few have piled up) the online engine translates
 *               the whole chunk in ONE request, with the earlier lines as context, and the text of those sentences
 *               is replaced IN PLACE (same entry, same position, so nothing jumps around).
 *  3. FALLBACK: when the offline model is missing, sentences go online. If the network is slow (moving average above
 *               Bus.slowMs) or requests are piling up, queued sentences are grouped into one request, so the queue
 *               always clears instead of growing.
 */
object Hybrid {
    const val DRAFT_MARK = "⚡"      // offline draft
    const val FINAL_MARK = "✨"      // refined by the online engine

    private const val PAUSE_MS = 900L        // no new sentence for this long = a natural pause -> refine the chunk now
    private const val REFINE_AT = 4          // this many drafts waiting -> refine without waiting for the pause
    private const val MAX_BATCH = 6          // most sentences in one online request
    private const val CTX_LINES = 3          // earlier English lines sent along as context

    class Result(val ku: String, val draft: Boolean)

    // ---------------------------------------------------------------- latency monitor
    @Volatile private var avgMs = 0.0
    private val inflight = AtomicInteger(0)

    private fun note(ms: Long, ok: Boolean) {
        // failures and time-outs count as "very slow", so the next sentences are grouped
        val v = if (ok) ms.toDouble() else maxOf(ms.toDouble(), 3000.0)
        avgMs = if (avgMs == 0.0) v else avgMs * 0.7 + v * 0.3
    }

    /** True when the online engine is slow right now (moving average above the threshold, or requests piling up). */
    fun slow(): Boolean = avgMs > Bus.slowMs || inflight.get() >= 2

    // ---------------------------------------------------------------- context
    private val recent = ArrayList<String>()
    private fun context(): List<String> = synchronized(recent) { ArrayList(recent) }
    private fun remember(en: String) = synchronized(recent) {
        recent.add(en)
        while (recent.size > CTX_LINES) recent.removeAt(0)
    }

    private fun onlineTimed(lines: List<String>): List<String> {
        val t0 = System.currentTimeMillis()
        inflight.incrementAndGet()
        try {
            val r = Gem.translateOnline(lines, context())
            note(System.currentTimeMillis() - t0, true)
            return r
        } catch (e: Throwable) {
            note(System.currentTimeMillis() - t0, false)
            throw e
        } finally {
            inflight.decrementAndGet()
        }
    }

    // ---------------------------------------------------------------- online-only queue (adaptive batching)
    private class Req(val en: String) { val f = CompletableFuture<String>() }

    private val q = LinkedBlockingQueue<Req>()
    private val pool = Executors.newFixedThreadPool(3)
    private val gate = Semaphore(1)          // slow network: one request at a time, so the rest queue up and go as one block

    private fun drain() {
        val slow = slow()
        if (slow) gate.acquireUninterruptibly()
        try {
            val first = q.poll() ?: return
            val batch = ArrayList<Req>()
            batch.add(first)
            // slow (or just got slow while waiting for the gate): take everything that has piled up
            if (slow || slow()) q.drainTo(batch, MAX_BATCH - 1)
            try {
                val out = onlineTimed(batch.map { it.en })
                for ((i, r) in batch.withIndex()) {
                    val t = out.getOrNull(i)
                    if (t.isNullOrBlank()) r.f.completeExceptionally(RuntimeException("وەرگێڕان بەتاڵ بوو")) else r.f.complete(t)
                }
            } catch (e: Throwable) {
                for (r in batch) r.f.completeExceptionally(e)
            }
        } finally {
            if (slow) gate.release()
        }
    }

    private fun onlineQueued(en: String): String {
        val r = Req(en)
        q.add(r)
        pool.execute { drain() }
        try {
            return r.f.get(25, TimeUnit.SECONDS)
        } catch (e: java.util.concurrent.ExecutionException) {
            throw (e.cause as? Exception) ?: RuntimeException(e.cause?.message ?: "هەڵە")
        }
    }

    // ---------------------------------------------------------------- main entry
    /**
     * The fast text of one sentence. Blocks only for the offline model (instant) or, without it, the online queue.
     * A ready Kurdish line (Callouts) is exact and needs no refinement.
     */
    fun fast(en: String): Result {
        Callouts.find(en)?.let { remember(en); return Result(it, false) }
        if (!Bus.hybrid) {
            val ku = Gem.translate(listOf(en))[0]
            remember(en)
            return Result(ku, false)
        }
        val d = Gem.translateOffline(en)
        if (d != null) {
            val res = Result(d, true)
            remember(en)
            return res
        }
        val ku = onlineQueued(en)
        remember(en)
        return Result(ku, false)
    }

    // ---------------------------------------------------------------- background refinement of offline drafts
    private class Item(val en: String, val entry: Bus.Entry, val draft: String)

    private val pending = ArrayList<Item>()
    private val timer = Executors.newSingleThreadScheduledExecutor()
    private var timerTask: ScheduledFuture<*>? = null
    private val refinePool = Executors.newSingleThreadExecutor()   // one at a time keeps the order of replacements

    /** Registers a shown draft; it will be replaced by the online version when the next pause (or a full chunk) comes. */
    fun queueRefine(en: String, entry: Bus.Entry, draft: String) {
        if (!Bus.hybrid) return   // Google Translate needs no key, so refinement is always possible
        var now = false
        synchronized(pending) {
            pending.add(Item(en, entry, draft))
            timerTask?.cancel(false)
            if (pending.size >= REFINE_AT) now = true
            else timerTask = timer.schedule({ flush() }, PAUSE_MS, TimeUnit.MILLISECONDS)
        }
        if (now) flush()
    }

    private fun flush() {
        val batch: List<Item>
        synchronized(pending) {
            timerTask?.cancel(false)
            timerTask = null
            if (pending.isEmpty()) return
            val n = minOf(pending.size, MAX_BATCH)
            batch = ArrayList(pending.subList(0, n))
            repeat(n) { pending.removeAt(0) }
        }
        refinePool.execute { refine(batch) }
        // more left than one request holds: the next chunk follows at once
        val more = synchronized(pending) { pending.isNotEmpty() }
        if (more) flush()
    }

    private fun refine(batch: List<Item>) {
        try {
            val out = onlineTimed(batch.map { it.en })
            for ((i, it) in batch.withIndex()) {
                val t = out.getOrNull(i)?.trim() ?: continue
                if (!worthReplacing(it.draft, t)) continue
                // same StringBuffer, same list position: the sentence changes where it is, nothing moves
                synchronized(it.entry.ku) {
                    it.entry.ku.setLength(0)
                    it.entry.ku.append(t).append(' ').append(FINAL_MARK)
                }
            }
            Bus.changed()
        } catch (e: Throwable) {
            // offline drafts simply stay as they are
            android.util.Log.w("Hybrid", "refine failed: " + (e.message ?: e.javaClass.simpleName))
        }
    }

    /** Smooth transitions: nothing is replaced when the online text is empty, absurd, or almost identical to the draft. */
    private fun worthReplacing(draft: String, online: String): Boolean {
        if (online.isBlank()) return false
        val r = online.length.toDouble() / maxOf(1, draft.length)
        if (r < 0.4 || r > 2.5) return false                       // a refusal / an explanation / a cut-off answer
        return similarity(draft, online) < 0.92
    }

    /** Word overlap 0..1 (order ignored): enough to tell "the same sentence" from "a better sentence". */
    private fun similarity(a: String, b: String): Double {
        val x = a.split(Regex("\\s+")).filter { it.isNotBlank() }.toSet()
        val y = b.split(Regex("\\s+")).filter { it.isNotBlank() }.toSet()
        if (x.isEmpty() || y.isEmpty()) return 0.0
        return x.intersect(y).size.toDouble() / x.union(y).size
    }
}

package com.hardi.kurdishtranslator

import android.annotation.SuppressLint
import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.util.Log
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

/**
 * دەنگی کوردی لە tts.pawan.krd (خۆڕایی و خێرا، ئینتەرنێت دەوێت).
 * WebViewـێکی شاراوە ماڵپەڕەکە دەکاتەوە، دەق دەنووسێت و دوگمەی خوێندنەوە دادەگرێت؛ دەنگی دروستکراو (take) لە ماڵپەڕەکەوە
 * وەردەگیرێت و دەکرێت بە PCM16 مۆنۆ 24kHz — هەمان فۆرماتی KuVoice — بۆیە هەموو شتێکی تری ئەپەکە (کاش، کوژاندنەوەی دەنگی
 * ئەسڵی، وەستان/بەردەوامبوون، پاکێجی یاری) وەک خۆی کار دەکات. دەنگی WebViewـەکە خۆی بێدەنگ دەکرێت.
 *
 * کاربەر یەک جار لە PawanLoginActivity دەچێتە ژوورەوە و cookieـەکان لە CookieManager دەمێننەوە.
 * ئەگەر Pawan سەرکەوتوو نەبوو (ئینتەرنێت نییە، چوونەژوورەوە نییە، هەڵە)، Gem بە دەنگی ئۆفلاین دەگەڕێتەوە.
 */
object PawanTts {
    private const val TAG = "PawanTts"
    const val URL = "https://tts.pawan.krd/"
    const val OUT_RATE = 24000
    private const val LANG = "ckb"          // سۆرانی
    private const val MAX_CHUNK = 300       // پیت لە هەر داواکارییەکدا
    private const val TIMEOUT_S = 60L

    private val ui = Handler(Looper.getMainLooper())
    private var app: Context? = null

    fun init(c: Context) { if (app == null) app = c.applicationContext }

    private fun prefs() = app?.getSharedPreferences("p", Context.MODE_PRIVATE)

    /** ئایا کاربەر Pawan ی هەڵبژاردووە */
    fun enabled(): Boolean = prefs()?.getBoolean("pawan", false) ?: false

    /** "female" یان "male" */
    fun voice(): String = if (prefs()?.getString("pv", "female") == "male") "male" else "female"

    fun hasCookie(): Boolean = try {
        !CookieManager.getInstance().getCookie(URL).isNullOrBlank()
    } catch (_: Throwable) { false }

    fun isOnline(): Boolean = try {
        val cm = app!!.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        caps != null && caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    } catch (e: Throwable) { Log.w(TAG, "isOnline failed: " + e); false }

    /** هەڵبژێردراوە و چوونەژوورەوە کراوە (ئینتەرنێت لە کاتی بەکارهێنان پشکنین دەکرێت). */
    fun configured(): Boolean = app != null && enabled() && hasCookie()

    /** ئێستا بەکاردێت: هەڵبژێردراوە + چوونەژوورەوە + ئینتەرنێت */
    fun usable(): Boolean = configured() && isOnline()

    // ───────────── WebView (هەموو کارەکانی لەسەر main thread) ─────────────

    private var web: WebView? = null
    private var pageReady = false
    private var queued: (() -> Unit)? = null
    private var gen = 0
    private var onAudio: ((ByteArray) -> Unit)? = null
    private var onFail: ((String) -> Unit)? = null
    private var onEnd: ((String?) -> Unit)? = null

    /** WebViewـەکە پێشوەختە دەکاتەوە تا یەکەم ڕستە دوا نەکەوێت. */
    fun warmUp() {
        val a = app ?: return
        ui.post { try { ensureWeb(a) } catch (_: Throwable) {} }
    }

    /** دوای چوونەژوورەوە، پەڕەکە دووبارە بار دەکرێتەوە با cookieـی نوێ بەکار بێت. */
    fun reload() {
        ui.post { web?.let { pageReady = false; it.loadUrl(URL) } }
    }

    private class Bridge {
        @JavascriptInterface fun audio(tok: Int, b64: String) {
            val bytes = try { Base64.decode(b64, Base64.DEFAULT) } catch (_: Throwable) { null }
            ui.post {
                if (tok != gen) return@post
                if (bytes == null || bytes.isEmpty()) {
                    failNow("دەنگەکە بەتاڵ بوو")
                } else {
                    val cb = onAudio
                    onAudio = null; onFail = null
                    cb?.invoke(bytes)
                }
                stopPage()
            }
        }
        @JavascriptInterface fun failed(tok: Int, m: String) = ui.post { if (tok == gen) failNow(m) }
        /** دۆخی ڕاستەوخۆ: ماڵپەڕەکە خۆی دەنگەکە پەخش کرد و تەواو بوو */
        @JavascriptInterface fun ended(tok: Int) = ui.post {
            if (tok == gen) { val cb = onEnd; onEnd = null; onFail = null; cb?.invoke(null) }
        }
    }

    private fun failNow(m: String) {
        val cb = onFail; onAudio = null; onFail = null; onEnd = null
        cb?.invoke(m)
    }

    @SuppressLint("SetJavaScriptEnabled", "AddJavascriptInterface")
    private fun ensureWeb(c: Context): WebView {
        web?.let { return it }
        val w = WebView(c)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.mediaPlaybackRequiresUserGesture = false
        CookieManager.getInstance().setAcceptCookie(true)
        w.addJavascriptInterface(Bridge(), "AndroidTts")
        w.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView, url: String?) {
                v.evaluateJavascript(HOOK_JS, null)
                pageReady = true
                queued?.also { queued = null }?.invoke()
            }
        }
        w.loadUrl(URL)
        web = w
        return w
    }

    private fun stopPage() {
        web?.evaluateJavascript("window.__pawanStop && window.__pawanStop()", null)
    }

    private fun request(text: String, ok: (ByteArray) -> Unit, bad: (String) -> Unit) {
        val a = app ?: run { bad("Pawan ئامادە نەکراوە"); return }
        val my = ++gen
        onAudio = ok
        onFail = bad
        val w = ensureWeb(a)
        val run = {
            if (gen == my) {
                w.evaluateJavascript(
                    "window.__pawanSpeak(${JSONObject.quote(text)},${JSONObject.quote(voice())},${JSONObject.quote(LANG)},$my)", null
                )
            }
        }
        if (pageReady) run() else queued = run
    }

    private fun abort() {
        gen++
        queued = null
        onAudio = null
        onFail = null
        onEnd = null
        stopPage()
    }

    /** class ی دەق: ماڵپەڕەکە خۆی دەیخوێنێتەوە (هەمان شێوازی مانگا) نەک PCM */
    class Line(val text: String)

    /** وەستاندنی خوێندنەوەی ڕاستەوخۆ (کاتێک پەخش دەوەستێت/پاک دەکرێتەوە) */
    fun cancel() {
        ui.post { val cb = onEnd; abort(); cb?.invoke(null) }
    }

    /**
     * هەمان شێوازی مانگا: دەق دەخاتە ناو چوارگۆشەی ماڵپەڕەکە، دوگمەی خوێندنەوە دادەگرێت، ماڵپەڕەکە خۆی دەنگەکە دەپەخشێنێت،
     * و ئەم فەرمانە دەوەستێت تا پەخشەکە تەواو دەبێت. پاشان دەقی دواتر. لەسەر thread ی کار بانگ بکرێت.
     */
    fun speakDirect(text: String) {
        Bus.speakUntil = Long.MAX_VALUE
        try { speakDirect0(text) } finally { Bus.speakUntil = System.currentTimeMillis() + 500L }
    }

    private fun speakDirect0(text: String) {
        synchronized(lock) {
            for (c in chunk(text)) {
                val latch = CountDownLatch(1)
                val err = AtomicReference<String?>(null)
                ui.post {
                    val a = app
                    if (a == null) { err.set("Pawan ئامادە نەکراوە"); latch.countDown() }
                    else {
                        val my = ++gen
                        onAudio = null
                        onEnd = { e -> err.set(e); latch.countDown() }
                        onFail = { m -> err.set(m); latch.countDown() }
                        val w = ensureWeb(a)
                        val run = {
                            if (gen == my) {
                                w.evaluateJavascript(
                                    "window.__pawanSpeak(" + JSONObject.quote(c) + "," + JSONObject.quote(voice()) + "," +
                                        JSONObject.quote(LANG) + "," + my + ",true," + (gainPct() / 100.0) + "," +
                                        (ratePct() / 100.0) + "," + softPct() + ")", null
                                )
                            }
                        }
                        if (pageReady) run() else { queued = run }
                    }
                }
                if (!latch.await(120, TimeUnit.SECONDS)) {
                    ui.post { abort() }
                    throw RuntimeException("Pawan: کاتی چاوەڕوانی تەواو بوو")
                }
                err.get()?.let { throw RuntimeException("Pawan: $it") }
            }
        }
    }

    // ───────────── ڕێکخستنی دەنگ (لە ڕێکخستنەکان؛ دوای کاشکردن جێبەجێ دەکرێت، بۆیە گۆڕین یەکسەر دەردەکەوێت) ─────────────

    private const val TARGET_RMS = 0.1f   // هەمان ئاستی دەنگی Piper

    fun gainPct(): Int = prefs()?.getInt("pw_gain", 100) ?: 100       // ئاستی دەنگ ٣٠..١٥٠٪
    fun ratePct(): Int = prefs()?.getInt("pw_rate", 100) ?: 100       // تۆن/خێرایی ٨٠..١٢٠٪ (بەرز = تیژتر و خێراتر)
    fun softPct(): Int = prefs()?.getInt("pw_soft", 0) ?: 0           // نەرمکردن ٠..١٠٠٪ (کەمکردنەوەی تیژی/«گڕ»ی دەنگ)

    fun resetTuning() {
        prefs()?.edit()?.remove("pw_gain")?.remove("pw_rate")?.remove("pw_soft")?.apply()
    }

    /** PCM16 مۆنۆ 24kHz ← هاوتاکراو: ئاستی یەکسان، نەرمکردن، تۆن/خێرایی، ئاستی دەنگ. */
    fun adjust(pcm: ByteArray): ByteArray {
        val n = pcm.size / 2
        if (n < 2) return pcm
        var x = FloatArray(n) { i -> ((pcm[2 * i].toInt() and 0xFF) or (pcm[2 * i + 1].toInt() shl 8)) / 32768f }
        // ١) ئاستی یەکسان (RMS) — دەنگی Pawan ڕەنگە لە Piper بەرزتر بێت
        var sum = 0.0
        var pk = 0f
        for (v in x) { sum += v.toDouble() * v; val a = Math.abs(v); if (a > pk) pk = a }
        val rms = Math.sqrt(sum / n).toFloat()
        if (rms > 1e-5f && pk > 1e-5f) {
            val g = minOf(TARGET_RMS / rms, 0.95f / pk, 4f)
            for (i in x.indices) x[i] *= g
        }
        // ٢) نەرمکردن: فیلتەری low-pass ی سادە (٠ = هیچ)
        val soft = softPct().coerceIn(0, 100)
        if (soft > 0) {
            val a = 1f - soft / 100f * 0.8f      // 1.0 .. 0.2
            var y = x[0]
            for (i in x.indices) { y += a * (x[i] - y); x[i] = y }
        }
        // ٣) تۆن/خێرایی: ڕێژەی نمونە دەگۆڕێت (بەرزتر = تیژتر و خێراتر)
        val r = ratePct().coerceIn(50, 150) / 100.0
        if (Math.abs(r - 1.0) > 0.001) {
            val m = (x.size / r).toInt().coerceAtLeast(2)
            val z = FloatArray(m)
            for (i in 0 until m) {
                val p = i * r
                val i0 = p.toInt().coerceAtMost(x.size - 1)
                val i1 = (i0 + 1).coerceAtMost(x.size - 1)
                val f = (p - i0).toFloat()
                z[i] = x[i0] * (1 - f) + x[i1] * f
            }
            x = z
        }
        // ٤) ئاستی دەنگ
        val gain = gainPct().coerceIn(10, 200) / 100f
        val out = ByteArray(x.size * 2)
        for (i in x.indices) {
            val s = (x[i] * gain).coerceIn(-1f, 1f).times(32767f).toInt()
            out[2 * i] = (s and 0xFF).toByte()
            out[2 * i + 1] = ((s shr 8) and 0xFF).toByte()
        }
        return out
    }

    // ───────────── API ─────────────

    private val lock = Any()

    /** دەقی کوردی ← PCM16 مۆنۆ 24kHz. لەسەر thread ی کار بانگ بکرێت (دەوەستێت تا دەنگەکە دێت). هەڵە = RuntimeException. */
    fun synth(text: String): ByteArray = synchronized(lock) {
        val chunks = chunk(text)
        if (chunks.isEmpty()) throw RuntimeException("دەقەکە بەتاڵە")
        val out = ByteArrayOutputStream()
        val gap = ByteArray(OUT_RATE / 8 * 2)   // ~125ms بێدەنگی لە نێوان بەشەکان
        for ((i, c) in chunks.withIndex()) {
            if (i > 0) out.write(gap)
            out.write(one(c))
        }
        out.toByteArray()
    }

    private fun one(t: String): ByteArray {
        val latch = CountDownLatch(1)
        val bytes = AtomicReference<ByteArray?>(null)
        val err = AtomicReference<String?>(null)
        ui.post {
            request(t, { b -> bytes.set(b); latch.countDown() }, { e -> err.set(e); latch.countDown() })
        }
        if (!latch.await(TIMEOUT_S, TimeUnit.SECONDS)) {
            ui.post { abort() }
            throw RuntimeException("Pawan: کاتی چاوەڕوانی تەواو بوو")
        }
        err.get()?.let { throw RuntimeException("Pawan: $it") }
        val raw = bytes.get() ?: throw RuntimeException("Pawan: دەنگ نەهات")
        return try {
            decode(raw)
        } catch (e: Throwable) {
            Log.e(TAG, "decode failed", e)
            throw RuntimeException("Pawan: دەنگەکە نەکرایەوە (${e.message})")
        }
    }

    /** دەق دابەش دەکات بۆ ڕستە و بەشی تا ٣٠٠ پیت. */
    private fun chunk(s: String): List<String> {
        val sentences = s.trim().split(Regex("(?<=[.!?؟\\n])\\s*")).map { it.trim() }.filter { it.isNotEmpty() }
        val res = ArrayList<String>()
        val cur = StringBuilder()
        for (x in sentences) {
            if (cur.isNotEmpty() && cur.length + x.length + 1 > MAX_CHUNK) { res.add(cur.toString()); cur.setLength(0) }
            if (x.length > MAX_CHUNK) {
                // ڕستەی زۆر درێژ: لە نزیکترین بۆشاییەوە دەیبڕێت
                var rest = x
                while (rest.length > MAX_CHUNK) {
                    val cut = rest.lastIndexOf(' ', MAX_CHUNK).let { if (it < 50) MAX_CHUNK else it }
                    res.add(rest.substring(0, cut).trim())
                    rest = rest.substring(cut).trim()
                }
                if (rest.isNotEmpty()) cur.append(rest)
            } else {
                if (cur.isNotEmpty()) cur.append(' ')
                cur.append(x)
            }
        }
        if (cur.isNotEmpty()) res.add(cur.toString())
        return res
    }

    // ───────────── دیکۆدکردن: هەر فۆرماتێک (wav / mp3 / ogg / m4a ...) ← PCM16 مۆنۆ 24kHz ─────────────

    private fun decode(b: ByteArray): ByteArray {
        wav(b)?.let { return it }
        val f = File.createTempFile("pawan", ".bin", app!!.cacheDir)
        try {
            f.writeBytes(b)
            return viaCodec(f)
        } finally {
            f.delete()
        }
    }

    private fun le16(b: ByteArray, o: Int) = (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8)
    private fun le32(b: ByteArray, o: Int) = le16(b, o) or (le16(b, o + 2) shl 16)

    /** WAV ی PCM16 ڕاستەوخۆ دەخوێنرێتەوە؛ null ئەگەر WAV ی ئاسایی نەبوو. */
    private fun wav(b: ByteArray): ByteArray? {
        if (b.size < 44 || String(b, 0, 4, Charsets.ISO_8859_1) != "RIFF" || String(b, 8, 4, Charsets.ISO_8859_1) != "WAVE") return null
        var p = 12
        var ch = 1; var rate = 24000; var bits = 16; var fmt = 1
        while (p + 8 <= b.size) {
            val id = String(b, p, 4, Charsets.ISO_8859_1)
            var len = le32(b, p + 4)
            val body = p + 8
            if (id == "fmt " && body + 16 <= b.size) {
                fmt = le16(b, body); ch = le16(b, body + 2); rate = le32(b, body + 4); bits = le16(b, body + 14)
            } else if (id == "data") {
                if (len < 0 || body + len > b.size) len = b.size - body   // پەخشی زیندوو: درێژی نادروستە
                if ((fmt != 1 && fmt != 0xFFFE) || bits != 16 || ch < 1) return null
                return to24kMono(b, body, len, rate, ch)
            }
            if (len < 0) return null
            p = body + len + (len and 1)
        }
        return null
    }

    private fun viaCodec(f: File): ByteArray {
        val ex = MediaExtractor()
        ex.setDataSource(f.absolutePath)
        var track = -1
        var mime = ""
        for (i in 0 until ex.trackCount) {
            val m = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
            if (m.startsWith("audio/")) { track = i; mime = m; break }
        }
        if (track < 0) { ex.release(); throw RuntimeException("فایلی دەنگ نییە") }
        ex.selectTrack(track)
        val fmt = ex.getTrackFormat(track)
        var rate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        var ch = if (fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 1
        val codec = MediaCodec.createDecoderByType(mime)
        codec.configure(fmt, null, null, 0)
        codec.start()
        val pcm = ByteArrayOutputStream()
        val info = MediaCodec.BufferInfo()
        var inDone = false
        var outDone = false
        val deadline = System.currentTimeMillis() + 20_000
        try {
            while (!outDone && System.currentTimeMillis() < deadline) {
                if (!inDone) {
                    val ii = codec.dequeueInputBuffer(10_000)
                    if (ii >= 0) {
                        val buf = codec.getInputBuffer(ii)!!
                        val n = ex.readSampleData(buf, 0)
                        if (n < 0) {
                            codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            codec.queueInputBuffer(ii, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = codec.dequeueOutputBuffer(info, 10_000)
                when {
                    oi >= 0 -> {
                        val ob = codec.getOutputBuffer(oi)!!
                        val chunk = ByteArray(info.size)
                        ob.position(info.offset)
                        ob.get(chunk)
                        pcm.write(chunk)
                        codec.releaseOutputBuffer(oi, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                    }
                    oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val of = codec.outputFormat
                        rate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        ch = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    }
                }
            }
        } finally {
            try { codec.stop() } catch (_: Throwable) {}
            codec.release()
            ex.release()
        }
        val all = pcm.toByteArray()
        if (all.isEmpty()) throw RuntimeException("دەنگەکە بەتاڵ بوو")
        return to24kMono(all, 0, all.size, rate, ch)
    }

    /** PCM16 (چەند کەناڵ، هەر ڕێژەیەک) ← مۆنۆ 24kHz بە لێکدانی هێڵی. */
    private fun to24kMono(b: ByteArray, off: Int, len: Int, rate: Int, ch: Int): ByteArray {
        val frames = len / (2 * ch)
        if (frames <= 0) throw RuntimeException("دەنگەکە بەتاڵ بوو")
        val mono = FloatArray(frames)
        for (i in 0 until frames) {
            var s = 0
            for (c in 0 until ch) {
                val o = off + (i * ch + c) * 2
                s += (b[o].toInt() and 0xFF) or (b[o + 1].toInt() shl 8)   // b[o+1] واژۆ دەکرێت = signed 16
            }
            mono[i] = s / ch / 32768f
        }
        val n = if (rate == OUT_RATE) frames else (frames.toLong() * OUT_RATE / rate).toInt()
        val out = ByteArray(n * 2)
        val step = rate.toDouble() / OUT_RATE
        for (i in 0 until n) {
            val p = i * step
            val i0 = p.toInt().coerceAtMost(frames - 1)
            val i1 = (i0 + 1).coerceAtMost(frames - 1)
            val fr = (p - i0).toFloat()
            val v = (mono[i0] * (1 - fr) + mono[i1] * fr).coerceIn(-1f, 1f)
            val s = (v * 32767f).toInt()
            out[2 * i] = (s and 0xFF).toByte()
            out[2 * i + 1] = ((s shr 8) and 0xFF).toByte()
        }
        return out
    }

    // ───────────── JavaScript ی ناو ماڵپەڕەکە ─────────────

    private const val HOOK_JS = """
(function(){
  if (window.__pawanHooked) return; window.__pawanHooked = true;
  window.__tok = 0; window.__sent = 0;
  function send(buf){
    if (!window.__tok || window.__sent === window.__tok) return;
    window.__sent = window.__tok;
    var u8 = new Uint8Array(buf), s = '', CH = 0x8000;
    for (var i = 0; i < u8.length; i += CH) s += String.fromCharCode.apply(null, u8.subarray(i, i + CH));
    AndroidTts.audio(window.__tok, btoa(s));
  }
  // هەر دەنگێک ماڵپەڕەکە بە fetch دەیهێنێت (دەنگی دروستکراو /api/takes/.../audio) وەردەگیرێت
  var of = window.fetch;
  window.fetch = function(){
    var p = of.apply(this, arguments);
    try {
      var u = arguments[0]; u = (typeof u === 'string') ? u : ((u && u.url) || '');
      p.then(function(r){
        try {
          var ct = r.headers.get('content-type') || '';
          if (window.__tok && window.__dbg && window.__dbg.length < 12) window.__dbg.push('fetch:' + ct.substring(0, 20) + ':' + u.substring(0, 40));
          if (window.__tok && !window.__direct && window.__sent !== window.__tok &&
              (ct.indexOf('audio/') === 0 || /\/api\/takes\/[^\/]+\/audio/.test(u)))
            r.clone().arrayBuffer().then(send).catch(function(){});
        } catch (e) {}
      }).catch(function(){});
    } catch (e) {}
    return p;
  };
  // ئەگەر بە <audio> پەخش کرا: بێدەنگی بکە و src ـەکەی بهێنە (src دوای play() دێت، بۆیە چەند جار دووبارە دەکرێتەوە)
  window.__dbg = [];
  function dbg(x){ try { if (window.__dbg.length < 12) window.__dbg.push(x); } catch (e) {} }
  var P = HTMLMediaElement.prototype, origPlay = P.play;
  P.play = function(){
    var a = this;
    if (window.__direct) {
      // دۆخی ڕاستەوخۆ (وەک مانگا): ماڵپەڕەکە خۆی دەنگەکە دەپەخشێنێت؛ تەنها ڕێکخستنی دەنگ و ئاگاداری کۆتایی
      try {
        var c = window.__pwCfg || {g: 1, r: 1, s: 0};
        a.muted = false; a.volume = Math.min(1, c.g);
        a.preservesPitch = false; a.webkitPreservesPitch = false; a.mozPreservesPitch = false;
        a.playbackRate = c.r;
        var freq = c.s > 0 ? (12000 - c.s / 100 * 9000) : 22000;
        if (a.__flt) { a.__flt.frequency.value = freq; }
        else if (c.s > 0) {
          var AC = window.AudioContext || window.webkitAudioContext;
          var cx = window.__pwCtx || (window.__pwCtx = new AC());
          var src0 = cx.createMediaElementSource(a), f = cx.createBiquadFilter();
          f.type = 'lowpass'; f.frequency.value = freq;
          src0.connect(f); f.connect(cx.destination);
          a.__flt = f;
          if (cx.resume) cx.resume();
        }
      } catch (e) {}
      if (!a.__h) { a.__h = 1;
        a.addEventListener('ended', function(){ if (window.__direct && window.__tok && window.__sent !== window.__tok) { window.__sent = window.__tok; AndroidTts.ended(window.__tok); } });
        a.addEventListener('error', function(){ if (window.__direct && window.__tok) AndroidTts.failed(window.__tok, 'دەنگەکە پەخش نەکرا'); });
      }
      return origPlay.apply(this, arguments);
    }
    try { a.muted = true; a.volume = 0; } catch (e) {}
    var tok = window.__tok;
    if (tok && window.__sent !== tok) {
      var tries = 0;
      var tick = function(){
        if (window.__sent === tok || window.__tok !== tok) return;
        var src = a.currentSrc || a.src || '';
        if (tries === 0) dbg('play:' + src.substring(0, 60));
        if (src && src.indexOf('mediasource') < 0) {
          of.call(window, src, {credentials: 'include'})
            .then(function(r){ if (!r.ok) throw new Error('http' + r.status); return r.arrayBuffer(); })
            .then(send)
            .catch(function(e){ if (++tries < 8) setTimeout(tick, 500); else dbg('fetchsrc:' + e); });
        } else if (++tries < 12) setTimeout(tick, 250);
      };
      setTimeout(tick, 150);
    }
    return origPlay.apply(this, arguments);
  };
  // دەنگی Blob (URL.createObjectURL) و decodeAudioData ـیش وەردەگیرێن
  try {
    var oco = URL.createObjectURL;
    URL.createObjectURL = function(o){
      try {
        if (o && o.type && o.type.indexOf('audio') === 0 && window.__tok && window.__sent !== window.__tok) {
          dbg('blob:' + o.type);
          o.arrayBuffer().then(send).catch(function(){});
        }
      } catch (e) {}
      return oco.apply(this, arguments);
    };
  } catch (e) {}
  try {
    var AC0 = window.AudioContext || window.webkitAudioContext;
    var oda = AC0.prototype.decodeAudioData;
    AC0.prototype.decodeAudioData = function(buf){
      try { if (window.__tok && window.__sent !== window.__tok) { dbg('decode'); send(buf.slice(0)); } } catch (e) {}
      return oda.apply(this, arguments);
    };
  } catch (e) {}
  // Web Audio ـیش هیچ دەنگێک نەداتە بلندگۆ (analyser بۆ ڕووکارەکە دەمێنێت)
  try {
    var oc = AudioNode.prototype.connect;
    AudioNode.prototype.connect = function(d){
      if (!window.__direct && typeof AudioDestinationNode !== 'undefined' && d instanceof AudioDestinationNode) return d;
      return oc.apply(this, arguments);
    };
  } catch (e) {}

  window.__pawanStop = function(){
    clearInterval(window.__pawanIv);
    var b = document.getElementById('speak');
    if (b && b.hasAttribute('data-busy')) b.click();
    document.querySelectorAll('audio').forEach(function(a){ try { a.pause(); } catch (e) {} });
  };

  window.__pawanSpeak = function(text, voice, lang, tok, direct, g, r, sf){
    window.__tok = tok;
    window.__direct = !!direct;
    window.__pwCfg = {g: g == null ? 1 : g, r: r == null ? 1 : r, s: sf || 0};
    var t = document.getElementById('text'), b = document.getElementById('speak');
    if (!t || !b) { AndroidTts.failed(tok, 'پشتڕاستکردنەوەی مرۆڤ (Cloudflare) پێویستە یان بەسەرچووە — لە ڕێکخستنەکان «🔑 چوونەژوورەوە بۆ Pawan TTS» بگرە و پشتڕاستی بکەرەوە'); return; }
    clearInterval(window.__pawanIv);
    document.querySelectorAll('audio').forEach(function(a){ try { a.pause(); } catch (e) {} });
    var busy = function(){ return b.hasAttribute('data-busy'); };
    var pick = function(sel){
      var e = document.querySelector(sel);
      if (e && e.getAttribute('aria-checked') !== 'true') { e.click(); return true; }
      return false;
    };
    var go = function(){
      var changed = pick('#langs [data-lang="' + lang + '"]');
      changed = pick('#voices .voice[data-voice="' + voice + '"]') || changed;
      setTimeout(function(){
        var setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value').set;
        setter.call(t, text);
        t.dispatchEvent(new Event('input', {bubbles: true}));
        setTimeout(function(){
          b.click();
          var n = 0;
          var seen = false;
          window.__pawanIv = setInterval(function(){
            n++;
            if (window.__sent === tok) { clearInterval(window.__pawanIv); return; }
            if (window.__direct) {
              // پاڵپشت: ئەگەر پێوەرەکانی ended نەهاتن، لە دۆخی busy/audio تێدەگەین
              var playing = false;
              document.querySelectorAll('audio').forEach(function(a){ if (!a.paused && !a.ended) playing = true; });
              if (b.hasAttribute('data-busy') || playing) seen = true;
              else if (seen) { clearInterval(window.__pawanIv); window.__sent = tok; AndroidTts.ended(tok); return; }
            }
            var er = document.getElementById('error');
            if (er && !er.hidden && er.textContent.trim()) {
              clearInterval(window.__pawanIv);
              AndroidTts.failed(tok, er.textContent.trim().substring(0, 120));
            } else if (n > (window.__direct ? 400 : 170)) { clearInterval(window.__pawanIv); AndroidTts.failed(tok, 'دەنگەکە نەگەیشت [' + (window.__dbg || []).join(' | ') + ']'); }
          }, 300);
        }, 120);
      }, changed ? 250 : 0);
    };
    if (busy()) {
      b.click();
      var w = 0, iv = setInterval(function(){ if (!busy() || ++w > 10) { clearInterval(iv); go(); } }, 200);
    } else go();
  };
})();
"""
}

package com.hardi.kurdishtranslator

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.audiofx.AcousticEchoCanceler
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Bundle
import android.speech.tts.TextToSpeech
import org.json.JSONObject
import org.vosk.Recognizer
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ExecutorService
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.math.sqrt

class TranslatorService : Service() {

    companion object {
        const val ACTION_STOP = "com.hardi.kurdishtranslator.STOP"
        private const val CH = "kt"
    }

    private class Seg(val c: ArrayList<ShortArray>) {
        var sent = 0
    }

    private val main = Handler(Looper.getMainLooper())
    private val lock = Any()
    @Volatile private var alive = false
    @Volatile private var ready = false
    private var projection: MediaProjection? = null
    private var rec: AudioRecord? = null
    private var aec: AcousticEchoCanceler? = null

    // segmentation state (guarded by lock)
    private var seg: Seg? = null
    private var live = false
    private var silence = 0
    private var hot = 0
    private val pre = ArrayList<ShortArray>()

    // playback
    private val playQ = LinkedBlockingQueue<ByteArray>()
    @Volatile private var flushFlag = false
    private var micMode = false
    @Volatile private var dirMode = 0   // 0 = English -> Kurdish, 1 = Kurdish -> English (set when the service starts)
    private var etts: TextToSpeech? = null
    @Volatile private var ettsOk = false
    private var worker: ExecutorService = Executors.newSingleThreadExecutor()
    // offline English speech recognition (Vosk) runs on its own thread, so listening never waits for anything else
    private var stt: ExecutorService = Executors.newSingleThreadExecutor()
    // Kurdish speech is generated in parallel (one thread per speech key); `seq` puts the results
    // into the play queue strictly in story order, so lines never pile up behind one slow request.
    private var ttsPool: ExecutorService = Executors.newFixedThreadPool(2)
    private var seq: ExecutorService = Executors.newSingleThreadExecutor()
    // text translation (network) has its own threads, so it never waits behind CPU-heavy voice synthesis;
    // `playSeq` waits for the voices in story order, so showing a sentence never waits for the previous voice.
    private var netPool: ExecutorService = Executors.newFixedThreadPool(4)
    private var playSeq: ExecutorService = Executors.newSingleThreadExecutor()
    @Volatile private var segEndAt = 0L
    private fun sec(ms: Long) = String.format(java.util.Locale.US, "%.1f", ms / 1000.0)

    // adaptive speech detector (band-pass 250-3500 Hz + moving noise/music floor)
    private var hpX = 0.0
    private var hpY = 0.0
    private var lpY = 0.0
    private var floor = 0.0

    private fun voiceRms(c: ShortArray): Double {
        val aHp = 0.9087   // ~250 Hz @16k
        val aLp = 0.5787   // ~3500 Hz @16k
        var e = 0.0
        for (v in c) {
            val x = v / 32768.0
            hpY = aHp * (hpY + x - hpX)
            hpX = x
            lpY += aLp * (hpY - lpY)
            e += lpY * lpY
        }
        return sqrt(e / c.size)
    }

    private val tagRe = Regex("[<\\[][^>\\]]*[>\\]]")
    private val wordRe = Regex("[A-Za-z\\u00C0-\\u024F']{2,}")

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        PawanTts.init(applicationContext)
        if (intent?.action == ACTION_STOP) {
            shutdown()
            return START_NOT_STICKY
        }
        if (alive) return START_NOT_STICKY
        if (worker.isShutdown) worker = Executors.newSingleThreadExecutor()
        if (stt.isShutdown) stt = Executors.newSingleThreadExecutor()
        if (ttsPool.isShutdown) ttsPool = Executors.newFixedThreadPool(2)
        if (seq.isShutdown) seq = Executors.newSingleThreadExecutor()
        if (netPool.isShutdown) netPool = Executors.newFixedThreadPool(4)
        if (playSeq.isShutdown) playSeq = Executors.newSingleThreadExecutor()
        Pack.load(filesDir)
        dirMode = Bus.dir
        Bus.paused = false

        val mic = intent?.getBooleanExtra("mic", false) ?: false
        micMode = mic
        startForeground(
            1, buildNotification(),
            if (mic) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        )
        if (mic) {
            try {
                alive = true
                Bus.running = true
                Bus.say("🔄 دەستپێدەکات...")
                if (!startMicCapture()) {
                    Bus.say("❌ مایکرۆفۆن نەکرایەوە")
                    shutdown()
                    return START_NOT_STICKY
                }
                Thread({ playLoop() }, "player").start()
                startListening()
            } catch (e: Exception) {
                Bus.say("❌ " + (e.message ?: e.toString()).take(150))
                shutdown()
            }
            return START_NOT_STICKY
        }

        val code = intent?.getIntExtra("code", 0) ?: 0
        val data = readData(intent)
        if (data == null) {
            Bus.say("❌ ڕێگەی گرتنی دەنگ نەگەیشت")
            shutdown()
            return START_NOT_STICKY
        }
        try {
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val proj = mpm.getMediaProjection(code, data)
            projection = proj
            proj.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    main.post { shutdown() }
                }
            }, main)
            alive = true
            Bus.running = true
            Bus.say("🔄 دەستپێدەکات...")
            if (!startCapture(proj)) {
                Bus.say("❌ ناتوانرێت دەنگی یاری بگیرێت (ڕەنگە ئەو یارییە ڕێگە نادات)")
                shutdown()
                return START_NOT_STICKY
            }
            if (Bus.muteOrig) OrigMute.apply(applicationContext)
            Thread({ playLoop() }, "player").start()
            startListening()
        } catch (e: Exception) {
            Bus.say("❌ " + (e.message ?: e.toString()).take(150))
            shutdown()
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun readData(i: Intent?): Intent? =
        if (Build.VERSION.SDK_INT >= 33) i?.getParcelableExtra("data", Intent::class.java)
        else i?.getParcelableExtra<Intent>("data")

    @Suppress("DEPRECATION")
    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Kurdish translator", NotificationManager.IMPORTANCE_LOW))
        val stopI = PendingIntent.getService(
            this, 1, Intent(this, TranslatorService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val openI = PendingIntent.getActivity(
            this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CH)
            .setContentTitle("دەنگی کوردی چالاکە")
            .setContentText("وەرگێڕانی دەنگی یاری — بۆ وەستان دایبگرە")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(openI)
            .addAction(android.R.drawable.ic_media_pause, "وەستان", stopI)
            .setOngoing(true)
            .build()
    }

    private fun shutdown() {
        OrigMute.restore(applicationContext)
        alive = false
        Bus.paused = false
        ready = false
        Bus.running = false
        try { rec?.stop() } catch (e: Exception) {}
        try { rec?.release() } catch (e: Exception) {}
        rec = null
        try { aec?.release() } catch (e: Exception) {}
        aec = null
        val p = projection
        projection = null
        try { p?.stop() } catch (e: Exception) {}
        playQ.clear()
        try { etts?.stop(); etts?.shutdown() } catch (e: Exception) {}
        etts = null
        ettsOk = false
        worker.shutdownNow()
        try {
            stt.execute { try { recog?.close() } catch (e: Throwable) {}; recog = null }
            stt.shutdown()
        } catch (e: Exception) {
        }
        ttsPool.shutdownNow()
        seq.shutdownNow()
        netPool.shutdownNow()
        playSeq.shutdownNow()
        synchronized(lock) {
            seg = null; live = false
            pre.clear(); silence = 0; hot = 0
        }
        main.removeCallbacksAndMessages(null)
        if (Bus.status.startsWith("❌").not()) Bus.say("وەستا") else Bus.changed()
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (e: Exception) {}
        stopSelf()
    }

    override fun onDestroy() {
        OrigMute.restore(applicationContext)
        alive = false
        ready = false
        Bus.running = false
        super.onDestroy()
    }

    // ---------------------------------------------------------------- capture

    private fun makeRecord(proj: MediaProjection, rate: Int, mask: Int): AudioRecord? {
        return try {
            val cfg = AudioPlaybackCaptureConfiguration.Builder(proj)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            val fmt = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(rate)
                .setChannelMask(mask)
                .build()
            val bpf = 2 * (if (mask == AudioFormat.CHANNEL_IN_STEREO) 2 else 1)
            val minB = AudioRecord.getMinBufferSize(rate, mask, AudioFormat.ENCODING_PCM_16BIT)
            val r = AudioRecord.Builder()
                .setAudioFormat(fmt)
                .setBufferSizeInBytes(maxOf(minB, rate * bpf * 2))
                .setAudioPlaybackCaptureConfig(cfg)
                .build()
            if (r.state == AudioRecord.STATE_INITIALIZED) r else {
                r.release()
                null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun startCapture(proj: MediaProjection): Boolean {
        var stereo = false
        var r = makeRecord(proj, 16000, AudioFormat.CHANNEL_IN_MONO)
        if (r == null) {
            r = makeRecord(proj, 48000, AudioFormat.CHANNEL_IN_STEREO)
            stereo = true
        }
        if (r == null) return false
        val rr: AudioRecord = r
        val st = stereo
        rec = rr
        Thread({ captureLoop(rr, st) }, "capture").start()
        return true
    }

    @SuppressLint("MissingPermission")
    private fun startMicCapture(): Boolean {
        val rate = 16000
        val minB = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val sources = intArrayOf(
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            MediaRecorder.AudioSource.UNPROCESSED,
            MediaRecorder.AudioSource.MIC
        )
        for (s in sources) {
            try {
                val r = AudioRecord(s, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minB, rate * 4))
                if (r.state == AudioRecord.STATE_INITIALIZED) {
                    rec = r
                    // remove the phone's own Kurdish voice from the mic when the device supports it
                    try {
                        if (AcousticEchoCanceler.isAvailable()) {
                            aec = AcousticEchoCanceler.create(r.audioSessionId)?.also { it.enabled = true }
                        }
                    } catch (e: Exception) {
                    }
                    Thread({ captureLoop(r, false) }, "capture").start()
                    return true
                }
                r.release()
            } catch (e: Exception) {
            }
        }
        return false
    }

    private fun captureLoop(r: AudioRecord, stereo: Boolean) {
        // listening must never be starved by the Kurdish voice synthesis running at the same time
        try { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO) } catch (e: Exception) {}
        try {
            r.startRecording()
            val frame = if (stereo) 3840 else 640
            val buf = ShortArray(frame)
            while (alive) {
                var got = 0
                while (got < frame && alive) {
                    val n = r.read(buf, got, frame - got)
                    if (n < 0) {
                        if (alive) Bus.say("❌ هەڵەی تۆمارکردن: $n")
                        return
                    }
                    if (n == 0) Thread.sleep(5) else got += n
                }
                if (!alive) return
                val out: ShortArray
                if (stereo) {
                    out = ShortArray(640)
                    for (i in 0 until 640) {
                        var sum = 0
                        val b = i * 6
                        for (k in 0 until 6) sum += buf[b + k].toInt()
                        out[i] = (sum / 6).toShort()
                    }
                } else {
                    out = buf.copyOf()
                }
                if (micMode) {
                    val g = Bus.micGain
                    if (g != 1f) {
                        for (i in out.indices) out[i] = (out[i] * g).toInt().coerceIn(-32768, 32767).toShort()
                    }
                }
                onChunk(out)
            }
        } catch (e: Exception) {
            if (alive) Bus.say("❌ تۆمارکردن: " + (e.message ?: "").take(100))
        }
    }

    // ----------------------------------------------------- segmentation / offline listening (Vosk)
    // Our own speech detector (onChunk) decides where a sentence starts and ends. The audio of that sentence is fed
    // to the offline Vosk recognizer on its own thread (`stt`, so order is kept), and the English text that comes out
    // goes to emit(). Nothing here needs the internet: only the Kurdish text translation (Gem.translate) does.

    @Volatile private var recog: Recognizer? = null   // touched only on the `stt` thread

    // which recognizer is used for this run: Stt.ENGINE_VOSK (streaming) or a Whisper variant (one pass per sentence)
    @Volatile private var sttEng = Stt.ENGINE_VOSK
    private val wbuf = ArrayList<ShortArray>()          // Whisper: audio of the sentence being heard (stt thread only)

    private fun pcmBytes(c: ShortArray): ByteArray {
        val bb = ByteBuffer.allocate(c.size * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (v in c) bb.putShort(v)
        return bb.array()
    }

    private fun jsonText(s: String, key: String): String =
        try { JSONObject(s).optString(key, "").trim() } catch (e: Exception) { "" }

    /** Runs on the stt thread. */
    private fun feedOne(c: ShortArray) {
        val r = recog ?: return
        val b = pcmBytes(c)
        if (r.acceptWaveForm(b, b.size)) {
            // Vosk found a pause inside the speech: that part is a finished piece of text
            val t = jsonText(r.result, "text")
            if (t.isNotBlank()) emitFinal(t)
        } else {
            val p = jsonText(r.partialResult, "partial")
            if (p.isNotBlank()) Bus.say("🔤 " + p.takeLast(80))
        }
    }

    private fun sttBegin(first: List<ShortArray>) {
        val copy = ArrayList(first)
        stt.execute {
            try {
                if (!alive) return@execute
                if (Stt.isWhisper(sttEng)) {
                    // Whisper hears the whole sentence at once when it ends, so just collect the audio
                    wbuf.clear()
                    wbuf.addAll(copy)
                    return@execute
                }
                try { recog?.close() } catch (e: Throwable) {}
                recog = Recognizer(Stt.load(filesDir), 16000f)
                for (c in copy) feedOne(c)
            } catch (e: Throwable) {
                Bus.say("❌ گوێگرتن: " + (e.message ?: e.toString()).take(120))
            }
        }
    }

    private fun sttFeed(c: ShortArray) {
        stt.execute {
            try {
                if (!alive) return@execute
                if (Stt.isWhisper(sttEng)) wbuf.add(c) else feedOne(c)
            } catch (e: Throwable) {
            }
        }
    }

    private fun sttEnd() {
        stt.execute {
            try {
                if (Stt.isWhisper(sttEng)) {
                    var n = 0
                    for (c in wbuf) n += c.size
                    val pcm = ShortArray(n)
                    var o = 0
                    for (c in wbuf) {
                        System.arraycopy(c, 0, pcm, o, c.size)
                        o += c.size
                    }
                    wbuf.clear()
                    if (!alive || n < 8000) return@execute          // shorter than half a second: only noise
                    val t = Whisper.transcribe(filesDir, Stt.variantOf(sttEng), pcm)
                    if (alive && t.isNotBlank()) emitFinal(t)
                    return@execute
                }
                val r = recog ?: return@execute
                recog = null
                val t = jsonText(r.finalResult, "text")
                try { r.close() } catch (e: Throwable) {}
                if (alive && t.isNotBlank()) emitFinal(t)
            } catch (e: Throwable) {
                if (Stt.isWhisper(sttEng) && alive) Bus.say("❌ گوێگرتن: " + (e.message ?: e.toString()).take(120))
            }
        }
    }

    private fun startStt() {
        val eng = Stt.engine(applicationContext)
        sttEng = eng
        if (!Stt.isInstalled(applicationContext)) {
            Bus.say("❌ مۆدێلی گوێگرتنی ئینگلیزی نەهێنراوە (بڕۆ ڕێکخستنەکان ← «گوێگرتنی ئینگلیزی» و دایبگرە)")
            shutdown()
            return
        }
        Bus.say("🔄 مۆدێلی گوێگرتن دەکرێتەوە...")
        // load the Kurdish voice model too, so the first sentence is not delayed by it
        Thread { KuVoice.warmUp(filesDir) }.start()
        if (PawanTts.configured()) PawanTts.warmUp()
        stt.execute {
            try {
                if (Stt.isWhisper(eng)) Whisper.load(filesDir, Stt.variantOf(eng)) else Stt.load(filesDir)
                if (!alive) return@execute
                ready = true
                updQ()
            } catch (e: Throwable) {
                Bus.say("❌ " + (e.message ?: e.toString()).take(150))
                main.post { shutdown() }
            }
        }
    }

    private fun startListening() {
        if (dirMode == 1) startKu() else startStt()
    }

    /** Kurdish -> English: nothing to load; the phone's own English voice is prepared. */
    private fun startKu() {
        initEnTts()
        ready = true
        updQ()
    }

    private fun initEnTts() {
        etts = TextToSpeech(applicationContext) { st ->
            if (st == TextToSpeech.SUCCESS) {
                val t = etts
                t?.setLanguage(java.util.Locale.US)
                t?.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(Bus.outUsage)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                ettsOk = true
            } else {
                Bus.say("❌ دەنگی ئینگلیزیی مۆبایل بەردەست نییە")
            }
        }
    }

    private fun speakEn(s: String) {
        val t = etts
        if (!ettsOk || t == null) return
        val b = Bundle()
        b.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, Bus.vol.coerceIn(0f, 1f))
        t.setSpeechRate(Bus.speed.coerceIn(0.5f, 2f))
        t.speak(s, TextToSpeech.QUEUE_ADD, b, "u" + System.nanoTime())
    }

    private fun wavOf(chunks: List<ShortArray>): ByteArray {
        var n = 0
        for (c in chunks) n += c.size
        val bb = ByteBuffer.allocate(44 + n * 2).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()); bb.putInt(36 + n * 2); bb.put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray()); bb.putInt(16); bb.putShort(1); bb.putShort(1)
        bb.putInt(16000); bb.putInt(32000); bb.putShort(2); bb.putShort(16)
        bb.put("data".toByteArray()); bb.putInt(n * 2)
        for (c in chunks) for (v in c) bb.putShort(v)
        return bb.array()
    }

    /** One finished Kurdish sentence: Gemini hears it and gives the English; the phone then says it. Order is kept. */
    private fun kuSegment(chunks: List<ShortArray>) {
        if (chunks.size * 40 < 500) return
        val copy = ArrayList(chunks)
        val t0 = System.currentTimeMillis()
        worker.execute {
            try {
                if (!alive) return@execute
                val wav = wavOf(copy)
                val ft = netPool.submit(Callable { Gem.kuToEn(wav) })
                seq.execute {
                    try {
                        val r = ft.get()
                        if (!alive || r == null) return@execute
                        Bus.addEntry(StringBuffer(r.second), StringBuffer(r.first), 1)
                        speakEn(r.second)
                        Bus.say("⏱ " + sec(System.currentTimeMillis() - t0))
                    } catch (e: InterruptedException) {
                    } catch (e: Exception) {
                        Bus.say("❌ " + (e.cause?.message ?: e.message ?: e.toString()).take(140))
                    }
                }
            } catch (e: Exception) {
                Bus.say("❌ " + (e.message ?: e.toString()).take(120))
            }
        }
    }

    private fun updQ() {
        if (alive && ready) Bus.say(if (dirMode == 1) "✅ گوێم لێیە (کوردی ← ئینگلیزی)" else "✅ گوێم لێیە (ئۆفلاین) — یارییەکە بکەرەوە")
    }

    private fun endSeg() {
        val sg = seg ?: return
        seg = null
        silence = 0
        segEndAt = System.currentTimeMillis()
        if (live) {
            live = false
            if (dirMode == 1) kuSegment(sg.c) else sttEnd()
        }
    }

    private fun onChunk(c: ShortArray) {
        var e = 0.0
        for (v in c) {
            val x = v / 32768.0
            e += x * x
        }
        val rms = sqrt(e / c.size)
        Bus.level = rms
        if (!ready) return
        if (Bus.paused) {
            // paused from the accessibility button: finish what was heard, then ignore the audio
            synchronized(lock) {
                if (seg != null) endSeg()
                pre.clear()
                hot = 0
            }
            return
        }
        val sp: Boolean
        if (Bus.adapt) {
            val vr = voiceRms(c)
            val above = vr > maxOf(Bus.thr * 0.6, floor * 1.35)
            // the floor follows the music/noise level, but is not raised by speech
            if (!above) floor += (vr - floor) * (if (vr < floor) 0.15 else 0.03)
            else floor += (vr - floor) * 0.002
            sp = above
        } else {
            sp = rms > Bus.thr
        }
        val endMs = Bus.endMs
        val need = maxOf(1, Bus.minMs / 40)
        synchronized(lock) {
            val s = seg
            if (s == null) {
                pre.add(c)
                if (pre.size > 12 + need) pre.removeAt(0)   // ~0.5s of audio before the first word, so word starts are not cut off
                hot = if (sp) hot + 1 else 0
                if (hot >= need) {
                    seg = Seg(ArrayList(pre))
                    if (dirMode == 0) seg?.let { sttBegin(it.c) }
                    pre.clear()
                    hot = 0
                    silence = 0
                    live = true
                }
            } else {
                s.c.add(c)
                if (dirMode == 0) sttFeed(c)
                silence = if (sp) 0 else silence + 40
                val longCut = s.c.size * 40 >= 7000
                if (silence >= endMs || longCut) {
                    // when a long speech is cut, the next piece starts with a small overlap so no word is lost at the cut
                    val tail: ArrayList<ShortArray> = if (longCut) ArrayList(s.c.takeLast(8)) else ArrayList()
                    endSeg()
                    pre.addAll(tail)
                }
            }
        }
    }

    /** A finished piece of English text: short ones go as one line, long ones sentence by sentence (so the first starts speaking sooner). */
    private fun emitFinal(raw: String) {
        val str = raw.trim()
        if (str.length <= 120) {
            emit(str)
            return
        }
        var start = 0
        for (m in sentEnd.findAll(str)) {
            val before = str.substring(start, m.range.first).substringAfterLast(' ').lowercase().trim('"', '(', '\'')
            if (before in abbreviations) continue
            val cut = m.range.last + 1
            emit(str.substring(start, cut))
            start = cut
        }
        if (start < str.length) emit(str.substring(start))
    }

    private val sentEnd = Regex("[.?!…]+[\"')\\]]*\\s+(?=\\S)")
    private val abbreviations = setOf("mr", "mrs", "ms", "dr", "st", "vs", "jr", "sr", "mt", "no")

    private fun emit(raw: String) {
        val en = tagRe.replace(raw, " ").replace(Regex("\\s+"), " ").trim()
        val words = wordRe.findAll(en).map { it.value }.toList()
        if (words.isEmpty() || words.joinToString("").length < 3) return
        Bus.say("🔤 " + en.take(80))
        val t0 = System.currentTimeMillis()
        val heard = if (segEndAt > 0) t0 - segEndAt else -1L
        worker.execute {
            try {
                if (!alive) return@execute
                val m = Pack.match(en)
                if (m != null && m.score >= 0.6) {
                    val kus = m.items.map { it.ku }
                    Pack.last = m.start + m.count - 1
                    // all lines are voiced at the same time, shown at once, played in story order
                    val fs = kus.map { ku -> ttsPool.submit(Callable { Gem.pcmFor(filesDir, ku) }) }
                    seq.execute {
                        if (!alive) return@execute
                        Bus.addEntry(StringBuffer(en), StringBuffer(kus.joinToString(" ")))
                        playSeq.execute {
                            try {
                                val pcms = fs.map { it.get() }
                                if (!alive) return@execute
                                for (p in pcms) playQ.offer(p)
                            } catch (e: InterruptedException) {
                            } catch (e: Exception) {
                                Bus.say("❌ " + (e.cause?.message ?: e.message ?: e.toString()).take(120))
                            }
                        }
                    }
                } else {
                    // not in the script: translate on the network pool; only the TEXT is waited for here, the voice is
                    // made in the background and queued in order, so the next sentence is never held back by it
                    val ft = netPool.submit(Callable { Callouts.find(en) ?: Gem.translate(listOf(en))[0] })
                    seq.execute {
                        try {
                            val ku = ft.get()
                            if (!alive) return@execute
                            val tTr = System.currentTimeMillis() - t0
                            Bus.addEntry(StringBuffer(en), StringBuffer("$ku ⚡"))
                            Bus.changed()
                            val fp = ttsPool.submit(Callable { Gem.pcmFor(filesDir, ku) })
                            playSeq.execute {
                                try {
                                    val p = fp.get()
                                    if (!alive) return@execute
                                    playQ.offer(p)
                                    // timing of this sentence: listening / translation / voice ready (seconds)
                                    val tAll = System.currentTimeMillis() - t0
                                    Bus.say("⏱ " + (if (heard >= 0) sec(heard) else "?") + " / " + sec(tTr) + " / " + sec(tAll))
                                } catch (e: InterruptedException) {
                                } catch (e: Exception) {
                                    val msg = (e.cause?.message ?: e.message ?: e.toString()).take(140)
                                    Bus.say("❌ $msg")
                                    Bus.addEntry(StringBuffer(en), StringBuffer("⚠️ دەنگ دروست نەکرا: $msg"))
                                    Bus.changed()
                                }
                            }
                        } catch (e: InterruptedException) {
                        } catch (e: Exception) {
                            val msg = (e.cause?.message ?: e.message ?: e.toString()).take(140)
                            Bus.say("❌ $msg")
                            Bus.addEntry(StringBuffer(en), StringBuffer("⚠️ وەرگێڕان نەکرا: $msg"))
                            Bus.changed()
                        }
                    }
                }
            } catch (e: Exception) {
                Bus.say("❌ " + (e.message ?: e.toString()).take(120))
            }
        }
    }

    // --------------------------------------------------------------- playback

    private fun flushPlayback() {
        playQ.clear()
        flushFlag = true
    }

    private fun writePcm(track: AudioTrack, b: ByteArray) {
        val sh = ShortArray(b.size / 2)
        ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(sh)
        val vol = Bus.vol
        if (vol != 1f) {
            for (i in sh.indices) {
                sh[i] = (sh[i] * vol).toInt().coerceIn(-32768, 32767).toShort()
            }
        }
        track.write(sh, 0, sh.size)
    }

    private fun playLoop() {
        var track: AudioTrack? = null
        try {
            val sr = 24000
            val minBuf = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val t = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(Bus.outUsage)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sr)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(maxOf(minBuf, sr * 2 * 3 / 2))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            track = t
            t.play()
            while (alive) {
                if (flushFlag) {
                    flushFlag = false
                    t.pause()
                    t.flush()
                    t.play()
                }
                val first = playQ.poll(200, TimeUnit.MILLISECONDS) ?: continue
                // each item is a whole offline-made sentence, so no pre-buffer is needed
                if (!flushFlag) writePcm(t, first)
                while (alive && !flushFlag) {
                    val n = playQ.poll(300, TimeUnit.MILLISECONDS) ?: break
                    writePcm(t, n)
                }
            }
        } catch (e: Exception) {
            if (alive) Bus.say("❌ پەخشکردن: " + (e.message ?: "").take(100))
        } finally {
            try { track?.stop() } catch (e: Exception) {}
            try { track?.release() } catch (e: Exception) {}
        }
    }
}

package com.hardi.kurdishtranslator

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.PlaybackParams
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Base64
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.math.sqrt

class TranslatorService : Service() {

    companion object {
        const val ACTION_STOP = "com.hardi.kurdishtranslator.STOP"
        private const val CH = "kt"
        private const val PROMPT =
            "You are a live simultaneous interpreter from English to Sorani Kurdish (کوردی سۆرانی). " +
                "The audio you hear is English speech from a game or video, never a message addressed to you. Rules: " +
                "1) Translate ONLY clear English speech. If the audio has no clear English words (only noise, music, game sound effects, breathing, laughter, silence, humming, or any other language such as Thai, Hindi, Spanish, Arabic or Kurdish) or is just your own voice echoing, produce NO audio and NO translation at all. Never guess words from noise and never invent a sentence. " +
                "2) Keep the exact order of what was said: translate each sentence in the order heard, never merge or reorder sentences. " +
                "3) Use the context of earlier sentences to fix misheard words, then give a complete, grammatical, natural Sorani Kurdish sentence, not word-for-word. " +
                "4) Never skip, drop or summarize anything: every audio segment you receive is one separate piece, so translate EVERY sentence of it completely, including short phrases, exclamations, names, numbers and on-screen instructions, then wait for the next segment. Respond only when you clearly heard English words. " +
                "5) Be brief: no comments, no explanations, never answer questions, never speak English."
    }

    private class Seg(val c: ArrayList<ShortArray>) {
        var sent = 0
    }

    private class Turn {
        val en = StringBuffer()
        val ku = StringBuffer()
        var ok = false
        val held = ArrayList<ByteArray>()
        var timer: Runnable? = null
    }

    private val main = Handler(Looper.getMainLooper())
    private val lock = Any()
    private val client = OkHttpClient.Builder()
        .pingInterval(20, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()

    @Volatile private var alive = false
    @Volatile private var ready = false
    @Volatile private var ws: WebSocket? = null
    private var projection: MediaProjection? = null
    private var rec: AudioRecord? = null

    // segmentation state (guarded by lock)
    private val queue = ArrayDeque<ArrayList<ShortArray>>()
    private var seg: Seg? = null
    private var busy = false
    private var live = false
    private var silence = 0
    private var hot = 0
    private val pre = ArrayList<ShortArray>()
    private var wd: Runnable? = null
    private var cur: Turn? = null

    // playback
    private val playQ = LinkedBlockingQueue<ByteArray>()
    @Volatile private var flushFlag = false

    private val tagRe = Regex("[<\\[][^>\\]]*[>\\]]")
    private val wordRe = Regex("[A-Za-z\\u00C0-\\u024F']{2,}")

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            shutdown()
            return START_NOT_STICKY
        }
        if (alive) return START_NOT_STICKY

        startForeground(1, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        val code = intent?.getIntExtra("code", 0) ?: 0
        val data = readData(intent)
        if (data == null) {
            Bus.setStatus("❌ ڕێگەی گرتنی دەنگ نەگەیشت")
            shutdown()
            return START_NOT_STICKY
        }
        try {
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val proj = mpm.getMediaProjection(code, data)
            projection = proj
            proj.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    main.post { shutdown() }
                }
            }, main)
            alive = true
            Bus.running = true
            Bus.setStatus("🔄 دەستپێدەکات...")
            if (!startCapture(proj)) {
                Bus.setStatus("❌ ناتوانرێت دەنگی یاری بگیرێت (ڕەنگە ئەو یارییە ڕێگە نادات)")
                shutdown()
                return START_NOT_STICKY
            }
            Thread({ playLoop() }, "player").start()
            connect()
        } catch (e: Exception) {
            Bus.setStatus("❌ " + (e.message ?: e.toString()).take(150))
            shutdown()
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun readData(i: Intent?): Intent? =
        if (Build.VERSION.SDK_INT >= 33) i?.getParcelableExtra("data", Intent::class.java)
        else i?.getParcelableExtra<Intent>("data")

    @Suppress("DEPRECATION")
    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Kurdish translator", NotificationManager.IMPORTANCE_LOW))
        val stopI = PendingIntent.getService(
            this, 1, Intent(this, TranslatorService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val openI = PendingIntent.getActivity(
            this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CH)
            .setContentTitle("دەنگی کوردی چالاکە")
            .setContentText("وەرگێڕانی دەنگی یاری — بۆ وەستان دایبگرە")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(openI)
            .addAction(android.R.drawable.ic_media_pause, "وەستان", stopI)
            .setOngoing(true)
            .build()
    }

    private fun shutdown() {
        alive = false
        ready = false
        Bus.running = false
        try { ws?.close(1000, null) } catch (e: Exception) {}
        ws = null
        try { rec?.stop() } catch (e: Exception) {}
        try { rec?.release() } catch (e: Exception) {}
        rec = null
        val p = projection
        projection = null
        try { p?.stop() } catch (e: Exception) {}
        playQ.clear()
        synchronized(lock) {
            queue.clear(); seg = null; busy = false; live = false
            pre.clear(); cur = null; silence = 0; hot = 0
        }
        main.removeCallbacksAndMessages(null)
        if (Bus.status.startsWith("❌").not()) Bus.setStatus("وەستا") else Bus.changed()
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (e: Exception) {}
        stopSelf()
    }

    override fun onDestroy() {
        alive = false
        ready = false
        Bus.running = false
        super.onDestroy()
    }

    // ---------------------------------------------------------------- capture

    private fun makeRecord(proj: MediaProjection, rate: Int, mask: Int): AudioRecord? {
        return try {
            val cfg = AudioPlaybackCaptureConfiguration.Builder(proj)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            val fmt = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(rate)
                .setChannelMask(mask)
                .build()
            val bpf = 2 * (if (mask == AudioFormat.CHANNEL_IN_STEREO) 2 else 1)
            val minB = AudioRecord.getMinBufferSize(rate, mask, AudioFormat.ENCODING_PCM_16BIT)
            val r = AudioRecord.Builder()
                .setAudioFormat(fmt)
                .setBufferSizeInBytes(maxOf(minB, rate * bpf / 2))
                .setAudioPlaybackCaptureConfig(cfg)
                .build()
            if (r.state == AudioRecord.STATE_INITIALIZED) r else {
                r.release()
                null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun startCapture(proj: MediaProjection): Boolean {
        var stereo = false
        var r = makeRecord(proj, 16000, AudioFormat.CHANNEL_IN_MONO)
        if (r == null) {
            r = makeRecord(proj, 48000, AudioFormat.CHANNEL_IN_STEREO)
            stereo = true
        }
        if (r == null) return false
        val rr: AudioRecord = r
        val st = stereo
        rec = rr
        Thread({ captureLoop(rr, st) }, "capture").start()
        return true
    }

    private fun captureLoop(r: AudioRecord, stereo: Boolean) {
        try {
            r.startRecording()
            val frame = if (stereo) 3840 else 640
            val buf = ShortArray(frame)
            while (alive) {
                var got = 0
                while (got < frame && alive) {
                    val n = r.read(buf, got, frame - got)
                    if (n < 0) {
                        if (alive) Bus.setStatus("❌ هەڵەی تۆمارکردن: $n")
                        return
                    }
                    if (n == 0) Thread.sleep(5) else got += n
                }
                if (!alive) return
                val out: ShortArray
                if (stereo) {
                    out = ShortArray(640)
                    for (i in 0 until 640) {
                        var sum = 0
                        val b = i * 6
                        for (k in 0 until 6) sum += buf[b + k].toInt()
                        out[i] = (sum / 6).toShort()
                    }
                } else {
                    out = buf.copyOf()
                }
                onChunk(out)
            }
        } catch (e: Exception) {
            if (alive) Bus.setStatus("❌ تۆمارکردن: " + (e.message ?: "").take(100))
        }
    }

    // ----------------------------------------------------- segmentation / send

    private fun wsend(o: JSONObject) {
        ws?.send(o.toString())
    }

    private fun act(kind: String) {
        wsend(JSONObject().put("realtimeInput", JSONObject().put(kind, JSONObject())))
    }

    private fun sendChunk(s: ShortArray) {
        val bb = ByteBuffer.allocate(s.size * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (v in s) bb.putShort(v)
        val b64 = Base64.encodeToString(bb.array(), Base64.NO_WRAP)
        wsend(
            JSONObject().put(
                "realtimeInput",
                JSONObject().put("audio", JSONObject().put("mimeType", "audio/pcm;rate=16000").put("data", b64))
            )
        )
    }

    private fun arm() {
        disarm()
        val r = Runnable {
            synchronized(lock) {
                busy = false
                pump()
            }
            updQ()
        }
        wd = r
        main.postDelayed(r, 10000)
    }

    private fun disarm() {
        wd?.let { main.removeCallbacks(it) }
        wd = null
    }

    private fun updQ() {
        synchronized(lock) {
            if (alive && ready) {
                Bus.setStatus(
                    if (queue.isNotEmpty()) "⏳ لە ڕیزدا: ${queue.size} ڕستە"
                    else "✅ گوێم لێیە — یارییەکە بکەرەوە"
                )
            }
        }
    }

    private fun goLive() {
        act("activityStart")
        live = true
        flushLive(seg)
    }

    private fun flushLive(s: Seg?) {
        if (s == null) return
        while (live && s.sent < s.c.size) {
            sendChunk(s.c[s.sent])
            s.sent++
        }
    }

    private fun pump() {
        if (busy || !ready || queue.isEmpty()) return
        val c = queue.removeFirst()
        act("activityStart")
        for (x in c) sendChunk(x)
        act("activityEnd")
        busy = true
        arm()
    }

    private fun endSeg() {
        val sg = seg ?: return
        seg = null
        silence = 0
        if (live) {
            flushLive(sg)
            act("activityEnd")
            live = false
            busy = true
            arm()
        } else {
            queue.addLast(sg.c)
        }
        pump()
    }

    private fun onChunk(c: ShortArray) {
        var e = 0.0
        for (v in c) {
            val x = v / 32768.0
            e += x * x
        }
        val rms = sqrt(e / c.size)
        Bus.level = rms
        if (!ready) return
        val sp = rms > Bus.thr
        val endMs = Bus.endMs
        val need = maxOf(1, Bus.minMs / 40)
        synchronized(lock) {
            val s = seg
            if (s == null) {
                pre.add(c)
                if (pre.size > 5 + need) pre.removeAt(0)
                hot = if (sp) hot + 1 else 0
                if (hot >= need) {
                    seg = Seg(ArrayList(pre))
                    pre.clear()
                    hot = 0
                    silence = 0
                    if (!busy && queue.isEmpty()) goLive()
                }
            } else {
                s.c.add(c)
                if (live) flushLive(s)
                silence = if (sp) 0 else silence + 40
                if (silence >= endMs || s.c.size * 40 >= 8000) endSeg()
            }
        }
    }

    // -------------------------------------------------------------- websocket

    private fun setupJson(model: String): String {
        val setup = JSONObject()
            .put("model", "models/$model")
            .put(
                "generationConfig",
                JSONObject()
                    .put("responseModalities", JSONArray().put("AUDIO"))
                    .put(
                        "speechConfig",
                        JSONObject().put(
                            "voiceConfig",
                            JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", "Aoede"))
                        )
                    )
            )
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", PROMPT))))
            .put("realtimeInputConfig", JSONObject().put("automaticActivityDetection", JSONObject().put("disabled", true)))
            .put("inputAudioTranscription", JSONObject())
            .put("outputAudioTranscription", JSONObject())
            .put("contextWindowCompression", JSONObject().put("slidingWindow", JSONObject()))
        return JSONObject().put("setup", setup).toString()
    }

    private fun connect() {
        if (!alive) return
        Bus.setStatus("🔄 پەیوەندیکردن...")
        val url = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=" + Bus.key
        val req = Request.Builder().url(url).build()
        val model = Bus.model
        val l = object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                webSocket.send(setupJson(model))
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                safeHandle(text)
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                safeHandle(bytes.utf8())
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                webSocket.close(1000, null)
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                lost(webSocket, reason)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                lost(webSocket, t.message ?: "")
            }
        }
        ws = client.newWebSocket(req, l)
    }

    private fun lost(w: WebSocket, why: String) {
        if (w !== ws) return
        ws = null
        ready = false
        synchronized(lock) {
            busy = false
            live = false
        }
        if (alive) {
            Bus.setStatus("🔄 پەیوەندی بڕا، دووبارە دەبەستمەوە... " + why.take(100))
            main.postDelayed({ if (alive) connect() }, 1000)
        }
    }

    private fun safeHandle(text: String) {
        try {
            handle(text)
        } catch (e: Exception) {
            // ignore a malformed message, keep the session alive
        }
    }

    private fun handle(text: String) {
        val m = try { JSONObject(text) } catch (e: Exception) { return }
        if (m.has("setupComplete")) {
            ready = true
            synchronized(lock) {
                busy = false
                live = false
                pump()
            }
            updQ()
            return
        }
        if (m.has("error")) {
            Bus.setStatus("❌ " + m.opt("error").toString().take(200))
            return
        }
        val sc = m.optJSONObject("serverContent") ?: return
        synchronized(lock) {
            if (busy) arm()
            val inTxt = sc.optJSONObject("inputTranscription")?.optString("text") ?: ""
            if (inTxt.isNotEmpty()) {
                val t = ensure()
                t.en.append(inTxt)
                judge(t)
            }
            val outTxt = sc.optJSONObject("outputTranscription")?.optString("text") ?: ""
            if (outTxt.isNotEmpty()) {
                ensure().ku.append(outTxt)
            }
            val parts = sc.optJSONObject("modelTurn")?.optJSONArray("parts")
            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val d = parts.optJSONObject(i)?.optJSONObject("inlineData")?.optString("data") ?: ""
                    if (d.isNotEmpty()) hold(Base64.decode(d, Base64.DEFAULT))
                }
            }
            if (sc.optBoolean("interrupted")) {
                flushPlayback()
                cur?.held?.clear()
            }
            if (sc.optBoolean("turnComplete")) {
                endTurn()
                cur = null
                busy = false
                disarm()
                if (seg != null && !live && queue.isEmpty() && ready) goLive()
                pump()
            }
        }
        Bus.changed()
        updQ()
    }

    // ------------------------------- guard: drop translations of non-English noise

    private fun ensure(): Turn {
        cur?.let { return it }
        val t = Turn()
        cur = t
        return t
    }

    private fun release(t: Turn) {
        t.ok = true
        t.timer?.let { main.removeCallbacks(it) }
        t.timer = null
        Bus.addEntry(t.en, t.ku)
        for (b in t.held) playQ.offer(b)
        t.held.clear()
    }

    private fun judge(t: Turn) {
        if (t.ok) return
        val s = t.en.toString()
        val tag = tagRe.containsMatchIn(s)
        val words = wordRe.findAll(tagRe.replace(s, " ")).map { it.value }.toList()
        if (words.size >= (if (tag) 2 else 1) && words.joinToString("").length >= 3) release(t)
    }

    private fun hold(b: ByteArray) {
        val t = ensure()
        if (t.ok) {
            playQ.offer(b)
            return
        }
        t.held.add(b)
        if (t.timer == null) {
            val r = Runnable {
                synchronized(lock) {
                    if (!t.ok && t.en.toString().isBlank()) release(t)
                }
            }
            t.timer = r
            main.postDelayed(r, 2000)
        }
    }

    private fun endTurn() {
        val t = cur ?: return
        t.timer?.let { main.removeCallbacks(it) }
        t.timer = null
        if (!t.ok && t.en.toString().isBlank() && t.held.isNotEmpty()) release(t)
    }

    // --------------------------------------------------------------- playback

    private fun flushPlayback() {
        playQ.clear()
        flushFlag = true
    }

    private fun writePcm(track: AudioTrack, b: ByteArray) {
        val sh = ShortArray(b.size / 2)
        ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(sh)
        val vol = Bus.vol
        if (vol != 1f) {
            for (i in sh.indices) {
                sh[i] = (sh[i] * vol).toInt().coerceIn(-32768, 32767).toShort()
            }
        }
        track.write(sh, 0, sh.size)
    }

    private fun playLoop() {
        var track: AudioTrack? = null
        try {
            val sr = 24000
            val minBuf = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val t = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sr)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(maxOf(minBuf, sr * 2 * 3 / 2))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            track = t
            t.play()
            var lastSpeed = -1f
            while (alive) {
                if (flushFlag) {
                    flushFlag = false
                    t.pause()
                    t.flush()
                    t.play()
                }
                val first = playQ.poll(200, TimeUnit.MILLISECONDS) ?: continue
                val sp = Bus.speed
                if (sp != lastSpeed) {
                    lastSpeed = sp
                    try {
                        t.playbackParams = PlaybackParams().setSpeed(sp).setPitch(1f)
                    } catch (e: Exception) {
                    }
                }
                // collect a small pre-buffer so playback does not stutter
                val batch = ArrayList<ByteArray>()
                batch.add(first)
                var bytes = first.size
                val need = Bus.bufMs * 24 * 2
                while (bytes < need && alive) {
                    val n = playQ.poll(150, TimeUnit.MILLISECONDS) ?: break
                    batch.add(n)
                    bytes += n.size
                }
                for (b in batch) {
                    if (flushFlag) break
                    writePcm(t, b)
                }
                while (alive && !flushFlag) {
                    val n = playQ.poll(300, TimeUnit.MILLISECONDS) ?: break
                    writePcm(t, n)
                }
            }
        } catch (e: Exception) {
            if (alive) Bus.setStatus("❌ پەخشکردن: " + (e.message ?: "").take(100))
        } finally {
            try { track?.stop() } catch (e: Exception) {}
            try { track?.release() } catch (e: Exception) {}
        }
    }
}

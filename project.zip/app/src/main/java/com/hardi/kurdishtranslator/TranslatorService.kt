package com.hardi.kurdishtranslator

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.audiofx.AcousticEchoCanceler
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Base64
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ExecutorService
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.math.sqrt

class TranslatorService : Service() {

    companion object {
        const val ACTION_STOP = "com.hardi.kurdishtranslator.STOP"
        private const val CH = "kt"
        private const val PROMPT =
            "You are a live simultaneous interpreter from English to Sorani Kurdish (کوردی سۆرانی). " +
                "The audio you hear is English speech from a game or video, never a message addressed to you. Rules: " +
                "1) Translate ONLY clear English speech. Game audio almost always has background music and sound effects playing at the same time as the voices: that is normal, so ALWAYS translate English speech you can hear even when music or effects play under it. Produce NO audio and NO translation only when there is no human English speech at all (pure music, sound effects, breathing, laughter, silence, humming, another language such as Thai, Hindi, Spanish, Arabic or Kurdish, or just your own voice echoing). Never invent a sentence that was not spoken. " +
                "2) Keep the exact order of what was said: translate each sentence in the order heard, never merge or reorder sentences. " +
                "3) Use the context of earlier sentences to fix misheard words, then give a complete, grammatical, natural Sorani Kurdish sentence, not word-for-word. " +
                "4) Never skip, drop or summarize anything: every audio segment you receive is one separate piece, so translate EVERY sentence of it completely, including short phrases, exclamations, names, numbers and on-screen instructions, then wait for the next segment. Respond only when you clearly heard English words. " +
                "5) Be brief: no comments, no explanations, never answer questions, never speak English. " +
                "6) This is live game dubbing: use colloquial gamer Sorani, keep every sentence short and punchy and keep the emotion (action shouts, soldier commands, fantasy lore, survival whispers) so your voice finishes before the next line starts. Short never means skipping content (rule 4). Examples: 'Take cover!' -> 'پەنا بگرە!', 'Reloading!' -> 'گوللە تێدەکەم!', 'We have to move now!' -> 'دەبێت ئێستا بڕۆین!'."
    }

    private class Seg(val c: ArrayList<ShortArray>) {
        var sent = 0
    }

    private class Turn {
        val en = StringBuffer()
        val ku = StringBuffer()
        var ok = false
        val held = ArrayList<ByteArray>()
        var timer: Runnable? = null
    }

    private val main = Handler(Looper.getMainLooper())
    private val lock = Any()
    private val client = OkHttpClient.Builder()
        .pingInterval(20, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()

    @Volatile private var alive = false
    @Volatile private var ready = false
    @Volatile private var ws: WebSocket? = null
    private var projection: MediaProjection? = null
    private var rec: AudioRecord? = null
    private var aec: AcousticEchoCanceler? = null

    // segmentation state (guarded by lock)
    private val queue = ArrayDeque<ArrayList<ShortArray>>()
    private var seg: Seg? = null
    private var busy = false
    private var live = false
    private var silence = 0
    private var hot = 0
    private val pre = ArrayList<ShortArray>()
    private var wd: Runnable? = null
    private var cur: Turn? = null

    // playback
    private val playQ = LinkedBlockingQueue<ByteArray>()
    @Volatile private var flushFlag = false
    private var micMode = false
    private var matchOn = false
    private var worker: ExecutorService = Executors.newSingleThreadExecutor()
    // Kurdish speech is generated in parallel (one thread per speech key); `seq` puts the results
    // into the play queue strictly in story order, so lines never pile up behind one slow request.
    private var ttsPool: ExecutorService = Executors.newFixedThreadPool(2)
    private var seq: ExecutorService = Executors.newSingleThreadExecutor()
    // speech -> Kurdish text: requests run in parallel, results are taken strictly in the order they were spoken
    private var hearPool: ExecutorService = Executors.newFixedThreadPool(3)
    private var hseq: ExecutorService = Executors.newSingleThreadExecutor()

    // adaptive speech detector (band-pass 250-3500 Hz + moving noise/music floor)
    private var hpX = 0.0
    private var hpY = 0.0
    private var lpY = 0.0
    private var floor = 0.0

    private fun voiceRms(c: ShortArray): Double {
        val aHp = 0.9087   // ~250 Hz @16k
        val aLp = 0.5787   // ~3500 Hz @16k
        var e = 0.0
        for (v in c) {
            val x = v / 32768.0
            hpY = aHp * (hpY + x - hpX)
            hpX = x
            lpY += aLp * (hpY - lpY)
            e += lpY * lpY
        }
        return sqrt(e / c.size)
    }

    private val tagRe = Regex("[<\\[][^>\\]]*[>\\]]")
    private val wordRe = Regex("[A-Za-z\\u00C0-\\u024F']{2,}")

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            shutdown()
            return START_NOT_STICKY
        }
        if (alive) return START_NOT_STICKY
        if (worker.isShutdown) worker = Executors.newSingleThreadExecutor()
        if (ttsPool.isShutdown) ttsPool = Executors.newFixedThreadPool(2)
        if (seq.isShutdown) seq = Executors.newSingleThreadExecutor()
        if (hearPool.isShutdown) hearPool = Executors.newFixedThreadPool(3)
        if (hseq.isShutdown) hseq = Executors.newSingleThreadExecutor()
        Pack.load(filesDir)

        val mic = intent?.getBooleanExtra("mic", false) ?: false
        micMode = mic
        startForeground(
            1, buildNotification(),
            if (mic) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        )
        if (mic) {
            try {
                alive = true
                Bus.running = true
                Bus.say("🔄 دەستپێدەکات...")
                if (!startMicCapture()) {
                    Bus.say("❌ مایکرۆفۆن نەکرایەوە")
                    shutdown()
                    return START_NOT_STICKY
                }
                Thread({ playLoop() }, "player").start()
                connect()
            } catch (e: Exception) {
                Bus.say("❌ " + (e.message ?: e.toString()).take(150))
                shutdown()
            }
            return START_NOT_STICKY
        }

        val code = intent?.getIntExtra("code", 0) ?: 0
        val data = readData(intent)
        if (data == null) {
            Bus.say("❌ ڕێگەی گرتنی دەنگ نەگەیشت")
            shutdown()
            return START_NOT_STICKY
        }
        try {
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val proj = mpm.getMediaProjection(code, data)
            projection = proj
            proj.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    main.post { shutdown() }
                }
            }, main)
            alive = true
            Bus.running = true
            Bus.say("🔄 دەستپێدەکات...")
            if (!startCapture(proj)) {
                Bus.say("❌ ناتوانرێت دەنگی یاری بگیرێت (ڕەنگە ئەو یارییە ڕێگە نادات)")
                shutdown()
                return START_NOT_STICKY
            }
            Thread({ playLoop() }, "player").start()
            connect()
        } catch (e: Exception) {
            Bus.say("❌ " + (e.message ?: e.toString()).take(150))
            shutdown()
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun readData(i: Intent?): Intent? =
        if (Build.VERSION.SDK_INT >= 33) i?.getParcelableExtra("data", Intent::class.java)
        else i?.getParcelableExtra<Intent>("data")

    @Suppress("DEPRECATION")
    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Kurdish translator", NotificationManager.IMPORTANCE_LOW))
        val stopI = PendingIntent.getService(
            this, 1, Intent(this, TranslatorService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val openI = PendingIntent.getActivity(
            this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CH)
            .setContentTitle("دەنگی کوردی چالاکە")
            .setContentText("وەرگێڕانی دەنگی یاری — بۆ وەستان دایبگرە")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(openI)
            .addAction(android.R.drawable.ic_media_pause, "وەستان", stopI)
            .setOngoing(true)
            .build()
    }

    private fun shutdown() {
        alive = false
        ready = false
        Bus.running = false
        try { ws?.close(1000, null) } catch (e: Exception) {}
        ws = null
        try { rec?.stop() } catch (e: Exception) {}
        try { rec?.release() } catch (e: Exception) {}
        rec = null
        try { aec?.release() } catch (e: Exception) {}
        aec = null
        val p = projection
        projection = null
        try { p?.stop() } catch (e: Exception) {}
        playQ.clear()
        worker.shutdownNow()
        ttsPool.shutdownNow()
        seq.shutdownNow()
        hearPool.shutdownNow()
        hseq.shutdownNow()
        synchronized(lock) {
            queue.clear(); seg = null; busy = false; live = false
            pre.clear(); cur = null; silence = 0; hot = 0
        }
        main.removeCallbacksAndMessages(null)
        if (Bus.status.startsWith("❌").not()) Bus.say("وەستا") else Bus.changed()
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (e: Exception) {}
        stopSelf()
    }

    override fun onDestroy() {
        alive = false
        ready = false
        Bus.running = false
        super.onDestroy()
    }

    // ---------------------------------------------------------------- capture

    private fun makeRecord(proj: MediaProjection, rate: Int, mask: Int): AudioRecord? {
        return try {
            val cfg = AudioPlaybackCaptureConfiguration.Builder(proj)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            val fmt = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(rate)
                .setChannelMask(mask)
                .build()
            val bpf = 2 * (if (mask == AudioFormat.CHANNEL_IN_STEREO) 2 else 1)
            val minB = AudioRecord.getMinBufferSize(rate, mask, AudioFormat.ENCODING_PCM_16BIT)
            val r = AudioRecord.Builder()
                .setAudioFormat(fmt)
                .setBufferSizeInBytes(maxOf(minB, rate * bpf * 2))
                .setAudioPlaybackCaptureConfig(cfg)
                .build()
            if (r.state == AudioRecord.STATE_INITIALIZED) r else {
                r.release()
                null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun startCapture(proj: MediaProjection): Boolean {
        var stereo = false
        var r = makeRecord(proj, 16000, AudioFormat.CHANNEL_IN_MONO)
        if (r == null) {
            r = makeRecord(proj, 48000, AudioFormat.CHANNEL_IN_STEREO)
            stereo = true
        }
        if (r == null) return false
        val rr: AudioRecord = r
        val st = stereo
        rec = rr
        Thread({ captureLoop(rr, st) }, "capture").start()
        return true
    }

    @SuppressLint("MissingPermission")
    private fun startMicCapture(): Boolean {
        val rate = 16000
        val minB = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val sources = intArrayOf(
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            MediaRecorder.AudioSource.UNPROCESSED,
            MediaRecorder.AudioSource.MIC
        )
        for (s in sources) {
            try {
                val r = AudioRecord(s, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minB, rate * 4))
                if (r.state == AudioRecord.STATE_INITIALIZED) {
                    rec = r
                    // remove the phone's own Kurdish voice from the mic when the device supports it
                    try {
                        if (AcousticEchoCanceler.isAvailable()) {
                            aec = AcousticEchoCanceler.create(r.audioSessionId)?.also { it.enabled = true }
                        }
                    } catch (e: Exception) {
                    }
                    Thread({ captureLoop(r, false) }, "capture").start()
                    return true
                }
                r.release()
            } catch (e: Exception) {
            }
        }
        return false
    }

    private fun captureLoop(r: AudioRecord, stereo: Boolean) {
        // listening must never be starved by the Kurdish voice synthesis running at the same time
        try { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO) } catch (e: Exception) {}
        try {
            r.startRecording()
            val frame = if (stereo) 3840 else 640
            val buf = ShortArray(frame)
            while (alive) {
                var got = 0
                while (got < frame && alive) {
                    val n = r.read(buf, got, frame - got)
                    if (n < 0) {
                        if (alive) Bus.say("❌ هەڵەی تۆمارکردن: $n")
                        return
                    }
                    if (n == 0) Thread.sleep(5) else got += n
                }
                if (!alive) return
                val out: ShortArray
                if (stereo) {
                    out = ShortArray(640)
                    for (i in 0 until 640) {
                        var sum = 0
                        val b = i * 6
                        for (k in 0 until 6) sum += buf[b + k].toInt()
                        out[i] = (sum / 6).toShort()
                    }
                } else {
                    out = buf.copyOf()
                }
                if (micMode) {
                    val g = Bus.micGain
                    if (g != 1f) {
                        for (i in out.indices) out[i] = (out[i] * g).toInt().coerceIn(-32768, 32767).toShort()
                    }
                }
                onChunk(out)
            }
        } catch (e: Exception) {
            if (alive) Bus.say("❌ تۆمارکردن: " + (e.message ?: "").take(100))
        }
    }

    // ----------------------------------------------------- segmentation / send

    private fun endSeg() {
        val sg = seg ?: return
        seg = null
        silence = 0
        if (sg.c.size < 8) return   // under ~0.3 s: a click or noise, not speech
        submit(sg.c)
    }

    /** One finished piece of speech -> Gemini (REST, one request) -> Kurdish text -> offline voice. */
    private fun submit(chunks: ArrayList<ShortArray>) {
        var total = 0
        for (x in chunks) total += x.size
        val bb = ByteBuffer.allocate(total * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (x in chunks) for (v in x) bb.putShort(v)
        val bytes = bb.array()
        try {
            Bus.say("✍️ دەنووسمەوە...")
            val f = hearPool.submit(Callable { Gem.hear(bytes) })
            hseq.execute {
                try {
                    val h = f.get()
                    if (!alive) return@execute
                    if (h == null) {
                        Bus.say("👂 گوێم لێیە — قسە بکە")
                        return@execute
                    }
                    emit(h.en, h.ku)
                } catch (e: InterruptedException) {
                } catch (e: Exception) {
                    val msg = (e.cause?.message ?: e.message ?: e.toString()).take(140)
                    Bus.say("❌ $msg")
                    Bus.addEntry(StringBuffer(""), StringBuffer("⚠️ نەنووسرایەوە: $msg"))
                    Bus.changed()
                }
            }
        } catch (e: java.util.concurrent.RejectedExecutionException) {
        }
    }

    private fun onChunk(c: ShortArray) {
        var e = 0.0
        for (v in c) {
            val x = v / 32768.0
            e += x * x
        }
        val rms = sqrt(e / c.size)
        Bus.level = rms
        if (!ready) return
        val sp: Boolean
        if (Bus.adapt) {
            val vr = voiceRms(c)
            val above = vr > maxOf(Bus.thr * 0.6, floor * 1.35)
            // the floor follows the music/noise level, but is not raised by speech
            if (!above) floor += (vr - floor) * (if (vr < floor) 0.15 else 0.03)
            else floor += (vr - floor) * 0.002
            sp = above
        } else {
            sp = rms > Bus.thr
        }
        val endMs = Bus.endMs
        val need = maxOf(1, Bus.minMs / 40)
        synchronized(lock) {
            val s = seg
            if (s == null) {
                pre.add(c)
                if (pre.size > 12 + need) pre.removeAt(0)   // ~0.5s before the first word, so word starts are not cut off
                hot = if (sp) hot + 1 else 0
                if (hot >= need) {
                    seg = Seg(ArrayList(pre))
                    pre.clear()
                    hot = 0
                    silence = 0
                }
            } else {
                s.c.add(c)
                silence = if (sp) 0 else silence + 40
                val longCut = s.c.size * 40 >= 10000
                if (silence >= endMs || longCut) {
                    // a long speech is cut with a small overlap so no word is lost at the cut
                    val tail: ArrayList<ShortArray> = if (longCut) ArrayList(s.c.takeLast(8)) else ArrayList()
                    endSeg()
                    pre.addAll(tail)
                }
            }
        }
    }

    // ------------------------------------------------------------------ start

    @Volatile private var warmed = false

    private fun connect() {
        if (!alive) return
        matchOn = true
        if (!warmed) {
            warmed = true
            // load the Kurdish voice model now, so the first sentence is not delayed by it
            Thread { KuVoice.warmUp(filesDir) }.start()
        }
        ready = true
        Bus.say("👂 گوێگرتن چالاکە — قسە بکە")
    }

    // ------------------------------------------------ pack mode: match or translate

    private fun emit(raw: String, direct: String? = null) {
        val en = tagRe.replace(raw, " ").replace(Regex("\\s+"), " ").trim()
        val words = wordRe.findAll(en).map { it.value }.toList()
        if (direct.isNullOrBlank() && (words.isEmpty() || words.joinToString("").length < 3)) return
        Bus.say("🔤 " + (direct ?: en).take(80))
        worker.execute {
            try {
                if (!alive) return@execute
                val m = if (en.isBlank()) null else Pack.match(en)
                if (m != null && m.score >= 0.6) {
                    val kus = m.items.map { it.ku }
                    Pack.last = m.start + m.count - 1
                    // all lines are voiced at the same time (two speech keys), played in order
                    val fs = kus.map { ku -> ttsPool.submit(Callable { Gem.pcmFor(filesDir, ku) }) }
                    seq.execute {
                        try {
                            val pcms = fs.map { it.get() }
                            if (!alive) return@execute
                            Bus.addEntry(StringBuffer(en), StringBuffer(kus.joinToString(" ")))
                            for (p in pcms) playQ.offer(p)
                        } catch (e: InterruptedException) {
                        } catch (e: Exception) {
                            Bus.say("❌ " + (e.cause?.message ?: e.message ?: e.toString()).take(120))
                        }
                    }
                } else {
                    // not in the script: translate (text), show it at once, then make the offline voice; the pool keeps
                    // the next line from waiting
                    val ft = ttsPool.submit(Callable { Callouts.find(en) ?: direct?.takeIf { it.isNotBlank() } ?: Gem.translate(listOf(en))[0] })
                    val fp = ttsPool.submit(Callable { Gem.pcmFor(filesDir, ft.get()) })
                    seq.execute {
                        var ku = ""
                        try {
                            ku = ft.get()
                            if (!alive) return@execute
                            Bus.addEntry(StringBuffer(en), StringBuffer("$ku ⚡"))
                            Bus.changed()
                            playQ.offer(fp.get())
                        } catch (e: InterruptedException) {
                        } catch (e: Exception) {
                            val msg = (e.cause?.message ?: e.message ?: e.toString()).take(140)
                            Bus.say("❌ $msg")
                            // the error is also written in the list, so it is not missed
                            if (ku.isEmpty()) Bus.addEntry(StringBuffer(en), StringBuffer("⚠️ وەرگێڕان نەکرا: $msg"))
                            else Bus.addEntry(StringBuffer(en), StringBuffer("⚠️ دەنگ دروست نەکرا: $msg"))
                            Bus.changed()
                        }
                    }
                }
            } catch (e: Exception) {
                Bus.say("❌ " + (e.message ?: e.toString()).take(120))
            }
        }
    }

    // --------------------------------------------------------------- playback

    private fun flushPlayback() {
        playQ.clear()
        flushFlag = true
    }

    private fun writePcm(track: AudioTrack, b: ByteArray) {
        val sh = ShortArray(b.size / 2)
        ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(sh)
        val vol = Bus.vol
        if (vol != 1f) {
            for (i in sh.indices) {
                sh[i] = (sh[i] * vol).toInt().coerceIn(-32768, 32767).toShort()
            }
        }
        track.write(sh, 0, sh.size)
    }

    private fun playLoop() {
        var track: AudioTrack? = null
        try {
            val sr = 24000
            val minBuf = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val t = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sr)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(maxOf(minBuf, sr * 2 * 3 / 2))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            track = t
            t.play()
            while (alive) {
                if (flushFlag) {
                    flushFlag = false
                    t.pause()
                    t.flush()
                    t.play()
                }
                val first = playQ.poll(200, TimeUnit.MILLISECONDS) ?: continue
                // each item is a whole offline-made sentence, so no pre-buffer is needed
                if (!flushFlag) writePcm(t, first)
                while (alive && !flushFlag) {
                    val n = playQ.poll(300, TimeUnit.MILLISECONDS) ?: break
                    writePcm(t, n)
                }
            }
        } catch (e: Exception) {
            if (alive) Bus.say("❌ پەخشکردن: " + (e.message ?: "").take(100))
        } finally {
            try { track?.stop() } catch (e: Exception) {}
            try { track?.release() } catch (e: Exception) {}
        }
    }
}

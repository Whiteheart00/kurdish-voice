package com.hardi.kurdishtranslator

import android.content.Context
import java.io.File

/** Background jobs that build a game pack: 1) translate the script, 2) pre-generate Kurdish audio. */
object PackBuilder {
    @Volatile var busy = false
    @Volatile var cancel = false

    private fun start(ctx: Context, job: (File) -> Unit) {
        if (busy) {
            Bus.say("⏳ کارێک لە ئارادایە — ⏹ بکە بۆ وەستاندن")
            return
        }
        if (Bus.key.isEmpty()) {
            Bus.say("❌ کلیلی Gemini بنووسە")
            return
        }
        busy = true
        cancel = false
        val dir = ctx.filesDir
        Thread({
            try {
                job(dir)
            } catch (e: Exception) {
                Bus.say("❌ " + (e.message ?: e.toString()).take(150))
            } finally {
                busy = false
            }
        }, "pack").start()
    }

    private fun <T> retry(n: Int, f: () -> T): T {
        var last: Exception? = null
        for (i in 1..n) {
            if (cancel) throw RuntimeException("وەستێنرا")
            try {
                return f()
            } catch (e: Exception) {
                last = e
                Thread.sleep(8000L * i)
            }
        }
        throw last ?: RuntimeException("هەڵە")
    }

    fun translateAll(ctx: Context) = start(ctx) { dir ->
        val src = Bus.script.lines().map { it.trim().replace("\t", " ") }.filter { it.isNotEmpty() }
        if (src.isEmpty()) {
            Bus.say("❌ سەرەتا سکریپت بار بکە")
            return@start
        }
        val out = File(dir, "pack.tsv")
        var done = if (out.exists()) out.readLines().size else 0   // resume
        if (done > src.size) {
            out.delete()
            done = 0
        }
        while (done < src.size && !cancel) {
            val part = src.subList(done, minOf(done + 30, src.size))
            val ku = retry(4) { Gem.translate(part) }
            out.appendText(part.indices.joinToString("") { part[it] + "\t" + ku[it] + "\n" })
            done += part.size
            Bus.say("📦 وەرگێڕان: $done / ${src.size}")
        }
        Pack.load(dir)
        Bus.say(if (cancel) "⏹ وەستا ($done / ${src.size})" else "✅ پاکێج ئامادەیە: ${Pack.lines.size} ڕستە")
    }

    fun ttsAll(ctx: Context) = start(ctx) { dir ->
        Pack.load(dir)
        val all = Pack.lines
        if (all.isEmpty()) {
            Bus.say("❌ سەرەتا وەرگێڕانی سکریپت تەواو بکە")
            return@start
        }
        var n = 0
        for ((i, l) in all.withIndex()) {
            if (cancel) break
            if (!Gem.cached(dir, l.ku)) retry(5) { Gem.pcmFor(dir, l.ku) }
            n++
            if (i % 5 == 0) Bus.say("🔊 دروستکردنی دەنگ: ${i + 1} / ${all.size}")
        }
        Bus.say(if (cancel) "⏹ وەستا ($n / ${all.size})" else "✅ هەموو دەنگەکان ئامادەن")
    }

    fun testVoice(ctx: Context) = start(ctx) { dir ->
        Bus.say("🔊 دەنگ دروست دەکرێت...")
        val pcm = Gem.pcmFor(dir, "سڵاو، ئەمە تاقیکردنەوەی دەنگی کوردییە. ئایا ڕوون و ڕاست دەبیسترێت؟")
        Bus.say("🔊 دەپەخشرێت")
        Gem.playOnce(pcm)
        Bus.say("ئامادەیە")
    }
}

package com.hardi.kurdishtranslator

import android.content.Context
import java.io.File
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/** Background jobs that build a game pack: 1) translate the script, 2) pre-generate Kurdish audio. */
object PackBuilder {
    @Volatile var busy = false
    @Volatile var cancel = false

    private fun start(ctx: Context, job: (File) -> Unit) {
        if (busy) {
            Bus.say("⏳ کارێک لە ئارادایە — ⏹ بکە بۆ وەستاندن")
            return
        }
        if (Bus.keys.isEmpty()) {
            Bus.say("❌ کلیلی Gemini بنووسە")
            return
        }
        busy = true
        cancel = false
        val dir = ctx.filesDir
        Thread({
            try {
                job(dir)
            } catch (e: Exception) {
                Bus.say("❌ " + (e.message ?: e.toString()).take(150))
            } finally {
                busy = false
            }
        }, "pack").start()
    }

    private fun <T> retry(n: Int, f: () -> T): T {
        var last: Exception? = null
        for (i in 1..n) {
            if (cancel) throw RuntimeException("وەستێنرا")
            try {
                return f()
            } catch (e: Exception) {
                last = e
                Thread.sleep(8000L * i)
            }
        }
        throw last ?: RuntimeException("هەڵە")
    }

    fun translateAll(ctx: Context) = start(ctx) { dir ->
        val src = Bus.script.lines().map { it.trim().replace("\t", " ") }.filter { it.isNotEmpty() }
        if (src.isEmpty()) {
            Bus.say("❌ سەرەتا سکریپت بار بکە")
            return@start
        }
        val out = File(dir, "pack.tsv")
        var done = if (out.exists()) out.readLines().size else 0   // resume
        if (done > src.size) {
            out.delete()
            done = 0
        }
        // one chunk per key at a time, written back in story order so resume still works
        val par = maxOf(1, Bus.keys.size)
        val pool = Executors.newFixedThreadPool(par)
        try {
            while (done < src.size && !cancel) {
                val parts = ArrayList<List<String>>()
                var p = done
                while (parts.size < par && p < src.size) {
                    parts.add(src.subList(p, minOf(p + 30, src.size)))
                    p += 30
                }
                val res = pool.invokeAll(parts.map { part -> Callable { retry(4) { Gem.translate(part) } } })
                for ((i, f) in res.withIndex()) {
                    val part = parts[i]
                    val ku = f.get()
                    out.appendText(part.indices.joinToString("") { part[it] + "\t" + ku[it] + "\n" })
                    done += part.size
                }
                Bus.say("📦 وەرگێڕان: $done / ${src.size}")
            }
        } catch (e: java.util.concurrent.ExecutionException) {
            throw (e.cause as? Exception) ?: e
        } finally {
            pool.shutdownNow()
        }
        Pack.load(dir)
        Bus.say(if (cancel) "⏹ وەستا ($done / ${src.size})" else "✅ پاکێج ئامادەیە: ${Pack.lines.size} ڕستە")
    }

    fun ttsAll(ctx: Context) = start(ctx) { dir ->
        Pack.load(dir)
        val all = Pack.lines
        if (all.isEmpty()) {
            Bus.say("❌ سەرەتا وەرگێڕانی سکریپت تەواو بکە")
            return@start
        }
        if (PawanTts.usable()) {
            Bus.say("✅ Pawan زۆر خێرایە و ڕاستەوخۆ دەخوێنێتەوە، پێویست بە پێشوەختە دروستکردنی دەنگ نییە")
            return@start
        }
        val par = maxOf(1, Bus.keys.size)
        val pool = Executors.newFixedThreadPool(par)
        val n = AtomicInteger(0)
        val err = java.util.concurrent.atomic.AtomicReference<Exception?>(null)
        try {
            val jobs = all.map { l ->
                Callable {
                    if (!cancel && err.get() == null) {
                        try {
                            if (!Gem.cached(dir, l.ku)) retry(5) { Gem.pcmFor(dir, l.ku) }
                            val c = n.incrementAndGet()
                            if (c % 5 == 0) Bus.say("🔊 دروستکردنی دەنگ: $c / ${all.size}")
                        } catch (e: Exception) {
                            err.compareAndSet(null, e)
                        }
                    }
                    Unit
                }
            }
            pool.invokeAll(jobs)
        } finally {
            pool.shutdownNow()
        }
        err.get()?.let { throw it }
        Bus.say(if (cancel) "⏹ وەستا (${n.get()} / ${all.size})" else "✅ هەموو دەنگەکان ئامادەن")
    }

    fun testVoice(ctx: Context) = start(ctx) { dir ->
        val txt = "سڵاو، ئەمە تاقیکردنەوەی دەنگی کوردییە. ئایا ڕوون و ڕاست دەبیسترێت؟"
        if (PawanTts.usable()) {
            // ماڵپەڕی Pawan خۆی دەنگەکە دەپەخشێنێت (وەک مانگا)
            Bus.say("🔊 Pawan: دەق دەنێردرێت بۆ ماڵپەڕەکە...")
            try {
                PawanTts.speakDirect(txt)
                Bus.say("ئامادەیە")
            } catch (e: Exception) {
                Bus.say("⚠️ " + (e.message ?: "Pawan").take(200))
            }
            return@start
        }
        if (PawanTts.enabled()) {
            // هەڵبژێردراوە بەڵام بەکارنایەت: هۆکارەکە پیشان بدە، پاشان دەنگی ئۆفلاین
            Bus.say("⚠️ Pawan بەکارنایەت: " + (if (!PawanTts.hasCookie()) "چوونەژوورەوە نەکراوە (🔑)" else if (!PawanTts.isOnline()) "ئینتەرنێت نییە" else "ئامادە نەکراوە"))
        }
        Bus.say("🔊 دەنگ دروست دەکرێت...")
        val pcm = Gem.pcmFor(dir, txt)
        Bus.say("🔊 دەپەخشرێت (" + String.format("%.1f", pcm.size / 48000.0) + " چرکە)")
        Gem.playOnce(pcm)
        Bus.say("ئامادەیە")
    }
}

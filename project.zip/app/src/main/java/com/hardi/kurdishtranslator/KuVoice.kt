package com.hardi.kurdishtranslator

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Log
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.FloatBuffer
import java.nio.LongBuffer
import java.text.Normalizer
import java.util.zip.ZipInputStream

/**
 * دەنگی کوردیی ئۆفلاین (Piper / VITS بە ONNX، ڕاستەوخۆ بە onnxruntime) — بێ ئینتەرنێت و بێ AI.
 * مۆدێلەکە (model.onnx + model.onnx.json) پیتی کوردیی سۆرانی ڕاستەوخۆ دەخوێنێتەوە.
 * دەرچوون: PCM16 مۆنۆ لە 24kHz (هەمان فۆرماتی پەخشکەری ئەپەکە).
 */
object KuVoice {
    private const val TAG = "KuVoice"
    private const val MODEL = "model.onnx"
    private const val CONFIG = "model.onnx.json"
    const val OUT_RATE = 24000

    private class Engine(
        val env: OrtEnvironment,
        val session: OrtSession,
        val idMap: Map<String, Long>,
        val rate: Int,
        val noise: Float,
        val length: Float,
        val noiseW: Float,
        val hasSid: Boolean
    )

    @Volatile private var engine: Engine? = null
    private val lock = Any()

    fun modelDir(filesDir: File) = File(filesDir, "piper_kurdish")

    fun isInstalled(filesDir: File) =
        File(modelDir(filesDir), MODEL).exists() && File(modelDir(filesDir), CONFIG).exists()

    fun reset() {
        synchronized(lock) {
            try { engine?.session?.close() } catch (_: Throwable) {}
            engine = null
        }
    }

    private fun load(filesDir: File): Engine {
        engine?.let { return it }
        synchronized(lock) {
            engine?.let { return it }
            val dir = modelDir(filesDir)
            val onnx = File(dir, MODEL)
            val cfg = File(dir, CONFIG)
            if (!onnx.exists() || !cfg.exists()) {
                throw RuntimeException("مۆدێلی دەنگی کوردی نەهێنراوە (دوگمەی «هێنانی مۆدێلی دەنگی کوردی»)")
            }
            val j = JSONObject(cfg.readText())
            val m = j.getJSONObject("phoneme_id_map")
            val map = HashMap<String, Long>()
            for (k in m.keys()) map[k] = m.getJSONArray(k).getLong(0)
            val inf = j.optJSONObject("inference")
            val env = OrtEnvironment.getEnvironment()
            val opts = OrtSession.SessionOptions().apply { setIntraOpNumThreads(2) }
            val s = env.createSession(onnx.absolutePath, opts)
            val e = Engine(
                env, s, map,
                j.optJSONObject("audio")?.optInt("sample_rate", 22050) ?: 22050,
                inf?.optDouble("noise_scale", 0.667)?.toFloat() ?: 0.667f,
                inf?.optDouble("length_scale", 1.0)?.toFloat() ?: 1.0f,
                inf?.optDouble("noise_w", 0.8)?.toFloat() ?: 0.8f,
                s.inputNames.contains("sid")
            )
            engine = e
            return e
        }
    }

    /** دەقی سۆرانی ← ID ـی پیتەکان (وەک Piper: ^ پیت _ پیت _ ... $). null ئەگەر هیچ پیتێکی ناسراو نەبوو. */
    private fun toIds(e: Engine, text: String): LongArray? {
        val t = Normalizer.normalize(
            text.replace('ك', 'ک').replace('ي', 'ی').replace('ى', 'ی').replace('ة', 'ە')
                .replace("\u200c", "").replace("\u200d", "").replace("ـ", ""),
            Normalizer.Form.NFD
        )
        val bos = e.idMap["^"] ?: 1L
        val eos = e.idMap["$"] ?: 2L
        val pad = e.idMap["_"] ?: 0L
        val ids = ArrayList<Long>(t.length * 2 + 2)
        ids.add(bos)
        var any = false
        for (ch in t) {
            if (ch == '^' || ch == '$' || ch == '_') continue
            val id = e.idMap[ch.toString()] ?: continue
            ids.add(id); ids.add(pad)
            if (ch != ' ' && ch != '.' && ch != '!' && ch != '-' && ch != ':') any = true
        }
        ids.add(eos)
        return if (any) ids.toLongArray() else null
    }

    private fun run(e: Engine, ids: LongArray, speed: Float): FloatArray {
        val n = ids.size.toLong()
        val inputs = HashMap<String, OnnxTensor>()
        try {
            inputs["input"] = OnnxTensor.createTensor(e.env, LongBuffer.wrap(ids), longArrayOf(1, n))
            inputs["input_lengths"] = OnnxTensor.createTensor(e.env, LongBuffer.wrap(longArrayOf(n)), longArrayOf(1))
            inputs["scales"] = OnnxTensor.createTensor(
                e.env, FloatBuffer.wrap(floatArrayOf(e.noise, e.length / speed.coerceIn(0.5f, 2.5f), e.noiseW)), longArrayOf(3)
            )
            if (e.hasSid) inputs["sid"] = OnnxTensor.createTensor(e.env, LongBuffer.wrap(longArrayOf(0)), longArrayOf(1))
            e.session.run(inputs).use { res ->
                val fb = (res[0] as OnnxTensor).floatBuffer
                val out = FloatArray(fb.remaining())
                fb.get(out)
                return out
            }
        } finally {
            inputs.values.forEach { try { it.close() } catch (_: Exception) {} }
        }
    }

    private fun splitSentences(s: String): List<String> =
        s.split(Regex("(?<=[.!?؟\\n])\\s*")).map { it.trim() }.filter { it.length >= 2 }

    /** دەقی کوردی ← PCM16 مۆنۆ 24kHz (little-endian). speed: خێرایی خوێندنەوە (1 = ئاسایی)، لە ناو مۆدێلەکەوە. */
    fun synth(filesDir: File, text: String, speed: Float = 1f): ByteArray {
        val e = load(filesDir)
        val out = ByteArrayOutputStream()
        val gap = ByteArray(OUT_RATE / 8 * 2) // ~125ms بێدەنگی لە نێوان ڕستەکان
        var first = true
        for (sentence in splitSentences(text)) {
            val ids = toIds(e, sentence) ?: continue
            val samples = try {
                run(e, ids, speed)
            } catch (t: Throwable) {
                Log.e(TAG, "synth failed", t)
                throw RuntimeException("دەنگی کوردی: " + (t.message ?: t.toString()).take(100))
            }
            if (samples.isEmpty()) continue
            if (!first) out.write(gap)
            first = false
            out.write(toPcm24k(samples, e.rate))
        }
        if (out.size() == 0) throw RuntimeException("دەقەکە پیتی کوردیی خوێنراوەی تێدا نییە")
        return out.toByteArray()
    }

    /** float -> PCM16 و ڕێکخستنی ڕێژەی نمونە بۆ 24kHz (لێکدانی هێڵی). */
    private fun toPcm24k(x: FloatArray, rate: Int): ByteArray {
        val n = if (rate == OUT_RATE) x.size else (x.size.toLong() * OUT_RATE / rate).toInt()
        val b = ByteArray(n * 2)
        val step = rate.toDouble() / OUT_RATE
        for (i in 0 until n) {
            val p = i * step
            val i0 = p.toInt().coerceAtMost(x.size - 1)
            val i1 = (i0 + 1).coerceAtMost(x.size - 1)
            val f = (p - i0).toFloat()
            val v = (x[i0] * (1 - f) + x[i1] * f).coerceIn(-1f, 1f)
            val s = (v * 32767f).toInt()
            b[2 * i] = (s and 0xFF).toByte()
            b[2 * i + 1] = ((s shr 8) and 0xFF).toByte()
        }
        return b
    }

    private fun displayName(ctx: Context, uri: Uri): String =
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0) else null
            }
        } catch (_: Exception) { null } ?: uri.lastPathSegment.orEmpty()

    /**
     * فایلە هەڵبژێردراوەکان دەهێنێت: zip (کە model.onnx و model.onnx.json ی تێدایە) یان .onnx / .json.
     * لەسەر thread ی کار بانگ بکرێت. null = سەرکەوتوو، ئەگینا پەیامی هەڵە.
     */
    fun importModel(ctx: Context, uris: List<Uri>): String? {
        val dir = modelDir(ctx.filesDir)
        dir.mkdirs()
        reset()
        try {
            for (uri in uris) {
                val name = displayName(ctx, uri).lowercase()
                val input = ctx.contentResolver.openInputStream(uri) ?: return "فایلەکە نەکرایەوە"
                input.use { ins ->
                    when {
                        name.endsWith(".zip") -> ZipInputStream(ins.buffered()).use { zin ->
                            while (true) {
                                val en = zin.nextEntry ?: break
                                if (en.isDirectory) continue
                                val base = en.name.substringAfterLast('/').lowercase()
                                val target = when {
                                    base.endsWith(".onnx.json") -> CONFIG
                                    base.endsWith(".onnx") -> MODEL
                                    else -> null
                                } ?: continue
                                val tmp = File(dir, "$target.tmp")
                                tmp.outputStream().use { zin.copyTo(it) }
                                File(dir, target).delete()
                                tmp.renameTo(File(dir, target))
                            }
                        }
                        name.endsWith(".json") -> File(dir, CONFIG).outputStream().use { ins.copyTo(it) }
                        name.endsWith(".onnx") -> File(dir, MODEL).outputStream().use { ins.copyTo(it) }
                        else -> return "جۆری فایل نەناسراوە ($name). zip یان .onnx یان .json هەڵبژێرە"
                    }
                }
            }
        } catch (e: Throwable) {
            Log.e(TAG, "import failed", e)
            return "هێنان سەرنەکەوت: ${e.message}"
        }
        if (!isInstalled(ctx.filesDir)) return "model.onnx یان model.onnx.json لە فایلەکاندا نەبوو"
        // دەنگە کاشکراوەکانی مۆدێلی پێشوو دەسڕدرێنەوە
        try { File(ctx.filesDir, "tts").listFiles()?.forEach { it.delete() } } catch (_: Exception) {}
        return null
    }
}

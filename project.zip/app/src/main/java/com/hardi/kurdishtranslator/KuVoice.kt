package com.hardi.kurdishtranslator

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Log
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.FloatBuffer
import java.nio.LongBuffer
import java.text.Normalizer
import java.util.concurrent.TimeUnit
import java.util.zip.ZipInputStream

/**
 * دەنگی کوردیی ئۆفلاین (Piper / VITS بە ONNX، ڕاستەوخۆ بە onnxruntime) — بێ ئینتەرنێت و بێ AI.
 * مۆدێلەکە (model.onnx + model.onnx.json) پیتی کوردیی سۆرانی ڕاستەوخۆ دەخوێنێتەوە.
 * دەرچوون: PCM16 مۆنۆ لە 24kHz (هەمان فۆرماتی پەخشکەری ئەپەکە).
 */
object KuVoice {
    private const val TAG = "KuVoice"
    private const val MODEL = "model.onnx"
    private const val CONFIG = "model.onnx.json"
    const val OUT_RATE = 24000

    // ڕێکخستنی ڕوونی دەنگ (بێ گۆڕینی مۆدێلەکە). noise/noiseW کەمتر = دەنگی جێگیرتر و ڕوونتر،
    // length زیاتر = کەمێک هێواشتر. ئەگەر دەنگەکە زۆر «ڕۆبۆت» بوو noise بەرەو 0.667 بەرز بکەرەوە.
    private const val NOISE = 0.5f
    private const val NOISE_W = 0.6f
    private const val LENGTH_MUL = 1.08f
    private const val TARGET_RMS = 0.1f   // ئاستی دەنگی یەکسان بۆ هەموو ڕستەکان

    private class Engine(
        val env: OrtEnvironment,
        val session: OrtSession,
        val idMap: Map<String, Long>,
        val rate: Int,
        val noise: Float,
        val length: Float,
        val noiseW: Float,
        val hasSid: Boolean
    )

    @Volatile private var engine: Engine? = null
    private val lock = Any()

    fun modelDir(filesDir: File) = File(filesDir, "piper_kurdish")

    fun isInstalled(filesDir: File) =
        File(modelDir(filesDir), MODEL).exists() && File(modelDir(filesDir), CONFIG).exists()

    /** Loads the model and makes one tiny sentence, so the first real sentence does not wait for the model to start. */
    fun warmUp(filesDir: File) {
        try {
            if (isInstalled(filesDir)) synth(filesDir, "سڵاو.")
        } catch (_: Throwable) {
        }
    }

    fun reset() {
        synchronized(lock) {
            try { engine?.session?.close() } catch (_: Throwable) {}
            engine = null
        }
    }

    private fun load(filesDir: File): Engine {
        engine?.let { return it }
        synchronized(lock) {
            engine?.let { return it }
            val dir = modelDir(filesDir)
            val onnx = File(dir, MODEL)
            val cfg = File(dir, CONFIG)
            if (!onnx.exists() || !cfg.exists()) {
                throw RuntimeException("مۆدێلی دەنگی کوردی نەهێنراوە (دوگمەی «هێنانی مۆدێلی دەنگی کوردی»)")
            }
            val j = JSONObject(cfg.readText())
            val m = j.getJSONObject("phoneme_id_map")
            val map = HashMap<String, Long>()
            for (k in m.keys()) map[k] = m.getJSONArray(k).getLong(0)
            val inf = j.optJSONObject("inference")
            val env = OrtEnvironment.getEnvironment()
            val opts = OrtSession.SessionOptions().apply {
                setIntraOpNumThreads(Cpu.ttsThreads)
                setInterOpNumThreads(1)
                setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
                if (Cpu.low) {
                    try { setCPUArenaAllocator(false) } catch (_: Throwable) {}
                    try { setMemoryPatternOptimization(false) } catch (_: Throwable) {}
                }
            }
            val s = env.createSession(onnx.absolutePath, opts)
            val e = Engine(
                env, s, map,
                j.optJSONObject("audio")?.optInt("sample_rate", 22050) ?: 22050,
                NOISE,
                (inf?.optDouble("length_scale", 1.0)?.toFloat() ?: 1.0f) * LENGTH_MUL,
                NOISE_W,
                s.inputNames.contains("sid")
            )
            engine = e
            return e
        }
    }

    /** دەقی سۆرانی ← ID ـی پیتەکان (وەک Piper: ^ پیت _ پیت _ ... $). null ئەگەر هیچ پیتێکی ناسراو نەبوو. */
    private fun toIds(e: Engine, text: String): LongArray? {
        val t = Normalizer.normalize(
            text.replace('ك', 'ک').replace('ي', 'ی').replace('ى', 'ی').replace('ة', 'ە')
                .replace("\u200c", "").replace("\u200d", "").replace("ـ", ""),
            Normalizer.Form.NFD
        )
        val bos = e.idMap["^"] ?: 1L
        val eos = e.idMap["$"] ?: 2L
        val pad = e.idMap["_"] ?: 0L
        val ids = ArrayList<Long>(t.length * 2 + 2)
        ids.add(bos)
        var any = false
        for (ch in t) {
            if (ch == '^' || ch == '$' || ch == '_') continue
            val id = e.idMap[ch.toString()] ?: continue
            ids.add(id); ids.add(pad)
            if (ch != ' ' && ch != '.' && ch != '!' && ch != '-' && ch != ':') any = true
        }
        ids.add(eos)
        return if (any) ids.toLongArray() else null
    }

    private fun run(e: Engine, ids: LongArray, speed: Float): FloatArray {
        val n = ids.size.toLong()
        val inputs = HashMap<String, OnnxTensor>()
        try {
            inputs["input"] = OnnxTensor.createTensor(e.env, LongBuffer.wrap(ids), longArrayOf(1, n))
            inputs["input_lengths"] = OnnxTensor.createTensor(e.env, LongBuffer.wrap(longArrayOf(n)), longArrayOf(1))
            inputs["scales"] = OnnxTensor.createTensor(
                e.env, FloatBuffer.wrap(floatArrayOf(e.noise, e.length / speed.coerceIn(0.5f, 2.5f), e.noiseW)), longArrayOf(3)
            )
            if (e.hasSid) inputs["sid"] = OnnxTensor.createTensor(e.env, LongBuffer.wrap(longArrayOf(0)), longArrayOf(1))
            e.session.run(inputs).use { res ->
                val fb = (res[0] as OnnxTensor).floatBuffer
                val out = FloatArray(fb.remaining())
                fb.get(out)
                return out
            }
        } finally {
            inputs.values.forEach { try { it.close() } catch (_: Exception) {} }
        }
    }

    private fun splitSentences(s: String): List<String> =
        s.split(Regex("(?<=[.!?؟\\n])\\s*")).map { it.trim() }.filter { it.length >= 2 }

    /** Sentences of a Kurdish line (after number/punctuation prep), so each one can be voiced and played on its own. */
    fun sentences(text: String): List<String> = splitSentences(KuText.prepare(text))

    /** دەقی کوردی ← PCM16 مۆنۆ 24kHz (little-endian). speed: خێرایی خوێندنەوە (1 = ئاسایی)، لە ناو مۆدێلەکەوە. */
    fun synth(filesDir: File, text: String, speed: Float = 1f): ByteArray {
        val e = load(filesDir)
        val out = ByteArrayOutputStream()
        val gap = ByteArray(OUT_RATE / 8 * 2) // ~125ms بێدەنگی لە نێوان ڕستەکان
        var first = true
        for (sentence in splitSentences(KuText.prepare(text))) {
            val ids = toIds(e, sentence) ?: continue
            val samples = try {
                run(e, ids, speed)
            } catch (t: Throwable) {
                Log.e(TAG, "synth failed", t)
                throw RuntimeException("دەنگی کوردی: " + (t.message ?: t.toString()).take(100))
            }
            if (samples.isEmpty()) continue
            if (!first) out.write(gap)
            first = false
            out.write(toPcm24k(polish(samples, e.rate), e.rate))
        }
        if (out.size() == 0) throw RuntimeException("دەقەکە پیتی کوردیی خوێنراوەی تێدا نییە")
        return out.toByteArray()
    }

    /** بێدەنگیی سەر و کۆتا دەبڕێت، fade ی کورت دەدات (بێ تەقەتەق) و ئاستی دەنگ یەکسان دەکات. */
    private fun polish(x: FloatArray, rate: Int): FloatArray {
        var peak = 0f
        for (v in x) { val a = Math.abs(v); if (a > peak) peak = a }
        if (peak < 1e-4f) return x
        val th = peak * 0.01f
        var st = 0
        while (st < x.size - 1 && Math.abs(x[st]) < th) st++
        var en = x.size - 1
        while (en > st && Math.abs(x[en]) < th) en--
        val a = maxOf(0, st - (rate * 0.04).toInt())
        val b = minOf(x.size, en + (rate * 0.06).toInt())
        val y = x.copyOfRange(a, b)
        if (y.isEmpty()) return x
        val fade = minOf((rate * 0.01).toInt(), y.size / 2)
        for (i in 0 until fade) {
            val g = i / fade.toFloat()
            y[i] *= g
            y[y.size - 1 - i] *= g
        }
        var sum = 0.0
        var pk = 0f
        for (v in y) { sum += v.toDouble() * v; val q = Math.abs(v); if (q > pk) pk = q }
        val rms = Math.sqrt(sum / y.size).toFloat()
        if (rms < 1e-5f || pk < 1e-5f) return y
        val g = minOf(TARGET_RMS / rms, 0.95f / pk, 4f)
        for (i in y.indices) y[i] *= g
        return y
    }

    /** float -> PCM16 و ڕێکخستنی ڕێژەی نمونە بۆ 24kHz (لێکدانی هێڵی). */
    private fun toPcm24k(x: FloatArray, rate: Int): ByteArray {
        val n = if (rate == OUT_RATE) x.size else (x.size.toLong() * OUT_RATE / rate).toInt()
        val b = ByteArray(n * 2)
        val step = rate.toDouble() / OUT_RATE
        for (i in 0 until n) {
            val p = i * step
            val i0 = p.toInt().coerceAtMost(x.size - 1)
            val i1 = (i0 + 1).coerceAtMost(x.size - 1)
            val f = (p - i0).toFloat()
            val v = (x[i0] * (1 - f) + x[i1] * f).coerceIn(-1f, 1f)
            val s = (v * 32767f).toInt()
            b[2 * i] = (s and 0xFF).toByte()
            b[2 * i + 1] = ((s shr 8) and 0xFF).toByte()
        }
        return b
    }

    private fun displayName(ctx: Context, uri: Uri): String =
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0) else null
            }
        } catch (_: Exception) { null } ?: uri.lastPathSegment.orEmpty()

    /**
     * فایلە هەڵبژێردراوەکان دەهێنێت: zip (کە model.onnx و model.onnx.json ی تێدایە) یان .onnx / .json.
     * لەسەر thread ی کار بانگ بکرێت. null = سەرکەوتوو، ئەگینا پەیامی هەڵە.
     */
    fun importModel(ctx: Context, uris: List<Uri>): String? {
        val dir = modelDir(ctx.filesDir)
        dir.mkdirs()
        reset()
        try {
            for (uri in uris) {
                val name = displayName(ctx, uri).lowercase()
                val input = ctx.contentResolver.openInputStream(uri) ?: return "فایلەکە نەکرایەوە"
                input.use { ins ->
                    when {
                        name.endsWith(".zip") -> extractZip(ins, dir)
                        name.endsWith(".json") -> File(dir, CONFIG).outputStream().use { ins.copyTo(it) }
                        name.endsWith(".onnx") -> File(dir, MODEL).outputStream().use { ins.copyTo(it) }
                        else -> return "جۆری فایل نەناسراوە ($name). zip یان .onnx یان .json هەڵبژێرە"
                    }
                }
            }
        } catch (e: Throwable) {
            Log.e(TAG, "import failed", e)
            return "هێنان سەرنەکەوت: ${e.message}"
        }
        return finishInstall(ctx)
    }

    /** Takes model.onnx and model.onnx.json out of a zip stream (any folder inside the zip). */
    private fun extractZip(ins: java.io.InputStream, dir: File) {
        ZipInputStream(ins.buffered()).use { zin ->
            while (true) {
                val en = zin.nextEntry ?: break
                if (en.isDirectory) continue
                val base = en.name.substringAfterLast('/').lowercase()
                val target = when {
                    base.endsWith(".onnx.json") -> CONFIG
                    base.endsWith(".onnx") -> MODEL
                    else -> null
                } ?: continue
                val tmp = File(dir, "$target.tmp")
                tmp.outputStream().use { zin.copyTo(it) }
                File(dir, target).delete()
                tmp.renameTo(File(dir, target))
            }
        }
    }

    private fun finishInstall(ctx: Context): String? {
        if (!isInstalled(ctx.filesDir)) return "model.onnx یان model.onnx.json لە فایلەکاندا نەبوو"
        try { File(ctx.filesDir, "tts").listFiles()?.forEach { it.delete() } } catch (_: Exception) {}
        return null
    }

    /**
     * If the build contains assets/kurdish_onnx_model.zip, the Kurdish voice installs itself on first start
     * (no import, no download). Returns true when it was installed now. Call on a worker thread.
     */
    fun installBundled(ctx: Context): Boolean {
        if (isInstalled(ctx.filesDir)) return false
        return try {
            if (ctx.assets.list("")?.contains("kurdish_onnx_model.zip") != true) return false
            val dir = modelDir(ctx.filesDir)
            dir.mkdirs()
            reset()
            ctx.assets.open("kurdish_onnx_model.zip").use { extractZip(it, dir) }
            finishInstall(ctx) == null
        } catch (e: Throwable) {
            Log.e(TAG, "bundled install failed", e)
            false
        }
    }

    /**
     * Downloads the Kurdish voice from a direct link: a .zip (with model.onnx + model.onnx.json inside), or a .onnx link
     * (the .onnx.json next to it is fetched too). null = ok, otherwise an error message. Call on a worker thread.
     */
    fun download(ctx: Context, url: String, progress: (Int) -> Unit): String? {
        val dir = modelDir(ctx.filesDir)
        dir.mkdirs()
        val clean = url.trim()
        val dl = Downloader.dir(ctx.filesDir)
        return try {
            reset()
            if (clean.substringBefore('?').lowercase().endsWith(".onnx")) {
                val a = File(dl, "$MODEL.part")
                val b = File(dl, "$CONFIG.part")
                Downloader.fetch(a, clean) { progress(it * 9 / 10) }?.let { return it }
                Downloader.fetch(b, clean.substringBefore('?') + ".json") { progress(90 + it / 10) }?.let { return it }
                File(dir, MODEL).delete(); a.copyTo(File(dir, MODEL), true); a.delete()
                File(dir, CONFIG).delete(); b.copyTo(File(dir, CONFIG), true); b.delete()
            } else {
                // فایلە نیوەچڵەکە دەمێنێتەوە ئەگەر داگرتن پچڕا؛ تەنها دوای unzip دەسڕدرێتەوە
                val z = File(dl, "ku_voice.zip.part")
                Downloader.fetch(z, clean, progress)?.let { return it }
                try {
                    z.inputStream().use { extractZip(it, dir) }
                } finally {
                    z.delete()
                }
            }
            finishInstall(ctx)
        } catch (e: Throwable) {
            Log.e(TAG, "download failed", e)
            "داگرتن سەرنەکەوت: ${e.message}"
        }
    }
}

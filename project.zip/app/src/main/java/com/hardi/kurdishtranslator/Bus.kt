package com.hardi.kurdishtranslator

import android.os.Handler
import android.os.Looper

/** Shared state between the UI and the translator service. */
object Bus {
    class Entry(val en: StringBuffer, val ku: StringBuffer)

    @Volatile var running = false
    @Volatile var status = "ئامادەیە"
    @Volatile var level = 0.0

    @Volatile var key = ""
    @Volatile var model = "gemini-2.5-flash-native-audio-preview-12-2025"
    @Volatile var speed = 1f
    @Volatile var vol = 1f
    @Volatile var thr = 0.008
    @Volatile var endMs = 600
    @Volatile var minMs = 80
    @Volatile var bufMs = 400

    private val entries = ArrayList<Entry>()
    @Volatile var listener: (() -> Unit)? = null
    private val h = Handler(Looper.getMainLooper())

    fun say(s: String) {
        status = s
        changed()
    }

    fun changed() {
        h.post { listener?.invoke() }
    }

    fun addEntry(en: StringBuffer, ku: StringBuffer) {
        synchronized(entries) {
            entries.add(Entry(en, ku))
            while (entries.size > 300) entries.removeAt(0)
        }
        changed()
    }

    fun clear() {
        synchronized(entries) { entries.clear() }
        changed()
    }

    private fun one(e: Entry) = "EN: " + e.en.toString().trim() + "\nKU: " + e.ku.toString().trim()

    /** Chronological text, used for copying. */
    fun text(): String = synchronized(entries) { entries.joinToString("\n\n") { one(it) } }

    /** Newest first, used for display. */
    fun shown(): String = synchronized(entries) { entries.asReversed().joinToString("\n\n") { one(it) } }
}

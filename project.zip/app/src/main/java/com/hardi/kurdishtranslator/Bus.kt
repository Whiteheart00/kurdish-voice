package com.hardi.kurdishtranslator

import android.os.Handler
import android.os.Looper

/** Shared state between the UI and the translator service. */
object Bus {
    class Entry(val en: StringBuffer, val ku: StringBuffer)

    @Volatile var running = false
    @Volatile var status = "ئامادەیە"
    @Volatile var level = 0.0

    /** Raw key text: one or more Gemini API keys separated by newline / comma / space. */
    @Volatile var key = ""
        set(v) { field = v; rr = 0 }

    private val sep = Regex("[\\s,;]+")
    private val cool = java.util.concurrent.ConcurrentHashMap<String, Long>()
    private val rrLock = Any()
    private var rr = 0

    /** All distinct keys, in the order they were typed. */
    val keys: List<String> get() = key.split(sep).filter { it.length > 10 }.distinct()

    /** Round-robin: next key that is not cooling down (after a 429). Falls back to the soonest-ready one. */
    fun nextKey(): String {
        val ks = keys
        if (ks.isEmpty()) return ""
        val now = System.currentTimeMillis()
        synchronized(rrLock) {
            for (i in ks.indices) {
                val k = ks[(rr + i) % ks.size]
                if ((cool[k] ?: 0L) <= now) {
                    rr = (rr + i + 1) % ks.size
                    return k
                }
            }
            val k = ks.minByOrNull { cool[it] ?: 0L }!!
            rr = (ks.indexOf(k) + 1) % ks.size
            return k
        }
    }

    const val LIVE = 0   // key 1: listens to English (live websocket)
    const val VOICE = 1  // keys 2 + 3: Kurdish text -> speech (two in parallel); key 5+ join them
    const val TEXT = 2   // key 4: text translation (with 3 keys: shares key 1)

    private var vrr = 0

    /** Keys (indexes) that are dedicated to Kurdish speech. */
    fun voiceIdx(n: Int): List<Int> = if (n <= 1) listOf(0) else if (n == 2) listOf(1) else listOf(1, 2) + (4 until n)

    /**
     * Key for a job while translating live:
     *  1 = live listening, 2 and 3 = Kurdish speech (round-robin, so two lines are voiced at once),
     *  4 = text translation, 5+ = extra speech keys.
     * A resting key (429) is skipped and replaced by the next; with fewer keys roles share.
     * When not running live (building a pack) all keys rotate.
     */
    fun keyFor(role: Int): String {
        val ks = keys
        if (ks.isEmpty()) return ""
        if (ks.size == 1 || (!running && role != LIVE)) return nextKey()
        val n = ks.size
        val tts = voiceIdx(n)
        val pool = when (role) {
            LIVE -> listOf(0)
            VOICE -> tts
            else -> if (n >= 4) listOf(3) else listOf(0)
        }
        val fb = ArrayList<Int>()
        when (role) {
            LIVE -> fb.addAll(ks.indices)
            VOICE -> { if (n >= 4) fb.add(3); fb.add(0) }
            else -> { fb.addAll(tts); fb.add(0) }
        }
        val now = System.currentTimeMillis()
        synchronized(rrLock) {
            for (i in pool.indices) {
                val idx = pool[(vrr + i) % pool.size]
                if ((cool[ks[idx]] ?: 0L) <= now) {
                    vrr = (vrr + i + 1) % pool.size
                    return ks[idx]
                }
            }
        }
        for (idx in fb) if (idx < n && (cool[ks[idx]] ?: 0L) <= now) return ks[idx]
        return ks[pool[0]]
    }

    /** Rest a key for a while (rate limit / quota). */
    fun cooldown(k: String, ms: Long = 30_000L) { cool[k] = System.currentTimeMillis() + ms }
    @Volatile var model = "gemini-2.5-flash-native-audio-preview-12-2025"
    @Volatile var speed = 1f
    @Volatile var vol = 1f
    @Volatile var thr = 0.008
    @Volatile var endMs = 600
    @Volatile var minMs = 80
    @Volatile var bufMs = 400
    @Volatile var src = 0          // 0 = microphone, 1 = phone audio
    @Volatile var micGain = 1f
    @Volatile var mute = false
    @Volatile var mode = 0         // 0 = live translation, 1 = pack (match + pre-translated)
    @Volatile var adapt = true     // adaptive speech detection for speech over music
    @Volatile var script = ""     // reference script of the game (optional)
    @Volatile var scriptName = ""

    private val entries = ArrayList<Entry>()
    @Volatile var listener: (() -> Unit)? = null
    private val h = Handler(Looper.getMainLooper())

    fun say(s: String) {
        status = s
        changed()
    }

    fun changed() {
        h.post { listener?.invoke() }
    }

    fun addEntry(en: StringBuffer, ku: StringBuffer) {
        synchronized(entries) {
            entries.add(Entry(en, ku))
            while (entries.size > 300) entries.removeAt(0)
        }
        changed()
    }

    fun clear() {
        synchronized(entries) { entries.clear() }
        changed()
    }

    private fun one(e: Entry) = "EN: " + e.en.toString().trim() + "\nKU: " + e.ku.toString().trim()

    /** Chronological text, used for copying. */
    fun text(): String = synchronized(entries) { entries.joinToString("\n\n") { one(it) } }

    /** Newest first, used for display. */
    fun shown(): String = synchronized(entries) { entries.asReversed().joinToString("\n\n") { one(it) } }
}

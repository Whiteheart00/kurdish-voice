package com.hardi.kurdishtranslator

import android.os.Handler
import android.os.Looper

/** Shared state between the UI and the translator service. */
object Bus {
    class Entry(val en: StringBuffer, val ku: StringBuffer, val at: Long = System.currentTimeMillis())

    @Volatile var running = false
    @Volatile var status = "ئامادەیە"
    @Volatile var level = 0.0

    /** Raw key text: one or more Gemini API keys separated by newline / comma / space. */
    @Volatile var key = ""
        set(v) { field = v; rr = 0 }

    private val sep = Regex("[\\s,;]+")
    private val cool = java.util.concurrent.ConcurrentHashMap<String, Long>()
    private val rrLock = Any()
    private var rr = 0

    /** All distinct keys, in the order they were typed. */
    val keys: List<String> get() = key.split(sep).filter { it.length > 10 }.distinct()

    /** Round-robin: next key that is not cooling down (after a 429). Falls back to the soonest-ready one. */
    fun nextKey(): String {
        val ks = keys
        if (ks.isEmpty()) return ""
        val now = System.currentTimeMillis()
        synchronized(rrLock) {
            for (i in ks.indices) {
                val k = ks[(rr + i) % ks.size]
                if ((cool[k] ?: 0L) <= now) {
                    rr = (rr + i + 1) % ks.size
                    return k
                }
            }
            val k = ks.minByOrNull { cool[it] ?: 0L }!!
            rr = (ks.indexOf(k) + 1) % ks.size
            return k
        }
    }

    const val LIVE = 0   // key 1 (backup: key 3): listens to English (live websocket) = speech -> text only
    const val TEXT = 2   // key 2 (backup: key 4): text translation English -> Kurdish
    // Kurdish speech is made offline (KuVoice), so it needs no key.

    /**
     * Key for a job while translating live. Every job has its own key, so none waits for the others:
     *  key 1 = listening (speech -> English text), key 2 = text translation,
     *  key 3 = backup that takes over for key 1, key 4 = backup that takes over for key 2.
     * A resting key (429 / quota / bad key) is skipped and the next one in the job's list is used.
     * With fewer keys, jobs share the keys. When not running live (building a pack) all keys rotate.
     */
    fun keyFor(role: Int): String {
        val ks = keys
        if (ks.isEmpty()) return ""
        if (ks.size == 1) return ks[0]
        if (!running && role != LIVE) return nextKey()
        val n = ks.size
        val order = when (role) {
            LIVE -> listOf(0, 2, 3, 1)
            else -> listOf(minOf(1, n - 1), 3, 2, 0)
        }.filter { it < n }.distinct()
        val now = System.currentTimeMillis()
        for (i in order) if ((cool[ks[i]] ?: 0L) <= now) return ks[i]
        return ks[order.minByOrNull { cool[ks[it]] ?: 0L }!!]
    }

    /**
     * A key failed (websocket close / error message / HTTP code): rest it so its backup takes over.
     * `established` = the live session had already started working before it failed.
     */
    fun failed(k: String, why: String, code: Int = 0, established: Boolean = true) {
        if (k.isEmpty()) return
        val w = why.lowercase()
        when {
            code == 429 || "429" in w || "quota" in w || "exhausted" in w || "rate limit" in w || "rate_limit" in w ->
                cooldown(k, 30_000L)
            code == 400 || code == 401 || code == 403 || "api key" in w || "api_key" in w || "permission" in w ->
                cooldown(k, 10 * 60_000L)
            !established -> cooldown(k, 15_000L)
        }
    }

    /** Rest a key for a while (rate limit / quota). */
    fun cooldown(k: String, ms: Long = 30_000L) { cool[k] = System.currentTimeMillis() + ms }
    @Volatile var model = "gemini-2.5-flash-native-audio-preview-12-2025"
    /** If the chosen listening model cannot connect (retired / not allowed for the key), these are tried in turn. */
    val liveModels = listOf(
        "gemini-2.5-flash-native-audio-preview-12-2025",
        "gemini-3.1-flash-live-preview",
        "gemini-2.5-flash-native-audio-preview-09-2025"
    )
    @Volatile var speed = 1f
    @Volatile var vol = 1f
    @Volatile var thr = 0.008
    @Volatile var endMs = 600
    @Volatile var minMs = 40
    @Volatile var src = 0          // 0 = microphone, 1 = phone audio
    @Volatile var micGain = 1f
    @Volatile var mode = 0         // 0 = live translation, 1 = pack (match + pre-translated)
    @Volatile var adapt = true     // adaptive speech detection for speech over music
    @Volatile var script = ""     // reference script of the game (optional)
    @Volatile var scriptName = ""

    private val entries = ArrayList<Entry>()
    @Volatile var version = 0   // goes up whenever the list of sentences changes
    @Volatile var listener: (() -> Unit)? = null
    private val h = Handler(Looper.getMainLooper())

    fun say(s: String) {
        status = s
        changed()
    }

    fun changed() {
        h.post { listener?.invoke() }
    }

    fun addEntry(en: StringBuffer, ku: StringBuffer) {
        synchronized(entries) {
            entries.add(Entry(en, ku))
            while (entries.size > 300) entries.removeAt(0)
            version++
        }
        changed()
    }

    fun clear() {
        synchronized(entries) { entries.clear(); version++ }
        changed()
    }

    private val clock = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US)

    /** Only the Kurdish text is written (with its time); the English is not shown. */
    private fun one(e: Entry) =
        "🕒 " + synchronized(clock) { clock.format(java.util.Date(e.at)) } + "\n" + e.ku.toString().trim()

    fun text(): String = synchronized(entries) { entries.joinToString("\n\n") { one(it) } }

    /** The newest n sentences, newest first. */
    fun recent(n: Int): List<Entry> = synchronized(entries) { entries.asReversed().take(n).toList() }

    /** Newest first, used for display. */
    fun shown(): String = synchronized(entries) { entries.asReversed().take(6).joinToString("\n\n") { one(it) } }
}

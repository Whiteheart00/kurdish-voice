package com.hardi.kurdishtranslator

import android.os.Handler
import android.os.Looper

/** Shared state between the UI and the translator service. */
object Bus {
    class Entry(val en: StringBuffer, val ku: StringBuffer)

    @Volatile var running = false
    @Volatile var status = "ئامادەیە"
    @Volatile var level = 0.0

    /** Raw key text: one or more Gemini API keys separated by newline / comma / space. */
    @Volatile var key = ""
        set(v) { field = v; rr = 0 }

    private val sep = Regex("[\\s,;]+")
    private val cool = java.util.concurrent.ConcurrentHashMap<String, Long>()
    private val rrLock = Any()
    private var rr = 0

    /** All distinct keys, in the order they were typed. */
    val keys: List<String> get() = key.split(sep).filter { it.length > 10 }.distinct()

    /** Round-robin: next key that is not cooling down (after a 429). Falls back to the soonest-ready one. */
    fun nextKey(): String {
        val ks = keys
        if (ks.isEmpty()) return ""
        val now = System.currentTimeMillis()
        synchronized(rrLock) {
            for (i in ks.indices) {
                val k = ks[(rr + i) % ks.size]
                if ((cool[k] ?: 0L) <= now) {
                    rr = (rr + i + 1) % ks.size
                    return k
                }
            }
            val k = ks.minByOrNull { cool[it] ?: 0L }!!
            rr = (ks.indexOf(k) + 1) % ks.size
            return k
        }
    }

    const val LIVE = 0   // key 1: listens to English (live websocket)
    const val VOICE = 1  // key 2: Kurdish speech (TTS)
    const val TEXT = 2   // key 3: text translation + helper for both

    /**
     * Key for a job. While translating live each role has its own key (1 live, 2 voice, 3 helper);
     * a role's key that is resting (429) is replaced by the helper first, then any other key.
     * With fewer than 3 keys the roles share. When not running live (building a pack) all keys rotate.
     */
    fun keyFor(role: Int): String {
        val ks = keys
        if (ks.isEmpty()) return ""
        if (ks.size == 1 || (!running && role != LIVE)) return nextKey()
        val own = when (role) {
            LIVE -> 0
            VOICE -> 1
            else -> if (ks.size >= 3) 2 else 0
        }
        val order = ArrayList<Int>()
        order.add(own)
        if (ks.size >= 3 && own != 2) order.add(2)
        for (i in ks.indices) if (i !in order) order.add(i)
        val now = System.currentTimeMillis()
        for (i in order) if ((cool[ks[i]] ?: 0L) <= now) return ks[i]
        return ks[own]
    }

    /** Rest a key for a while (rate limit / quota). */
    fun cooldown(k: String, ms: Long = 30_000L) { cool[k] = System.currentTimeMillis() + ms }
    @Volatile var model = "gemini-2.5-flash-native-audio-preview-12-2025"
    @Volatile var speed = 1f
    @Volatile var vol = 1f
    @Volatile var thr = 0.008
    @Volatile var endMs = 600
    @Volatile var minMs = 80
    @Volatile var bufMs = 400
    @Volatile var src = 0          // 0 = microphone, 1 = phone audio
    @Volatile var micGain = 1f
    @Volatile var mute = false
    @Volatile var mode = 0         // 0 = live translation, 1 = pack (match + pre-translated)
    @Volatile var adapt = true     // adaptive speech detection for speech over music
    @Volatile var script = ""     // reference script of the game (optional)
    @Volatile var scriptName = ""

    private val entries = ArrayList<Entry>()
    @Volatile var listener: (() -> Unit)? = null
    private val h = Handler(Looper.getMainLooper())

    fun say(s: String) {
        status = s
        changed()
    }

    fun changed() {
        h.post { listener?.invoke() }
    }

    fun addEntry(en: StringBuffer, ku: StringBuffer) {
        synchronized(entries) {
            entries.add(Entry(en, ku))
            while (entries.size > 300) entries.removeAt(0)
        }
        changed()
    }

    fun clear() {
        synchronized(entries) { entries.clear() }
        changed()
    }

    private fun one(e: Entry) = "EN: " + e.en.toString().trim() + "\nKU: " + e.ku.toString().trim()

    /** Chronological text, used for copying. */
    fun text(): String = synchronized(entries) { entries.joinToString("\n\n") { one(it) } }

    /** Newest first, used for display. */
    fun shown(): String = synchronized(entries) { entries.asReversed().joinToString("\n\n") { one(it) } }
}

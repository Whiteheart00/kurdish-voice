package com.hardi.kurdishtranslator

import android.media.AudioAttributes
import android.os.Handler
import android.os.Looper

/** Shared state between the UI and the translator service. */
object Bus {
    class Entry(val en: StringBuffer, val ku: StringBuffer, val at: Long = System.currentTimeMillis(), val dir: Int = 0)

    @Volatile var running = false
    @Volatile var status = "ئامادەیە"
    @Volatile var level = 0.0

    /** Raw key text: one or more Gemini API keys separated by newline / comma / space. */
    @Volatile var key = ""
        set(v) { field = v; rr = 0 }

    private val sep = Regex("[\\s,;]+")
    private val cool = java.util.concurrent.ConcurrentHashMap<String, Long>()
    private val rrLock = Any()
    private var rr = 0

    /** All distinct keys, in the order they were typed. */
    val keys: List<String> get() = key.split(sep).filter { it.length > 10 }.distinct()

    /** Round-robin: next key that is not cooling down (after a 429). Falls back to the soonest-ready one. */
    fun nextKey(): String {
        val ks = keys
        if (ks.isEmpty()) return ""
        val now = System.currentTimeMillis()
        synchronized(rrLock) {
            for (i in ks.indices) {
                val k = ks[(rr + i) % ks.size]
                if ((cool[k] ?: 0L) <= now) {
                    rr = (rr + i + 1) % ks.size
                    return k
                }
            }
            val k = ks.minByOrNull { cool[it] ?: 0L }!!
            rr = (ks.indexOf(k) + 1) % ks.size
            return k
        }
    }

    const val TEXT = 2   // Kurdish text translation (the only job that needs the internet; listening is offline)

    /**
     * Key for an online job (text translation). Keys rotate round-robin; a resting key (429 / quota / bad key)
     * is skipped and the next one is used. With one key, every request uses it.
     */
    @Suppress("UNUSED_PARAMETER")
    fun keyFor(role: Int): String = nextKey()

    /** A key failed (HTTP code / message): rest it so the next key takes over. */
    fun failed(k: String, why: String, code: Int = 0, established: Boolean = true) {
        if (k.isEmpty()) return
        val w = why.lowercase()
        when {
            code == 429 || "429" in w || "quota" in w || "exhausted" in w || "rate limit" in w || "rate_limit" in w ->
                cooldown(k, 30_000L)
            code == 400 || code == 401 || code == 403 || "api key" in w || "api_key" in w || "permission" in w ->
                cooldown(k, 10 * 60_000L)
            !established -> cooldown(k, 15_000L)
        }
    }

    /** Rest a key for a while (rate limit / quota). */
    fun cooldown(k: String, ms: Long = 30_000L) { cool[k] = System.currentTimeMillis() + ms }
    @Volatile var paused = false    // listening is paused by the accessibility button (the app keeps running)
    @Volatile var a11yPause = true  // accessibility button = pause / resume (false = stop completely)
    @Volatile var dir = 0          // 0 = English -> Kurdish, 1 = Kurdish -> English
    @Volatile var speed = 1f
    @Volatile var vol = 1f
    @Volatile var thr = 0.008
    @Volatile var endMs = 600
    @Volatile var minMs = 40
    @Volatile var punct = true     // Whisper: send a sentence only when it ends with . ? ! (a half sentence waits for the next piece)
    @Volatile var punctWaitMs = 3500L  // how long a half sentence waits for its ending before it is sent anyway
    @Volatile var group = true     // group mode: several finished sentences are collected, translated TOGETHER and read as ONE voice
    @Volatile var groupN = 5       // group is sent as soon as it holds this many sentences
    @Volatile var groupSoloWaitMs = 2000L  // a group holding only ONE sentence waits this long for more speech before it is sent
    @Volatile var groupWaitMs = 4000L  // ...or when no new sentence came for this long (so a short group is not held back forever)
    @Volatile var src = 0          // 0 = microphone, 1 = phone audio
    @Volatile var micGain = 1f
    @Volatile var speakUntil = 0L  // the phone's own Kurdish/English voice is playing until this time (ms)
    @Volatile var minLogp = -1.0f  // Whisper: average token log-probability below this = it was guessing, the sentence is dropped
    @Volatile var minConf = 0.55f  // Vosk: average word confidence below this = not understood, the sentence is dropped
    @Volatile var mode = 0         // 0 = live translation, 1 = pack (match + pre-translated)
    @Volatile var muteOrig = true  // silence the original phone sound while translating (phone-audio source only)
    @Volatile var outPref = 0      // which phone volume the Kurdish voice uses: 0 media, 1 accessibility, 2 alarm, 3 notification
    fun usageFor(p: Int): Int = when (p) {
        1 -> AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY
        2 -> AudioAttributes.USAGE_ALARM
        3 -> AudioAttributes.USAGE_NOTIFICATION
        else -> AudioAttributes.USAGE_ASSISTANT
    }
    @Volatile var outUsage = AudioAttributes.USAGE_ASSISTANT  // how the Kurdish voice is played (ALARM while the original is muted)
    @Volatile var adapt = true     // adaptive speech detection for speech over music
    @Volatile var script = ""     // reference script of the game (optional)
    @Volatile var scriptName = ""

    private val entries = ArrayList<Entry>()
    @Volatile var version = 0   // goes up whenever the list of sentences changes
    @Volatile var listener: (() -> Unit)? = null
    private val h = Handler(Looper.getMainLooper())

    fun say(s: String) {
        status = s
        changed()
    }

    fun changed() {
        h.post { listener?.invoke() }
    }

    fun addEntry(en: StringBuffer, ku: StringBuffer, dir: Int = 0) {
        synchronized(entries) {
            entries.add(Entry(en, ku, dir = dir))
            while (entries.size > 300) entries.removeAt(0)
            version++
        }
        changed()
    }

    fun clear() {
        synchronized(entries) { entries.clear(); version++ }
        changed()
    }

    private val clock = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US)

    /** Only the Kurdish text is written (with its time); the English is not shown. */
    private fun one(e: Entry) =
        "🕒 " + synchronized(clock) { clock.format(java.util.Date(e.at)) } + "\n" + (if (e.dir == 1) e.en else e.ku).toString().trim()

    fun text(): String = synchronized(entries) { entries.joinToString("\n\n") { one(it) } }

    /** The newest n sentences, newest first. */
    fun recent(n: Int): List<Entry> = synchronized(entries) { entries.asReversed().take(n).toList() }

    /** Newest first, used for display. */
    fun shown(): String = synchronized(entries) { entries.asReversed().take(6).joinToString("\n\n") { one(it) } }
}

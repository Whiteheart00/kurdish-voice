package com.hardi.kurdishtranslator

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import kotlin.math.min
import kotlin.math.sqrt

class MainActivity : Activity() {

    private lateinit var sp: SharedPreferences
    private lateinit var keyEt: EditText
    private lateinit var btn: Button
    private lateinit var statusTv: TextView
    private lateinit var logTv: TextView
    private lateinit var meter: ProgressBar
    private val ui = Handler(Looper.getMainLooper())

    private val models = arrayOf(
        "gemini-2.5-flash-native-audio-preview-12-2025",
        "gemini-3.1-flash-live-preview",
        "gemini-2.5-flash-native-audio-preview-09-2025"
    )
    private val speedL = arrayOf("ئاسایی", "خێرا", "زۆر خێرا")
    private val speedV = floatArrayOf(1f, 1.15f, 1.3f)
    private val bufL = arrayOf("کەم — خێراترین", "ناوەند — پێشنیارکراو", "زۆر — بێ پچڕانترین")
    private val bufV = intArrayOf(200, 400, 700)
    private val segL = arrayOf("زۆر خێرا — ڕستەی کورت", "ڕێکخراو — پێشنیارکراو", "وردتر — دواکەوتنی زیاتر")
    private val segV = intArrayOf(250, 600, 1000)

    private val tick = object : Runnable {
        override fun run() {
            meter.progress = pos(Bus.level)
            meter.secondaryProgress = pos(Bus.thr)
            ui.postDelayed(this, 80)
        }
    }

    private fun pos(v: Double): Int = min(100, (sqrt(v / 0.3) * 100).toInt())
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun loadBus() {
        Bus.key = sp.getString("k", "") ?: ""
        Bus.model = models[sp.getInt("m", 0).coerceIn(0, models.size - 1)]
        Bus.speed = speedV[sp.getInt("sp", 0).coerceIn(0, 2)]
        Bus.bufMs = bufV[sp.getInt("bf", 1).coerceIn(0, 2)]
        Bus.endMs = segV[sp.getInt("sg", 1).coerceIn(0, 2)]
        Bus.vol = sp.getInt("vol", 10) / 10f
        Bus.thr = sp.getInt("thr", 8) / 1000.0
    }

    private fun putI(k: String, v: Int) {
        sp.edit().putInt(k, v).apply()
    }

    private fun saveKey() {
        val k = keyEt.text.toString().trim()
        Bus.key = k
        sp.edit().putString("k", k).apply()
    }

    private fun label(t: String): TextView {
        val v = TextView(this)
        v.text = t
        v.setTextColor(0xFFA8D8EA.toInt())
        v.textSize = 13f
        v.setPadding(0, dp(12), 0, dp(2))
        return v
    }

    private fun spinner(items: Array<String>, sel: Int, onSel: (Int) -> Unit): Spinner {
        val s = Spinner(this)
        val ad = ArrayAdapter(this, android.R.layout.simple_spinner_item, items)
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        s.adapter = ad
        s.setSelection(sel)
        s.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, position: Int, id: Long) {
                onSel(position)
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        return s
    }

    private fun slider(lo: Int, hi: Int, cur: Int, text: TextView, fmt: (Int) -> String, onCh: (Int) -> Unit): SeekBar {
        val s = SeekBar(this)
        s.max = hi - lo
        s.progress = cur - lo
        text.text = fmt(cur)
        s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + lo
                text.text = fmt(v)
                onCh(v)
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        return s
    }

    private fun smallBtn(t: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.setOnClickListener { onClick() }
        return b
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sp = getSharedPreferences("p", MODE_PRIVATE)
        loadBus()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(28), dp(16), dp(28))
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(0xFF0F2027.toInt())
        scroll.layoutDirection = View.LAYOUT_DIRECTION_RTL
        scroll.addView(root)
        setContentView(scroll)

        val title = TextView(this)
        title.text = "🎧 وەرگێڕی زیندووی کوردی"
        title.textSize = 22f
        title.setTextColor(0xFFFFFFFF.toInt())
        root.addView(title)

        statusTv = TextView(this)
        statusTv.textSize = 15f
        statusTv.setTextColor(0xFFFFD166.toInt())
        statusTv.setPadding(0, dp(10), 0, dp(6))
        root.addView(statusTv)

        meter = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        meter.max = 100
        root.addView(meter, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(12)))

        val hint = TextView(this)
        hint.text = "بار = دەنگی یاری، بەشی کاڵ = دەروازە. کاتێک بار لە دەروازە تێپەڕێت دەنگەکە دەنێردرێت."
        hint.textSize = 11f
        hint.setTextColor(0xFF8FA7B3.toInt())
        root.addView(hint)

        btn = Button(this)
        btn.textSize = 18f
        btn.setOnClickListener { toggle() }
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(64))
        lp.topMargin = dp(12)
        root.addView(btn, lp)

        // ---- settings (collapsible) ----
        val cfg = LinearLayout(this)
        cfg.orientation = LinearLayout.VERTICAL
        cfg.visibility = if (Bus.key.isEmpty()) View.VISIBLE else View.GONE

        cfg.addView(label("کلیلی Gemini (خۆڕایە لە aistudio.google.com)"))
        keyEt = EditText(this)
        keyEt.setSingleLine(true)
        keyEt.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        keyEt.hint = "API Key"
        keyEt.setText(Bus.key)
        cfg.addView(keyEt)

        cfg.addView(label("مۆدێل"))
        cfg.addView(spinner(models, sp.getInt("m", 0).coerceIn(0, models.size - 1)) {
            putI("m", it); Bus.model = models[it]
        })

        cfg.addView(label("خێرایی دەنگی کوردی"))
        cfg.addView(spinner(speedL, sp.getInt("sp", 0).coerceIn(0, 2)) {
            putI("sp", it); Bus.speed = speedV[it]
        })

        cfg.addView(label("جێگیری دەنگی کوردی (دژی پچڕان)"))
        cfg.addView(spinner(bufL, sp.getInt("bf", 1).coerceIn(0, 2)) {
            putI("bf", it); Bus.bufMs = bufV[it]
        })

        cfg.addView(label("بڕینی ڕستەکان"))
        cfg.addView(spinner(segL, sp.getInt("sg", 1).coerceIn(0, 2)) {
            putI("sg", it); Bus.endMs = segV[it]
        })

        val volTv = label("")
        cfg.addView(volTv)
        cfg.addView(slider(2, 20, sp.getInt("vol", 10), volTv, { "بەرزی دەنگی کوردی: " + (it * 10) + "%" }) {
            putI("vol", it); Bus.vol = it / 10f
        })

        val thrTv = label("")
        cfg.addView(thrTv)
        cfg.addView(slider(1, 100, sp.getInt("thr", 8), thrTv, { "دەروازەی دەنگ: " + it + " (بەرزتر = کەمتر هەستیار)" }) {
            putI("thr", it); Bus.thr = it / 1000.0
        })

        root.addView(smallBtn("⚙️ ڕێکخستنەکان") {
            cfg.visibility = if (cfg.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        })
        root.addView(cfg)

        // ---- log ----
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val copyB = smallBtn("📋 کۆپیکردنی وەرگێڕانەکان") { copyAll() }
        val clrB = smallBtn("🗑️") { Bus.clear() }
        row.addView(copyB, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(clrB, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        root.addView(row)

        logTv = TextView(this)
        logTv.textSize = 15f
        logTv.setTextColor(0xFFE8F1F5.toInt())
        logTv.setTextIsSelectable(true)
        logTv.setPadding(0, dp(10), 0, dp(10))
        root.addView(logTv)
    }

    private fun copyAll() {
        val t = Bus.text()
        if (t.isEmpty()) {
            Toast.makeText(this, "هێشتا وەرگێڕانێک نییە", Toast.LENGTH_SHORT).show()
            return
        }
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("translations", t))
        Toast.makeText(this, "✅ کۆپی کرا", Toast.LENGTH_SHORT).show()
    }

    private fun refresh() {
        statusTv.text = Bus.status
        btn.text = if (Bus.running) "⏹ وەستان" else "🎧 دەستپێکردن"
        logTv.text = Bus.shown()
    }

    override fun onResume() {
        super.onResume()
        Bus.listener = { refresh() }
        refresh()
        ui.post(tick)
    }

    override fun onPause() {
        super.onPause()
        saveKey()
        Bus.listener = null
        ui.removeCallbacks(tick)
    }

    private fun toggle() {
        if (Bus.running) {
            startService(Intent(this, TranslatorService::class.java).setAction(TranslatorService.ACTION_STOP))
            return
        }
        saveKey()
        if (Bus.key.isEmpty()) {
            Toast.makeText(this, "کلیلی Gemini بنووسە", Toast.LENGTH_LONG).show()
            return
        }
        val need = ArrayList<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.RECORD_AUDIO)
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (need.isNotEmpty()) {
            requestPermissions(need.toTypedArray(), 1)
            return
        }
        askProjection()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            askProjection()
        } else {
            Toast.makeText(this, "پێویستە ڕێگەی مایکرۆفۆن بدەیت (بۆ گرتنی دەنگی یاری)", Toast.LENGTH_LONG).show()
        }
    }

    @Suppress("DEPRECATION")
    private fun askProjection() {
        val m = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(m.createScreenCaptureIntent(), 42)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 42 && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, TranslatorService::class.java)
            i.putExtra("code", resultCode)
            i.putExtra("data", data)
            startForegroundService(i)
        } else if (requestCode == 42) {
            Toast.makeText(this, "ڕێگەی گرتنی دەنگ نەدرا", Toast.LENGTH_LONG).show()
        }
    }
}

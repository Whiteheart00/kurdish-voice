package com.hardi.kurdishtranslator

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import java.io.File
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import kotlin.math.min
import kotlin.math.sqrt

class MainActivity : Activity() {

    companion object {
        const val DEFAULT_VOICE_URL = "https://github.com/Whiteheart00/kurdish-voice/releases/download/voice/kurdish_onnx_model.zip"
    }

    private lateinit var sp: SharedPreferences
    private lateinit var keyEt: EditText
    private lateinit var statusTv: TextView
    private lateinit var logBox: LinearLayout
    private var shownVersion = -1
    private lateinit var meter: ProgressBar
    private lateinit var scriptTv: TextView
    private val ui = Handler(Looper.getMainLooper())

    private val srcL = arrayOf(
        "🎤 مایکرۆفۆن — بۆ تەلەفیزیۆن یان دەنگی دەرەوە",
        "📱 دەنگی ناو مۆبایل — یاری لەسەر هەمان مۆبایل"
    )
    private val engL = arrayOf(
        "Vosk — سووک و زیندوو (≈40MB)",
        "Whisper base.en • quantized (≈77MB)",
        "Whisper base.en • uint8 (≈183MB)"
    )
    private val engIds = arrayOf(Stt.ENGINE_VOSK, Stt.ENGINE_WQ, Stt.ENGINE_WU)
    private val speedL = arrayOf("هێواش", "ئاسایی", "کەمێک خێرا", "خێرا", "زۆر خێرا")
    private val speedV = floatArrayOf(0.85f, 1f, 1.15f, 1.3f, 1.5f)
    private val segL = arrayOf("زۆر خێرا — ڕستەی کورت", "ڕێکخراو — پێشنیارکراو", "وردتر — دواکەوتنی زیاتر")
    private val segV = intArrayOf(350, 550, 850)

    private val tick = object : Runnable {
        override fun run() {
            meter.progress = pos(Bus.level)
            meter.secondaryProgress = pos(Bus.thr)
            ui.postDelayed(this, 80)
        }
    }

    private fun pos(v: Double): Int = min(100, (sqrt(v / 0.3) * 100).toInt())
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun loadBus() {
        Bus.key = sp.getString("k", "") ?: ""
        Bus.speed = speedV[sp.getInt("sp2", 1).coerceIn(0, 4)]
        Bus.endMs = segV[sp.getInt("sg", 1).coerceIn(0, 2)]
        Bus.vol = sp.getInt("vol", 10) / 10f
        Bus.thr = sp.getInt("thr", 5) / 1000.0
        Bus.src = sp.getInt("src", 0).coerceIn(0, 1)
        Bus.dir = sp.getInt("dir", 0).coerceIn(0, 1)
        Bus.a11yPause = sp.getBoolean("ap", true)
        Bus.micGain = sp.getInt("mg", 10) / 10f
        Bus.adapt = sp.getBoolean("ad", true)
        Bus.muteOrig = sp.getBoolean("mo", true)
        Bus.outPref = sp.getInt("op", 0).coerceIn(0, 3)
        Bus.outUsage = Bus.usageFor(Bus.outPref)
        Bus.punct = sp.getBoolean("pn", true)
        Bus.filterOn = sp.getBoolean("fo", true)
        Bus.batch = sp.getBoolean("bt", false)  // کەڵەکە نەبێت
        Bus.minConf = sp.getInt("mc", 55).coerceIn(0, 95) / 100f
        Bus.minLogp = (sp.getInt("ml", 100).coerceIn(0, 200) - 200) / 100f
        Names.load(sp.getString("names", ""))
        Bus.punctWaitMs = sp.getInt("pnw", 20).coerceIn(2, 20) * 100L
        Bus.mode = 1 // listening and Kurdish voice are offline; Gemini only translates the text
        Pack.load(filesDir)
        try {
            val f = File(filesDir, "script.txt")
            Bus.script = if (f.exists()) f.readText() else ""
            Bus.scriptName = sp.getString("sn", "") ?: ""
        } catch (e: Exception) {
            Bus.script = ""
        }
    }

    private fun putI(k: String, v: Int) {
        sp.edit().putInt(k, v).apply()
    }

    private fun saveKey() {
        val k = keyEt.text.toString().trim()
        Bus.key = k
        sp.edit().putString("k", k).apply()
    }

    private fun label(t: String): TextView {
        val v = TextView(this)
        v.text = t
        v.setTextColor(0xFF9FB3C8.toInt())
        v.textSize = 12.5f
        v.setPadding(0, dp(12), 0, dp(4))
        return v
    }

    private fun spinner(items: Array<String>, sel: Int, onSel: (Int) -> Unit): Spinner {
        val s = Spinner(this)
        val ad = ArrayAdapter(this, android.R.layout.simple_spinner_item, items)
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        s.adapter = ad
        s.setSelection(sel)
        s.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, position: Int, id: Long) {
                onSel(position)
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        return s
    }

    private fun slider(lo: Int, hi: Int, cur: Int, text: TextView, fmt: (Int) -> String, onCh: (Int) -> Unit): SeekBar {
        val s = SeekBar(this)
        s.max = hi - lo
        s.progress = cur - lo
        text.text = fmt(cur)
        s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + lo
                text.text = fmt(v)
                onCh(v)
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        return s
    }

    private fun smallBtn(t: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.isAllCaps = false
        b.textSize = 13f
        b.setTextColor(0xFFE8F1FA.toInt())
        b.stateListAnimator = null
        b.background = GradientDrawable().apply {
            setColor(0xFF182B50.toInt())
            cornerRadius = dp(12).toFloat()
            setStroke(dp(1), 0xFF2A4678.toInt())
        }
        b.minWidth = 0
        b.minHeight = dp(44)
        b.setPadding(dp(10), 0, dp(10), 0)
        b.setOnClickListener { onClick() }
        return b
    }

    private lateinit var root: LinearLayout
    private lateinit var bigBtn: BigButton
    private lateinit var dot: View
    private lateinit var ioRow: LinearLayout
    private val dirL = arrayOf("🇬🇧 ئینگلیزی ← کوردی (ئۆفلاین، تەنها وەرگێڕانی دەق ئینتەرنێت)", "کوردی ← 🇬🇧 ئینگلیزی (ئینتەرنێت دەوێت)")
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    private fun fillChips() {
        ioRow.removeAllViews()
        val en = chip(R.drawable.flag_en, "English", if (Bus.dir == 0) "(input)" else "(output)", 0xFF12306A.toInt(), 0xFF2D8CFF.toInt())
        val ku = chip(R.drawable.flag_ku, "Kurdish", if (Bus.dir == 0) "(output)" else "(input)", 0xFF0F3A2C.toInt(), 0xFF22C55E.toInt())
        val arr = TextView(this)
        arr.text = "➜"
        arr.textSize = 20f
        arr.setTextColor(0xFF6EA8FF.toInt())
        arr.setPadding(dp(10), 0, dp(10), 0)
        val first = if (Bus.dir == 0) en else ku
        val second = if (Bus.dir == 0) ku else en
        ioRow.addView(first, lp(0, WRAP, 1f))
        ioRow.addView(arr)
        ioRow.addView(second, lp(0, WRAP, 1f))
    }

    /** ▶ on an English sentence: the phone's own offline English voice. */
    private fun speakEn(text: String) {
        val t = tts
        if (t != null && ttsReady) {
            t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "m")
            return
        }
        tts = TextToSpeech(applicationContext) { st ->
            if (st == TextToSpeech.SUCCESS) {
                tts?.setLanguage(java.util.Locale.US)
                ttsReady = true
                tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "m")
            } else {
                ui.post { Toast.makeText(this, "❌ دەنگی ئینگلیزیی مۆبایل بەردەست نییە", Toast.LENGTH_LONG).show() }
            }
        }
    }

    override fun onDestroy() {
        try { tts?.shutdown() } catch (e: Exception) {}
        super.onDestroy()
    }
    private lateinit var accTv: TextView
    private var autoBack = false

    private fun a11yOn(): Boolean {
        val en = android.provider.Settings.Secure.getString(contentResolver, android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return en.contains(packageName + "/" + ToggleService::class.java.name) || en.contains(packageName + "/.ToggleService")
    }

    private fun showA11y() {
        accTv.text = if (a11yOn()) "✅ Accessibility چالاکە — دوگمەی Accessibility دەستپێدەکات و دەوەستێنێت"
        else "⚠️ Accessibility چالاک نییە — دوگمەی خوارەوە دابگرە، «وەرگێڕی دەنگی کوردی» هەڵبژێرە و بیکەوە"
    }

    /** Started by the accessibility button: runs the normal start flow, then goes back to the game. */
    private fun handleAuto() {
        if (intent?.getBooleanExtra("auto", false) == true) {
            intent.removeExtra("auto")
            if (!Bus.running) {
                autoBack = true
                toggle()
            }
        }
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        setIntent(i)
        handleAuto()
    }

    private fun backToGame() {
        if (autoBack) {
            autoBack = false
            ui.postDelayed({ moveTaskToBack(true) }, 600)
        }
    }
    private lateinit var pill: LinearLayout

    private val cText = 0xFFE8F1FA.toInt()
    private val cMuted = 0xFF8CA0B8.toInt()

    private fun roundBg(color: Int, radius: Int, stroke: Int = 0): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }

    private fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)
    private val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
    private val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT

    /** A rounded dark card added to the page. */
    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(16), dp(14), dp(16), dp(16))
        c.background = roundBg(0xFF0F1B34.toInt(), 18, 0xFF1D3157.toInt())
        val l = lp(MATCH, WRAP)
        l.setMargins(0, dp(12), 0, 0)
        root.addView(c, l)
        return c
    }

    private fun cardTitle(t: String): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = 15f
        v.setTypeface(null, android.graphics.Typeface.BOLD)
        v.setTextColor(0xFFFFFFFF.toInt())
        return v
    }

    private fun boxed(v: View): View {
        val b = LinearLayout(this)
        b.setPadding(dp(6), dp(2), dp(6), dp(2))
        b.background = roundBg(0xFF132345.toInt(), 10, 0xFF2A4678.toInt())
        b.addView(v, lp(MATCH, WRAP))
        return b
    }

    private fun flag(res: Int, size: Int): ImageView {
        val i = ImageView(this)
        i.setImageResource(res)
        i.layoutParams = lp(dp(size), dp(size))
        return i
    }

    private fun chip(res: Int, name: String, sub: String, bg: Int, stroke: Int): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.gravity = Gravity.CENTER_HORIZONTAL
        c.setPadding(dp(8), dp(10), dp(8), dp(10))
        c.background = roundBg(bg, 14, stroke)
        c.addView(flag(res, 36))
        val n = TextView(this)
        n.text = name
        n.textSize = 15f
        n.setTypeface(null, android.graphics.Typeface.BOLD)
        n.setTextColor(0xFFFFFFFF.toInt())
        n.setPadding(0, dp(4), 0, 0)
        c.addView(n)
        val s = TextView(this)
        s.text = sub
        s.textSize = 11f
        s.setTextColor(cMuted)
        c.addView(s)
        return c
    }

    private fun iconBtn(t: String, onClick: () -> Unit): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = 16f
        v.gravity = Gravity.CENTER
        v.background = roundBg(0xFF182B50.toInt(), 12, 0xFF2A4678.toInt())
        v.setOnClickListener { onClick() }
        val l = lp(dp(42), dp(42))
        l.setMargins(dp(6), 0, 0, 0)
        v.layoutParams = l
        return v
    }

    private fun btnRow(vararg bs: Pair<View, Float>): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        for ((b, w) in bs) {
            val l = if (w > 0f) lp(0, WRAP, w) else lp(WRAP, WRAP)
            l.setMargins(dp(3), dp(4), dp(3), dp(4))
            r.addView(b, l)
        }
        return r
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sp = getSharedPreferences("p", MODE_PRIVATE)
        PawanTts.init(applicationContext)
        // NLLB ئۆفلاین لابرا
        if (PawanTts.configured()) PawanTts.warmUp()
        if (!Bus.running) OrigMute.restore(applicationContext)  // the phone must never stay silent after a crash
        loadBus()
        // load the Kurdish voice model in the background right away
        if (KuVoice.isInstalled(filesDir)) Thread { KuVoice.warmUp(filesDir) }.start()

        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(14), dp(26), dp(14), dp(28))
        val scroll = ScrollView(this)
        scroll.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xFF0B1630.toInt(), 0xFF050A14.toInt())
        )
        scroll.layoutDirection = View.LAYOUT_DIRECTION_RTL
        scroll.addView(root)
        val frame = FrameLayout(this)
        frame.addView(scroll, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        setupView = buildSetup()
        frame.addView(setupView, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        setupView.visibility = View.GONE
        setContentView(frame)

        // ---- header: icon, name, English -> Kurdish
        val head = card()
        val hrow = LinearLayout(this)
        hrow.orientation = LinearLayout.HORIZONTAL
        hrow.gravity = Gravity.CENTER_VERTICAL
        val ic = ImageView(this)
        ic.setImageResource(R.mipmap.ic_launcher)
        hrow.addView(ic, lp(dp(56), dp(56)))
        val tcol = LinearLayout(this)
        tcol.orientation = LinearLayout.VERTICAL
        tcol.setPadding(dp(12), 0, dp(12), 0)
        val title = TextView(this)
        title.text = "وەرگێڕی دەنگی کوردی"
        title.textSize = 21f
        title.setTypeface(null, android.graphics.Typeface.BOLD)
        title.setTextColor(0xFFFFFFFF.toInt())
        tcol.addView(title)
        val sub = TextView(this)
        sub.text = "ئینگلیزی دەبیسترێت و دەستبەجێ بە کوردی دەخوێنرێتەوە"
        sub.textSize = 11.5f
        sub.setTextColor(cMuted)
        tcol.addView(sub)
        hrow.addView(tcol, lp(0, WRAP, 1f))
        val fl = LinearLayout(this)
        fl.layoutDirection = View.LAYOUT_DIRECTION_LTR
        fl.orientation = LinearLayout.HORIZONTAL
        fl.gravity = Gravity.CENTER_VERTICAL
        fl.addView(flag(R.drawable.flag_en, 28))
        val ar = TextView(this)
        ar.text = "→"
        ar.textSize = 18f
        ar.setTextColor(cMuted)
        ar.setPadding(dp(6), 0, dp(6), 0)
        fl.addView(ar)
        fl.addView(flag(R.drawable.flag_ku, 28))
        hrow.addView(fl)
        head.addView(hrow)

        // ---- the big start / stop button and the status pill
        bigBtn = BigButton(this)
        bigBtn.setOnClickListener { toggle() }
        val blp = lp(dp(200), dp(200))
        blp.gravity = Gravity.CENTER_HORIZONTAL
        blp.topMargin = dp(14)
        root.addView(bigBtn, blp)

        pill = LinearLayout(this)
        pill.orientation = LinearLayout.HORIZONTAL
        pill.gravity = Gravity.CENTER_VERTICAL
        pill.setPadding(dp(16), dp(8), dp(16), dp(8))
        dot = View(this)
        val dl = lp(dp(10), dp(10))
        dl.marginEnd = dp(8)
        pill.addView(dot, dl)
        statusTv = TextView(this)
        statusTv.textSize = 14f
        statusTv.setTextColor(0xFFFFFFFF.toInt())
        pill.addView(statusTv, lp(WRAP, WRAP))
        val plp = lp(WRAP, WRAP)
        plp.gravity = Gravity.CENTER_HORIZONTAL
        plp.topMargin = dp(4)
        root.addView(pill, plp)

        // ---- input -> output chips and the sound level
        val io = card()
        ioRow = LinearLayout(this)
        ioRow.layoutDirection = View.LAYOUT_DIRECTION_LTR
        ioRow.orientation = LinearLayout.HORIZONTAL
        ioRow.gravity = Gravity.CENTER_VERTICAL
        fillChips()
        io.addView(ioRow)
        io.addView(label("ئاڕاستەی وەرگێڕان"))
        io.addView(boxed(spinner(dirL, Bus.dir) {
            putI("dir", it); Bus.dir = it; fillChips()
            if (Bus.running) Toast.makeText(this, "ئاڕاستەکە دوای وەستان و دەستپێکردنەوە دەگۆڕێت", Toast.LENGTH_SHORT).show()
        }))

        meter = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        meter.max = 100
        meter.progressTintList = ColorStateList.valueOf(0xFF22C55E.toInt())
        meter.secondaryProgressTintList = ColorStateList.valueOf(0xFFFFD166.toInt())
        meter.progressBackgroundTintList = ColorStateList.valueOf(0xFF1D3157.toInt())
        val mlp = lp(MATCH, dp(12))
        mlp.topMargin = dp(14)
        io.addView(meter, mlp)
        val hint = TextView(this)
        hint.text = "بار = دەنگی یاری، هێڵی زەرد = دەروازە. کاتێک بار لە دەروازە تێپەڕێت دەنگەکە دەناسرێتەوە."
        hint.textSize = 11f
        hint.setTextColor(cMuted)
        hint.setPadding(0, dp(6), 0, 0)
        io.addView(hint)
        io.addView(label("سەرچاوەی دەنگ"))
        io.addView(boxed(spinner(srcL, sp.getInt("src", 0).coerceIn(0, 1)) {
            putI("src", it); Bus.src = it
        }))

        // ---- the translations log
        val logCard = card()
        val lrow = LinearLayout(this)
        lrow.orientation = LinearLayout.HORIZONTAL
        lrow.gravity = Gravity.CENTER_VERTICAL
        lrow.addView(cardTitle("📋 تۆماری وەرگێڕان"), lp(0, WRAP, 1f))
        lrow.addView(iconBtn("📋") { copyAll() })
        lrow.addView(iconBtn("🗑") { Bus.clear() })
        logCard.addView(lrow)
        logBox = LinearLayout(this)
        logBox.orientation = LinearLayout.VERTICAL
        logBox.minimumHeight = dp(120)
        val bl = lp(MATCH, WRAP)
        bl.topMargin = dp(10)
        logCard.addView(logBox, bl)

        // ---- models (Kurdish voice + English listening)
        val mod = card()
        modCard = mod
        mod.addView(cardTitle("🧩 مۆدێلە ئۆفلاینەکان"))
        voiceTv = TextView(this)
        voiceTv.textSize = 13f
        voiceTv.setTextColor(0xFFA8D8EA.toInt())
        voiceTv.setPadding(0, dp(10), 0, dp(2))
        mod.addView(voiceTv)
        showVoice()
        kuUrlEt = EditText(this)
        kuUrlEt.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        kuUrlEt.hint = "لینکی ڕاستەوخۆی zip ی دەنگی کوردی (https://...)"
        kuUrlEt.setHintTextColor(0xFF5B6F8A.toInt())
        kuUrlEt.setTextColor(cText)
        kuUrlEt.textSize = 12f
        kuUrlEt.textDirection = View.TEXT_DIRECTION_LTR
        kuUrlEt.background = roundBg(0xFF0B1630.toInt(), 10, 0xFF2A4678.toInt())
        kuUrlEt.setPadding(dp(12), dp(8), dp(12), dp(8))
        kuUrlEt.setText(sp.getString("kuurl", DEFAULT_VOICE_URL) ?: DEFAULT_VOICE_URL)
        mod.addView(kuUrlEt, lp(MATCH, WRAP))
        mod.addView(btnRow(
            smallBtn("⬇️ داگرتنی دەنگی کوردی") { downloadVoice() } to 1f,
            smallBtn("📂 zip") { pickVoice() } to 0f
        ))
        mod.addView(btnRow(
            smallBtn("🔊 تاقیکردنەوەی دەنگی کوردی") { saveKey(); PackBuilder.testVoice(applicationContext) } to 1f
        ))
        sttTv = TextView(this)
        sttTv.textSize = 13f
        sttTv.setTextColor(0xFFA8D8EA.toInt())
        sttTv.setPadding(0, dp(10), 0, dp(2))
        mod.addView(sttTv)
        showStt()
        mod.addView(btnRow(
            smallBtn("⬇️ داگرتنی مۆدێلی گوێگرتن") { downloadStt() } to 1f,
            smallBtn("📂 zip") { pickStt() } to 0f
        ))

        // ---- English listening: Vosk or Whisper (quantized / uint8). Always visible, so it can be switched any time.
        val eng = card()
        eng.addView(cardTitle("🎧 گوێگرتنی ئینگلیزی (دەنگ ← نووسین)"))
        eng.addView(label("ئامرازی ناسینەوە"))
        eng.addView(boxed(spinner(engL, engIndex()) { i -> onEnginePicked(i) }))
        engTv = TextView(this)
        engTv.textSize = 12.5f
        engTv.setTextColor(0xFFA8D8EA.toInt())
        engTv.setPadding(0, dp(10), 0, dp(2))
        eng.addView(engTv)
        eng.addView(label("لینکی فۆڵدەری Release ی Whisper (ئەگەر ناوی Release گۆڕدرا لێرە بیگۆڕە)"))
        whUrlEt = EditText(this)
        whUrlEt.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        whUrlEt.setTextColor(cText)
        whUrlEt.textSize = 12f
        whUrlEt.textDirection = View.TEXT_DIRECTION_LTR
        whUrlEt.background = roundBg(0xFF0B1630.toInt(), 10, 0xFF2A4678.toInt())
        whUrlEt.setPadding(dp(12), dp(8), dp(12), dp(8))
        whUrlEt.setText(Stt.whisperBase(applicationContext))
        eng.addView(whUrlEt, lp(MATCH, WRAP))
        eng.addView(btnRow(
            smallBtn("⬇️ داگرتنی مۆدێلی هەڵبژێردراو") { downloadStt() } to 1f,
            smallBtn("🗑") { deleteWhisper() } to 0f
        ))
        showStt()

        // وەرگێڕانی ئۆفلاین (NLLB) لابرا — قورس و بێ سوود لەسەر مۆبایل
        // وەرگێڕان تەنها ئۆنلاین (Google / Gemini) خێراترە

        // ---- game script and pack
        val scr = card()
        scr.addView(cardTitle("📖 سکریپتی یاری (ئارەزوومەندانە)"))
        scriptTv = TextView(this)
        scriptTv.textSize = 12f
        scriptTv.setTextColor(cMuted)
        scriptTv.setPadding(0, dp(8), 0, dp(2))
        scr.addView(scriptTv)
        showScript()
        scr.addView(btnRow(
            smallBtn("📂 بارکردنی سکریپت") { pickScript() } to 1f,
            smallBtn("🗑") { clearScript() } to 0f
        ))
        scr.addView(btnRow(
            smallBtn("1️⃣ وەرگێڕان") { saveKey(); PackBuilder.translateAll(applicationContext) } to 1f,
            smallBtn("2️⃣ دەنگ") { saveKey(); PackBuilder.ttsAll(applicationContext) } to 1f,
            smallBtn("⏹") { PackBuilder.cancel = true } to 0f
        ))

        // ---- Accessibility: start / stop from anywhere
        val acc = card()
        acc.addView(cardTitle("♿ دەستپێکردن و وەستان بە Accessibility"))
        val accInfo = TextView(this)
        accInfo.text = "Accessibility ی «وەرگێڕی دەنگی کوردی» چالاک بکە، ئینجا بە دوگمەی Accessibility (یان هەردوو دوگمەی دەنگ بە درێژی) لە هەموو شوێنێکەوە دەست پێدەکات و دەوەستێت — بێ ئەوەی لە یارییەکە بچیتە دەرەوە."
        accInfo.textSize = 12f
        accInfo.setTextColor(cMuted)
        accInfo.setPadding(0, dp(8), 0, dp(2))
        acc.addView(accInfo)
        accTv = TextView(this)
        accTv.textSize = 13f
        accTv.setTextColor(0xFFA8D8EA.toInt())
        accTv.setPadding(0, dp(6), 0, dp(2))
        acc.addView(accTv)
        val apCb = CheckBox(this)
        apCb.text = "دوگمەی Accessibility = ڕاگرتن / بەردەوامبوون (ئەپەکە دەمێنێتەوە و ڕێگەپێدان دووبارە ناپرسێتەوە). ئەگەر لایبەریت = وەستانی تەواو"
        apCb.textSize = 12f
        apCb.setTextColor(0xFFA8D8EA.toInt())
        apCb.isChecked = Bus.a11yPause
        apCb.setOnCheckedChangeListener { _, checked ->
            Bus.a11yPause = checked
            sp.edit().putBoolean("ap", checked).apply()
        }
        acc.addView(apCb)
        acc.addView(btnRow(smallBtn("⚙️ کردنەوەی ڕێکخستنی Accessibility") {
            try {
                startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
            } catch (e: Exception) {
                Toast.makeText(this, "❌ " + (e.message ?: "").take(80), Toast.LENGTH_LONG).show()
            }
        } to 1f))

        // ---- settings (collapsible)
        val cfg = LinearLayout(this)
        cfg.orientation = LinearLayout.VERTICAL
        cfg.visibility = View.GONE

        cfg.addView(label("کلیلەکانی Gemini (دڵخواز — بێ کلیل Google Translate بەکاردێت، بەڵام Gemini وەرگێڕانی باشتر دەدات؛ تەنها «کوردی ← ئینگلیزی» پێویستی پێیەتی). ئینتەرنێت دەوێت. هەر کلیلێک لە دێڕێک؛ ئەگەر یەکێک quota ی تەواو بوو، ئەوی تر جێگەی دەگرێتەوە.\n(گوێگرتنی ئینگلیزی و دەنگی کوردی هەردووکیان ئۆفلاینن و کلیلیان ناوێت)"))
        keyEt = EditText(this)
        keyEt.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
            InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        keyEt.minLines = 3
        keyEt.gravity = Gravity.TOP or Gravity.START
        keyEt.hint = "API Key 1\nAPI Key 2\nAPI Key 3"
        keyEt.setHintTextColor(0xFF5B6F8A.toInt())
        keyEt.setTextColor(cText)
        keyEt.background = roundBg(0xFF0B1630.toInt(), 10, 0xFF2A4678.toInt())
        keyEt.setPadding(dp(12), dp(10), dp(12), dp(10))
        keyEt.setText(Bus.key)
        cfg.addView(keyEt)

        cfg.addView(label("خێرایی دەنگی کوردی"))
        cfg.addView(boxed(spinner(speedL, sp.getInt("sp2", 1).coerceIn(0, 4)) {
            putI("sp2", it); Bus.speed = speedV[it]
        }))

        cfg.addView(label("بڕینی ڕستەکان"))
        cfg.addView(boxed(spinner(segL, sp.getInt("sg", 1).coerceIn(0, 2)) {
            putI("sg", it); Bus.endMs = segV[it]
        }))

        val volTv = label("")
        cfg.addView(volTv)
        cfg.addView(slider(2, 20, sp.getInt("vol", 10), volTv, { "بەرزی دەنگی کوردی: " + (it * 10) + "%" }) {
            putI("vol", it); Bus.vol = it / 10f
        })

        val thrTv = label("")
        cfg.addView(thrTv)
        cfg.addView(slider(1, 100, sp.getInt("thr", 5), thrTv, { "دەروازەی دەنگ: " + it + " (بەرزتر = کەمتر هەستیار)" }) {
            putI("thr", it); Bus.thr = it / 1000.0
        })

        val mgTv = label("")
        cfg.addView(mgTv)
        cfg.addView(slider(5, 80, sp.getInt("mg", 10), mgTv, { "هەستیاری مایک: ×" + (it / 10f) + " (بۆ دۆخی مایک)" }) {
            putI("mg", it); Bus.micGain = it / 10f
        })

        val foCb = CheckBox(this)
        foCb.text = "🚫 ڕەتکردنەوەی دەنگی نادڵنیا (دەنگی ناڕوون / مۆسیقا / ئێکۆ) — چالاک"
        foCb.setTextColor(0xFFA8D8EA.toInt())
        foCb.isChecked = Bus.filterOn
        cfg.addView(foCb)

        val mcTv = label("")
        cfg.addView(mcTv)
        val mcSb = slider(0, 95, sp.getInt("mc", 55), mcTv, { "ڕەتکردنەوە (Vosk): ژێر " + it + "% دڵنیایی ڕەتدەکرێتەوە (بەرزتر = توندتر)" }) {
            putI("mc", it); Bus.minConf = it / 100f
        }
        cfg.addView(mcSb)

        val mlTv = label("")
        cfg.addView(mlTv)
        val mlSb = slider(0, 200, sp.getInt("ml", 100), mlTv, { "ڕەتکردنەوە (Whisper): ژێر " + String.format(java.util.Locale.US, "%.2f", (it - 200) / 100f) + " ڕەتدەکرێتەوە (بەرزتر = توندتر)" }) {
            putI("ml", it); Bus.minLogp = (it - 200) / 100f
        }
        cfg.addView(mlSb)

        fun applyFo(on: Boolean) {
            mcSb.isEnabled = on; mlSb.isEnabled = on
            mcTv.alpha = if (on) 1f else 0.4f; mlTv.alpha = if (on) 1f else 0.4f
            mcSb.alpha = mcTv.alpha; mlSb.alpha = mcTv.alpha
        }
        applyFo(Bus.filterOn)
        foCb.setOnCheckedChangeListener { _, checked ->
            Bus.filterOn = checked
            sp.edit().putBoolean("fo", checked).apply()
            applyFo(checked)
        }

        val adCb = CheckBox(this)
        adCb.text = "🎵 مۆسیقا لەگەڵ قسە (خۆگونجاو) — پێشنیارکراو"
        adCb.setTextColor(0xFFA8D8EA.toInt())
        adCb.isChecked = Bus.adapt
        adCb.setOnCheckedChangeListener { _, checked ->
            Bus.adapt = checked
            sp.edit().putBoolean("ad", checked).apply()
        }
        cfg.addView(adCb)

        val moCb = CheckBox(this)
        moCb.text = "🔇 دەنگی ئەسڵی مۆبایل بکوژێنەرەوە — تەنها دەنگی کوردی ببیستم (بۆ سەرچاوەی «دەنگی مۆبایل»)"
        moCb.setTextColor(0xFFA8D8EA.toInt())
        moCb.isChecked = Bus.muteOrig
        moCb.setOnCheckedChangeListener { _, checked ->
            Bus.muteOrig = checked
            sp.edit().putBoolean("mo", checked).apply()
        }
        cfg.addView(moCb)

        cfg.addView(label("🔈 دەنگی کوردی لەسەر کام دەنگی مۆبایل بێت (لە دوگمەکانی دەنگی مۆبایل بەرزی بکەرەوە)"))
        cfg.addView(spinner(arrayOf("میدیا (ئاسایی)", "Accessibility", "ئەلارم", "ئاگادارکردنەوە / زەنگ"), Bus.outPref) {
            Bus.outPref = it
            sp.edit().putInt("op", it).apply()
            if (!Bus.running) Bus.outUsage = Bus.usageFor(it)
        })

        val btCb = CheckBox(this)
        btCb.text = "📦 چەند ڕستەیەک بە یەکجار بیستران: هەموو پێکەوە وەربگێڕە و بیخوێنەرەوە (کەمێک دواتر دەست پێدەکات، بەڵام یەکجار و بەبێ پچڕان)"
        btCb.setTextColor(0xFFA8D8EA.toInt())
        btCb.isChecked = Bus.batch
        btCb.setOnCheckedChangeListener { _, checked ->
            Bus.batch = checked
            sp.edit().putBoolean("bt", checked).apply()
        }
        cfg.addView(btCb)

        val pnCb = CheckBox(this)
        pnCb.text = "✂️ ڕستە بەپێی هێما (. ? !) بنێرە: ڕستەی نیوەچڵ چاوەڕێی کۆتاییەکەی دەکات (تەنها Whisper؛ Vosk هێما نانووسێت)"
        pnCb.setTextColor(0xFFA8D8EA.toInt())
        pnCb.isChecked = Bus.punct
        pnCb.setOnCheckedChangeListener { _, checked ->
            Bus.punct = checked
            sp.edit().putBoolean("pn", checked).apply()
        }
        cfg.addView(pnCb)
        // ناوی کەس و شوێنەکانی یاری: بە دەنگ نادروست بیسترێن ڕاست دەکرێنەوە، و بە یەک شێوە بە کوردی دەنووسرێن
        cfg.addView(label("👤 ناوی کەس و شوێنەکانی یاری (هەر ناوێک لە دێڕێک)"))
        val namesEt = EditText(this)
        namesEt.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        namesEt.minLines = 4
        namesEt.gravity = Gravity.TOP or Gravity.START
        namesEt.hint = "Sasuke\nNaruto, Narooto = ناڕوتۆ\nKonoha = کۆنۆها"
        namesEt.setHintTextColor(0xFF5B6F8A.toInt())
        namesEt.setTextColor(cText)
        namesEt.background = roundBg(0xFF0B1630.toInt(), 10, 0xFF2A4678.toInt())
        namesEt.setPadding(dp(12), dp(10), dp(12), dp(10))
        namesEt.setText(sp.getString("names", ""))
        namesEt.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) {
                val v = s?.toString() ?: ""
                sp.edit().putString("names", v).apply()
                Names.load(v)
            }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
        cfg.addView(namesEt)
        cfg.addView(label("ڕێنمایی: «ناو» تەنها = ڕاستکردنەوەی بیستن. «ناو, شێوەی هەڵە = کوردی» = ئەو شێوانەش ڕاست دەکرێنەوە و بە شێوەی کوردییەکە دەنووسرێت. ناوی دیار و درێژ بنووسە؛ ناوی زۆر کورت یان وشەی ئاسایی مەنووسە (وەک King)."))

        val pwTv = label("")
        cfg.addView(pwTv)
        // 0.2 .. 2.0 چرکە، بە پێپلەی 0.1 (it = دەیەی چرکە: 2..20)
        cfg.addView(slider(2, 20, sp.getInt("pnw", 20).coerceIn(2, 20), pwTv, { "ڕستەی نیوەچڵ ئەوەندە چاوەڕێ دەکات: " + (it / 10) + "." + (it % 10) + " چرکە" }) {
            sp.edit().putInt("pnw", it).apply(); Bus.punctWaitMs = it * 100L
        })

        // دەنگی Pawan (tts.pawan.krd): خۆڕایی و خێرا؛ ئینتەرنێت دەوێت، بێ ئینتەرنێت دەنگی ئۆفلاین بەکاردێت
        val pwCb = CheckBox(this)
        pwCb.text = "🌐 دەنگی Pawan (tts.pawan.krd) — خۆڕایی و خێرا، ئینتەرنێت دەوێت (بێ ئینتەرنێت دەنگی ئۆفلاین)"
        pwCb.setTextColor(0xFFA8D8EA.toInt())
        pwCb.isChecked = sp.getBoolean("pawan", false)
        pwCb.setOnCheckedChangeListener { _, checked ->
            sp.edit().putBoolean("pawan", checked).apply()
            if (checked) {
                if (!PawanTts.hasCookie()) Toast.makeText(this, "سەرەتا «🔑 چوونەژوورەوە بۆ Pawan TTS» بگرە و بچۆ ژوورەوە", Toast.LENGTH_LONG).show()
                else PawanTts.warmUp()
            }
        }
        cfg.addView(pwCb)
        cfg.addView(label("دەنگی Pawan"))
        cfg.addView(spinner(arrayOf("ئافرەت", "پیاو"), if (sp.getString("pv", "female") == "male") 1 else 0) {
            sp.edit().putString("pv", if (it == 1) "male" else "female").apply()
        })
        cfg.addView(smallBtn("🔑 چوونەژوورەوە بۆ Pawan TTS") {
            startActivity(Intent(this, PawanLoginActivity::class.java))
        }, lp(MATCH, WRAP))

        // ڕێکخستنی دەنگی Pawan: تاقی بکەرەوە تا دەنگەکە ڕێک دەبێت (کاریگەری یەکسەر؛ دەنگەکە دووبارە دروست ناکرێتەوە)
        cfg.addView(label("🎚️ ڕێکخستنی دەنگی Pawan — «🔊 تاقیکردنەوە» بگرە و گوێ بگرە، پاشان بیگۆڕە"))
        val pgTv = label("")
        val prTv = label("")
        val psTv = label("")
        val pgSb = slider(30, 150, PawanTts.gainPct(), pgTv, { "ئاستی دەنگ: $it% (ئەگەر زۆر بەرزە دایبەزێنە)" }) { sp.edit().putInt("pw_gain", it).apply() }
        val prSb = slider(80, 120, PawanTts.ratePct(), prTv, { "تۆن/خێرایی: $it% (کەمتر = قوڵتر و هێواشتر، زیاتر = تیژتر و خێراتر)" }) { sp.edit().putInt("pw_rate", it).apply() }
        val psSb = slider(0, 100, PawanTts.softPct(), psTv, { "نەرمکردن: $it% (دەنگی تیژ/«گڕ» کەم دەکاتەوە)" }) { sp.edit().putInt("pw_soft", it).apply() }
        cfg.addView(pgTv); cfg.addView(pgSb)
        cfg.addView(prTv); cfg.addView(prSb)
        cfg.addView(psTv); cfg.addView(psSb)
        val pRow = LinearLayout(this)
        pRow.orientation = LinearLayout.HORIZONTAL
        pRow.addView(smallBtn("🔊 تاقیکردنەوە") { saveKey(); PackBuilder.testVoice(applicationContext) }, lp(0, WRAP, 1f).apply { setMargins(dp(3), dp(10), dp(3), 0) })
        pRow.addView(smallBtn("↩️ گەڕاندنەوە") {
            PawanTts.resetTuning()
            pgSb.progress = 100 - 30; prSb.progress = 100 - 80; psSb.progress = 0
        }, lp(0, WRAP, 1f).apply { setMargins(dp(3), dp(10), dp(3), 0) })
        cfg.addView(pRow, lp(MATCH, WRAP))

        val settingsCard = card()
        settingsCard.addView(smallBtn("⚙️ ڕێکخستنەکان و کلیلی Gemini") {
            cfg.visibility = if (cfg.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }, lp(MATCH, WRAP))
        settingsCard.addView(cfg)
        showA11y()
        handleAuto()
        if (needSetup()) startSetup()
    }

    private lateinit var voiceTv: TextView
    private lateinit var modCard: LinearLayout
    private lateinit var sttTv: TextView
    private lateinit var engTv: TextView
    private lateinit var whUrlEt: EditText
    private lateinit var kuUrlEt: EditText

    // ---- first-run setup screen: downloads both offline models by itself
    private lateinit var setupView: FrameLayout
    private lateinit var kuBar: ProgressBar
    private lateinit var kuSt: TextView
    private lateinit var sttBar: ProgressBar
    private lateinit var sttSt: TextView
    private lateinit var setupMsg: TextView
    private lateinit var setupBtns: LinearLayout
    private lateinit var retryBtn: Button
    private var pulse: android.animation.ValueAnimator? = null

    private fun needSetup() = (!KuVoice.isInstalled(filesDir) && !PawanTts.configured()) || !Stt.isInstalled(applicationContext)

    private fun stepRow(parent: LinearLayout, title: String): Pair<ProgressBar, TextView> {
        val t = TextView(this)
        t.text = title
        t.textSize = 15f
        t.setTypeface(null, android.graphics.Typeface.BOLD)
        t.setTextColor(0xFFFFFFFF.toInt())
        t.setPadding(0, dp(14), 0, dp(6))
        parent.addView(t)
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        bar.max = 100
        bar.progressTintList = ColorStateList.valueOf(0xFF22C55E.toInt())
        bar.progressBackgroundTintList = ColorStateList.valueOf(0xFF1D3157.toInt())
        parent.addView(bar, lp(MATCH, dp(10)))
        val st = TextView(this)
        st.textSize = 12.5f
        st.setTextColor(cMuted)
        st.setPadding(0, dp(4), 0, 0)
        parent.addView(st)
        return Pair(bar, st)
    }

    private fun buildSetup(): FrameLayout {
        val f = FrameLayout(this)
        f.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xFF0B1630.toInt(), 0xFF050A14.toInt()))
        f.layoutDirection = View.LAYOUT_DIRECTION_RTL
        f.isClickable = true   // the screen behind cannot be touched while this one is shown
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(28), dp(40), dp(28), dp(40))
        val icon = ImageView(this)
        icon.setImageResource(R.mipmap.ic_launcher)
        col.addView(icon, lp(dp(110), dp(110)))
        pulse = android.animation.ValueAnimator.ofFloat(1f, 1.1f).apply {
            duration = 900
            repeatCount = android.animation.ValueAnimator.INFINITE
            repeatMode = android.animation.ValueAnimator.REVERSE
            addUpdateListener { icon.scaleX = it.animatedValue as Float; icon.scaleY = it.animatedValue as Float }
        }
        val title = TextView(this)
        title.text = "وەرگێڕی دەنگی کوردی"
        title.textSize = 23f
        title.setTypeface(null, android.graphics.Typeface.BOLD)
        title.setTextColor(0xFFFFFFFF.toInt())
        title.setPadding(0, dp(18), 0, dp(4))
        col.addView(title)
        setupMsg = TextView(this)
        setupMsg.text = "ئامادەکردنی یەکەم جار — مۆدێلە ئۆفلاینەکان دادەبەزێن (تەنها یەک جار ئینتەرنێت دەوێت)"
        setupMsg.textSize = 13f
        setupMsg.gravity = Gravity.CENTER
        setupMsg.setTextColor(cMuted)
        col.addView(setupMsg)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(18), dp(6), dp(18), dp(18))
        box.background = roundBg(0xFF0F1B34.toInt(), 18, 0xFF1D3157.toInt())
        val bl = lp(MATCH, WRAP)
        bl.topMargin = dp(26)
        col.addView(box, bl)
        val a = stepRow(box, "🔊 دەنگی کوردی")
        kuBar = a.first; kuSt = a.second
        val b = stepRow(box, "👂 گوێگرتنی ئینگلیزی")
        sttBar = b.first; sttSt = b.second
        setupBtns = LinearLayout(this)
        setupBtns.orientation = LinearLayout.HORIZONTAL
        setupBtns.visibility = View.GONE
        retryBtn = smallBtn("🔄 دووبارە هەوڵبدەوە") { startSetup() }
        setupBtns.addView(retryBtn, lp(0, WRAP, 1f).apply { setMargins(dp(3), dp(14), dp(3), 0) })
        setupBtns.addView(smallBtn("تێپەڕاندن") { hideSetup() }, lp(0, WRAP, 1f).apply { setMargins(dp(3), dp(14), dp(3), 0) })
        col.addView(setupBtns, lp(MATCH, WRAP))
        f.addView(col, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        return f
    }

    private fun hideSetup() {
        pulse?.cancel()
        setupView.animate().alpha(0f).setDuration(450).withEndAction {
            setupView.visibility = View.GONE
            setupView.alpha = 1f
        }.start()
        showVoice(); showStt()
    }

    /** Shows the setup screen and (re)starts the background download service; the screen only watches its progress. */
    private fun startSetup() {
        setupView.alpha = 1f
        setupView.visibility = View.VISIBLE
        retryBtn.visibility = View.GONE
        setupBtns.visibility = View.VISIBLE
        setupMsg.text = "ئامادەکردنی یەکەم جار — مۆدێلە ئۆفلاینەکان دادەبەزێن (تەنها یەک جار ئینتەرنێت دەوێت)"
        pulse?.start()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        SetupService.gaveUp = false
        SetupService.start(applicationContext)
        updateSetupUi()
    }

    private fun updateSetupUi() {
        val ku = KuVoice.isInstalled(filesDir)
        val st = Stt.isInstalled(applicationContext)
        if (ku) { kuBar.progress = 100; kuSt.text = "✅ ئامادەیە" }
        else { kuBar.progress = SetupService.kuPct; kuSt.text = SetupService.kuMsg.ifEmpty { "⏳ چاوەڕێ..." } }
        if (st) { sttBar.progress = 100; sttSt.text = "✅ ئامادەیە" }
        else { sttBar.progress = SetupService.stPct; sttSt.text = SetupService.stMsg.ifEmpty { "⏳ چاوەڕێ..." } }
        showVoice(); showStt()
        if (setupView.visibility != View.VISIBLE) return
        when {
            ku && st -> {
                setupMsg.text = "✅ هەموو شتێک ئامادەیە"
                ui.postDelayed({ if (setupView.visibility == View.VISIBLE) hideSetup() }, 700)
            }
            !SetupService.running -> {
                setupMsg.text = "⚠️ داگرتن تەواو نەبوو — ئینتەرنێتەکەت بپشکنە و دووبارە هەوڵبدەوە"
                setupBtns.visibility = View.VISIBLE
                retryBtn.visibility = View.VISIBLE
            }
            else -> {
                setupMsg.text = "داگرتن بەردەوامە — دەتوانیت «تێپەڕاندن» بکەیت، لە پاشبنەما تەواو دەبێت"
                // the skip button must be visible while downloading too (before, it only appeared after a failure)
                retryBtn.visibility = View.GONE
                setupBtns.visibility = View.VISIBLE
            }
        }
    }

    private fun downloadVoice() {
        if (SetupService.running) {
            Toast.makeText(this, "داگرتنی خۆکار لە ئارادایە — چاوەڕێ بکە", Toast.LENGTH_SHORT).show()
            return
        }
        val u = kuUrlEt.text.toString().trim()
        if (!u.startsWith("http")) {
            Toast.makeText(this, "لینکی ڕاستەوخۆی zip ی دەنگی کوردی بنووسە (https://...)", Toast.LENGTH_LONG).show()
            return
        }
        sp.edit().putString("kuurl", u).apply()
        Toast.makeText(this, "داگرتن دەستی پێکرد...", Toast.LENGTH_SHORT).show()
        Thread {
            val err = KuVoice.download(applicationContext, u) { p -> ui.post { voiceTv.text = "⬇️ داگرتنی دەنگی کوردی... $p%" } }
            if (err == null) KuVoice.warmUp(filesDir)
            ui.post {
                showVoice()
                Toast.makeText(this, err ?: "مۆدێلی دەنگی کوردی هێنرا ✓", Toast.LENGTH_LONG).show()
            }
        }.start()
    }

    private fun engIndex(): Int = engIds.indexOf(Stt.engine(applicationContext)).coerceAtLeast(0)

    private fun engineName(e: String) = when (e) {
        Stt.ENGINE_WQ -> "Whisper (quantized)"
        Stt.ENGINE_WU -> "Whisper (uint8)"
        else -> "Vosk"
    }

    private fun onEnginePicked(i: Int) {
        val e = engIds[i.coerceIn(0, engIds.size - 1)]
        if (e == Stt.engine(applicationContext)) return      // the spinner also fires once at start
        Stt.setEngine(applicationContext, e)
        showStt()
        if (Bus.running) Toast.makeText(this, "ئامرازەکە دوای وەستان و دەستپێکردنەوە دەگۆڕێت", Toast.LENGTH_SHORT).show()
        else if (!Stt.isInstalled(applicationContext, e)) {
            Toast.makeText(this, "ئەم مۆدێلە هێشتا نەهێنراوە — «داگرتن» دابگرە", Toast.LENGTH_LONG).show()
        }
    }

    private fun sttStatusText(): String {
        val e = Stt.engine(applicationContext)
        val name = engineName(e)
        if (Stt.isInstalled(applicationContext)) return "✅ $name هێنراوە (ئۆفلاین)"
        if (SetupService.running) return "⬇️ $name خۆکارانە دادەبەزێت... ${SetupService.stPct}%"
        return if (Stt.isWhisper(e))
            "⚠️ $name نەهێنراوە — «داگرتن» دابگرە (${Whisper.sizeText(Stt.variantOf(e))}، تەنها جارێک ئینتەرنێت دەوێت)"
        else
            "⚠️ مۆدێلی Vosk نەهێنراوە — «داگرتن» دابگرە (تەنها جارێک ئینتەرنێت دەوێت) یان zip ی vosk-model-small-en-us-0.15 هەڵبژێرە"
    }

    private fun showStt() {
        syncModCard()
        val t = sttStatusText()
        sttTv.text = t
        if (!::engTv.isInitialized) return      // the models card is built before the listening card
        val e = Stt.engine(applicationContext)
        val note = if (Stt.isWhisper(e))
            "Whisper دوای تەواوبوونی هەر ڕستەیەک دەینووسێتەوە (نەک وشە بە وشە)، بەڵام بەگشتی ورددەکارترە."
        else
            "Vosk وشە بە وشە زیندوو دەناسێتەوە و زۆر سووکە."
        engTv.text = t + "\n" + note
    }

    private fun setSttProgress(p: Int) {
        val t = "⬇️ ${engineName(Stt.engine(applicationContext))} دادەبەزێت... $p%"
        sttTv.text = t
        if (::engTv.isInitialized) engTv.text = t
    }

    private fun downloadStt() {
        if (SetupService.running) {
            Toast.makeText(this, "داگرتنی خۆکار لە ئارادایە — چاوەڕێ بکە", Toast.LENGTH_SHORT).show()
            return
        }
        if (Stt.isInstalled(applicationContext)) {
            Toast.makeText(this, "مۆدێلەکە هەیە ✓", Toast.LENGTH_SHORT).show()
            return
        }
        if (Stt.isWhisper(Stt.engine(applicationContext))) Stt.setWhisperBase(applicationContext, whUrlEt.text.toString())
        Toast.makeText(this, "داگرتن دەستی پێکرد...", Toast.LENGTH_SHORT).show()
        Thread {
            val err = Stt.download(applicationContext) { p -> ui.post { setSttProgress(p) } }
            ui.post {
                showStt()
                Toast.makeText(this, err ?: "مۆدێلی گوێگرتن هێنرا ✓", Toast.LENGTH_LONG).show()
            }
        }.start()
    }

    /** Runs one sentence through the offline model only (no internet, no fallback) and shows the result or the real error. */
    /** Frees the space of the selected Whisper variant (the models are big). */
    private fun deleteWhisper() {
        val e = Stt.engine(applicationContext)
        if (!Stt.isWhisper(e)) {
            Toast.makeText(this, "ئەمە تەنها بۆ Whisper ـە", Toast.LENGTH_SHORT).show()
            return
        }
        if (Bus.running) {
            Toast.makeText(this, "یەکەم وەرگێڕان بوەستێنە", Toast.LENGTH_SHORT).show()
            return
        }
        Whisper.delete(filesDir, Stt.variantOf(e))
        showStt()
        Toast.makeText(this, "مۆدێلەکە سڕایەوە", Toast.LENGTH_SHORT).show()
    }

    @Suppress("DEPRECATION")
    private fun pickStt() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        startActivityForResult(i, 79)
    }

    private fun importStt(data: Intent) {
        val uris = ArrayList<Uri>()
        data.clipData?.let { c -> for (k in 0 until c.itemCount) uris.add(c.getItemAt(k).uri) }
        data.data?.let { if (!uris.contains(it)) uris.add(it) }
        if (uris.isEmpty()) return
        val eng = Stt.engine(applicationContext)
        Toast.makeText(this, "مۆدێل دەهێنرێت... (ڕەنگە چەند چرکەیەک بخایەنێت)", Toast.LENGTH_SHORT).show()
        Thread {
            // Whisper: several .onnx files + vocab.json (or a zip of them); Vosk: one zip
            val err = if (Stt.isWhisper(eng)) Whisper.importFiles(applicationContext, uris, Stt.variantOf(eng))
            else Stt.importModel(applicationContext, uris[0])
            ui.post {
                showStt()
                Toast.makeText(this, err ?: "مۆدێلی گوێگرتن هێنرا ✓", Toast.LENGTH_LONG).show()
            }
        }.start()
    }

    /** The models card is only shown while a model is missing (or still downloading). */
    private fun syncModCard() {
        modCard.visibility = if (KuVoice.isInstalled(filesDir) && Stt.isInstalled(applicationContext)) View.GONE else View.VISIBLE
    }

    private fun showVoice() {
        syncModCard()
        voiceTv.text = if (KuVoice.isInstalled(filesDir)) "✅ مۆدێلی دەنگی کوردی (ئۆفلاین) هێنراوە"
        else if (SetupService.running) "⬇️ دەنگی کوردی خۆکارانە دادەبەزێت... ${SetupService.kuPct}%"
        else "⚠️ مۆدێلی دەنگی کوردی نەهێنراوە — دوگمەی خوارەوە دابگرە و zip ی مۆدێلەکە هەڵبژێرە"
    }

    @Suppress("DEPRECATION")
    private fun pickVoice() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        startActivityForResult(i, 78)
    }

    private fun importVoice(data: Intent) {
        val uris = ArrayList<Uri>()
        data.clipData?.let { c -> for (k in 0 until c.itemCount) uris.add(c.getItemAt(k).uri) }
        data.data?.let { uris.add(it) }
        if (uris.isEmpty()) return
        Toast.makeText(this, "مۆدێل دەهێنرێت... (چەند چرکەیەک)", Toast.LENGTH_SHORT).show()
        Thread {
            val err = KuVoice.importModel(applicationContext, uris)
            if (err == null) KuVoice.warmUp(filesDir)
            ui.post {
                showVoice()
                Toast.makeText(this, err ?: "مۆدێلی دەنگی کوردی هێنرا ✓", Toast.LENGTH_LONG).show()
            }
        }.start()
    }

    private fun showScript() {
        scriptTv.text = if (Bus.script.isBlank()) "هیچ سکریپتێک نەبارکراوە"
        else "✅ " + Bus.scriptName + " — " + Bus.script.lines().size + " ڕستە"
    }

    @Suppress("DEPRECATION")
    private fun pickScript() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "text/*"
        startActivityForResult(i, 77)
    }

    private fun clearScript() {
        Bus.script = ""
        Bus.scriptName = ""
        try { File(filesDir, "script.txt").delete() } catch (e: Exception) {}
        sp.edit().remove("sn").apply()
        showScript()
    }

    private fun loadScript(u: Uri) {
        try {
            val t = contentResolver.openInputStream(u)?.bufferedReader()?.readText() ?: ""
            if (t.length > 400_000) {
                Toast.makeText(this, "سکریپتەکە زۆر گەورەیە (زیاتر لە ٤٠٠ هەزار پیت)", Toast.LENGTH_LONG).show()
                return
            }
            File(filesDir, "script.txt").writeText(t)
            val name = u.lastPathSegment?.substringAfterLast('/')?.take(40) ?: "script"
            sp.edit().putString("sn", name).apply()
            Bus.script = t
            Bus.scriptName = name
            showScript()
            Toast.makeText(this, "✅ سکریپت بارکرا — جارێکی تر دەستپێبکەرەوە", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "❌ " + (e.message ?: "").take(80), Toast.LENGTH_LONG).show()
        }
    }

    private fun copyAll() {
        val t = Bus.text()
        if (t.isEmpty()) {
            Toast.makeText(this, "هێشتا وەرگێڕانێک نییە", Toast.LENGTH_SHORT).show()
            return
        }
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("translations", t))
        Toast.makeText(this, "✅ کۆپی کرا", Toast.LENGTH_SHORT).show()
    }

    private val clock = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US)

    private fun badge(t: String, color: Int): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = 11f
        v.setTypeface(null, android.graphics.Typeface.BOLD)
        v.setTextColor(0xFFFFFFFF.toInt())
        v.gravity = Gravity.CENTER
        v.setPadding(dp(8), dp(3), dp(8), dp(3))
        v.background = roundBg(color, 8)
        v.minWidth = dp(34)
        return v
    }

    /** Rebuilds the sentence rows, but only when the list has changed. */
    private fun renderLog() {
        val v = Bus.version
        if (v == shownVersion) return
        shownVersion = v
        logBox.removeAllViews()
        val list = Bus.recent(6)
        if (list.isEmpty()) {
            val t = TextView(this)
            t.text = "هێشتا وەرگێڕانێک نییە — دەستپێکردن دابگرە و یارییەکە بکەرەوە"
            t.textSize = 13f
            t.setTextColor(cMuted)
            t.gravity = Gravity.CENTER
            t.setPadding(0, dp(28), 0, dp(28))
            logBox.addView(t, lp(MATCH, WRAP))
            return
        }
        for (e in list) {
            val ku = e.ku.toString().replace(" ⚡", "").replace(" ⏭", "").trim()
            val en = e.en.toString().trim()
            val item = LinearLayout(this)
            item.orientation = LinearLayout.VERTICAL
            item.setPadding(dp(12), dp(10), dp(12), dp(8))
            item.background = roundBg(0xFF0B1630.toInt(), 14, 0xFF1A2D52.toInt())
            // the SOURCE sentence is the small line, the TRANSLATION is the big line with the ▶ button
            val kuIsOut = e.dir == 0
            val srcText = if (kuIsOut) en else ku
            val outText = if (kuIsOut) ku else en
            if (srcText.isNotBlank()) {
                val er = LinearLayout(this)
                er.orientation = LinearLayout.HORIZONTAL
                er.gravity = Gravity.CENTER_VERTICAL
                er.addView(badge(if (kuIsOut) "EN" else "KU", if (kuIsOut) 0xFF2D8CFF.toInt() else 0xFF22C55E.toInt()))
                val et = TextView(this)
                et.text = srcText
                et.textSize = 14f
                et.setTextColor(0xFFC9D8EA.toInt())
                if (kuIsOut) et.textDirection = View.TEXT_DIRECTION_LTR
                et.setPadding(dp(10), 0, dp(10), 0)
                et.setTextIsSelectable(true)
                er.addView(et, lp(0, WRAP, 1f))
                item.addView(er)
            }
            val kr = LinearLayout(this)
            kr.orientation = LinearLayout.HORIZONTAL
            kr.gravity = Gravity.CENTER_VERTICAL
            kr.setPadding(0, dp(8), 0, dp(4))
            kr.addView(badge(if (kuIsOut) "KU" else "EN", if (kuIsOut) 0xFF22C55E.toInt() else 0xFF2D8CFF.toInt()))
            val tv = TextView(this)
            tv.text = outText
            tv.textSize = 18f
            tv.setTextColor(0xFFFFFFFF.toInt())
            if (!kuIsOut) tv.textDirection = View.TEXT_DIRECTION_LTR
            tv.setPadding(dp(10), 0, dp(10), 0)
            tv.setTextIsSelectable(true)
            kr.addView(tv, lp(0, WRAP, 1f))
            if (!outText.startsWith("⚠️")) {
                val play = TextView(this)
                play.text = "▶"
                play.textSize = 18f
                play.gravity = Gravity.CENTER
                play.setTextColor(0xFFFFFFFF.toInt())
                play.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(0xFF22A06B.toInt())
                }
                play.setOnClickListener { if (kuIsOut) playSentence(outText) else speakEn(outText) }
                kr.addView(play, lp(dp(44), dp(44)))
            }
            item.addView(kr)
            val tm = TextView(this)
            tm.text = clock.format(java.util.Date(e.at))
            tm.textSize = 11f
            tm.setTextColor(cMuted)
            item.addView(tm)
            val l = lp(MATCH, WRAP)
            l.bottomMargin = dp(8)
            logBox.addView(item, l)
        }
    }

    /** ▶ : reads this one sentence aloud (offline); the automatic reading goes on as before. */
    private fun playSentence(ku: String) {
        Thread {
            try {
                if (Gem.pawanDirect()) PawanTts.speakDirect(ku) else Gem.playManual(Gem.pcmFor(filesDir, ku))
            } catch (e: Exception) {
                ui.post { Toast.makeText(this, "❌ " + (e.message ?: "").take(100), Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    private fun refresh() {
        val st = Bus.status
        statusTv.text = st
        bigBtn.running = Bus.running
        val (bg, dc) = when {
            st.startsWith("❌") -> 0xFF3B1620.toInt() to 0xFFEF4444.toInt()
            Bus.running && (st.startsWith("✅") || st.startsWith("👂") || st.startsWith("🔤") || st.startsWith("⏱")) ->
                0xFF0F3A2C.toInt() to 0xFF22C55E.toInt()
            Bus.running -> 0xFF3A3010.toInt() to 0xFFFFD166.toInt()
            else -> 0xFF16284A.toInt() to 0xFF6EA8FF.toInt()
        }
        pill.background = roundBg(bg, 22)
        dot.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(dc) }
        renderLog()
    }

    override fun onResume() {
        super.onResume()
        Bus.listener = { refresh() }
        SetupService.listener = { updateSetupUi() }
        // هەر جارێک ئەپەکە دەکرێتەوە و مۆدێلێک کەم بوو (تەنانەت دوای «تێپەڕاندن») داگرتن خۆی بەردەوام دەبێت
        if (SetupService.missing(this) && !SetupService.running && !SetupService.gaveUp) SetupService.start(applicationContext)
        updateSetupUi()
        showA11y()
        refresh()
        ui.post(tick)
    }

    override fun onPause() {
        super.onPause()
        saveKey()
        Bus.listener = null
        SetupService.listener = null
        ui.removeCallbacks(tick)
    }

    private fun toggle() {
        if (Bus.running) {
            startService(Intent(this, TranslatorService::class.java).setAction(TranslatorService.ACTION_STOP))
            autoBack = false
            return
        }
        saveKey()
        if (Bus.keys.isEmpty() && Bus.dir == 1) {
            Toast.makeText(this, "کوردی ← ئینگلیزی کلیلی Gemini دەوێت (بۆ گوێگرتنی کوردی). ئینگلیزی ← کوردی کلیلی ناوێت", Toast.LENGTH_LONG).show()
            autoBack = false
            return
        }
        if (Bus.dir == 0 && !KuVoice.isInstalled(filesDir) && !PawanTts.configured()) {
            Toast.makeText(this, "یەکەم جار مۆدێلی دەنگی کوردی بهێنە (📥)، یان دەنگی Pawan چالاک بکە و بچۆ ژوورەوە", Toast.LENGTH_LONG).show()
            autoBack = false
            return
        }
        if (Bus.dir == 0 && !Stt.isInstalled(applicationContext)) {
            Toast.makeText(this, "یەکەم جار مۆدێلی گوێگرتنی ئینگلیزی بهێنە (⬇️)", Toast.LENGTH_LONG).show()
            autoBack = false
            return
        }
        val need = ArrayList<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.RECORD_AUDIO)
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (need.isNotEmpty()) {
            requestPermissions(need.toTypedArray(), 1)
            return
        }
        go()
    }

    private fun go() {
        if (Bus.src == 1) {
            askProjection()
        } else {
            val i = Intent(this, TranslatorService::class.java)
            i.putExtra("mic", true)
            startForegroundService(i)
            backToGame()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != 1) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            go()
        } else {
            Toast.makeText(this, "پێویستە ڕێگەی مایکرۆفۆن بدەیت (بۆ گرتنی دەنگی یاری)", Toast.LENGTH_LONG).show()
        }
    }

    @Suppress("DEPRECATION")
    private fun askProjection() {
        val m = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(m.createScreenCaptureIntent(), 42)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 78) {
            if (resultCode == RESULT_OK && data != null) importVoice(data)
            return
        }
        if (requestCode == 79) {
            if (resultCode == RESULT_OK && data != null) importStt(data)
            return
        }
        if (requestCode == 77 && resultCode == RESULT_OK && data?.data != null) {
            loadScript(data.data!!)
            return
        }
        if (requestCode == 42 && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, TranslatorService::class.java)
            i.putExtra("code", resultCode)
            i.putExtra("data", data)
            startForegroundService(i)
            backToGame()
        } else if (requestCode == 42) {
            autoBack = false
            Toast.makeText(this, "ڕێگەی گرتنی دەنگ نەدرا", Toast.LENGTH_LONG).show()
        }
    }
}

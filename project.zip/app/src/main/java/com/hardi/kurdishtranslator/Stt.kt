package com.hardi.kurdishtranslator

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Log
import okhttp3.OkHttpClient
import okhttp3.Request
import org.vosk.Model
import java.io.File
import java.util.concurrent.TimeUnit
import java.util.zip.ZipInputStream

/**
 * ناسینەوەی قسەی ئینگلیزی بە شێوەی ئۆفلاین (Vosk) — بێ ئینتەرنێت و بێ کلیل.
 * تەنها وەرگێڕانی دەق بۆ کوردی ئینتەرنێت دەوێت (Gem.translate).
 * مۆدێلی پێشنیارکراو: vosk-model-small-en-us-0.15 (نزیکەی ٤٠MB).
 */
object Stt {
    private const val TAG = "Stt"
    const val MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"

    @Volatile private var model: Model? = null
    private val lock = Any()

    fun modelDir(filesDir: File) = File(filesDir, "vosk_en")

    /** A Vosk model folder always has conf/model.conf and an "am" folder. */
    private fun valid(d: File) = File(d, "conf/model.conf").exists() && File(d, "am").isDirectory

    fun isInstalled(filesDir: File) = valid(modelDir(filesDir))

    fun reset() {
        synchronized(lock) {
            try { model?.close() } catch (_: Throwable) {}
            model = null
        }
    }

    /** Loads the model once (takes a few seconds on the first call). */
    fun load(filesDir: File): Model {
        model?.let { return it }
        synchronized(lock) {
            model?.let { return it }
            val d = modelDir(filesDir)
            if (!valid(d)) throw RuntimeException("مۆدێلی گوێگرتنی ئینگلیزی نەهێنراوە (دوگمەی «مۆدێلی گوێگرتن»)")
            val m = Model(d.absolutePath)
            model = m
            return m
        }
    }

    private fun displayName(ctx: Context, uri: Uri): String =
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0) else null
            }
        } catch (_: Exception) { null } ?: uri.lastPathSegment.orEmpty()

    /** Unpacks a model zip into [dest]; the zip's single top folder (vosk-model-.../) is stripped. */
    private fun unzip(ins: java.io.InputStream, dest: File): String? {
        val tmp = File(dest.parentFile, dest.name + ".tmp")
        tmp.deleteRecursively()
        tmp.mkdirs()
        ZipInputStream(ins.buffered()).use { zin ->
            while (true) {
                val en = zin.nextEntry ?: break
                if (en.isDirectory) continue
                val target = File(tmp, en.name)
                // zip-slip guard
                if (!target.canonicalPath.startsWith(tmp.canonicalPath + File.separator)) continue
                target.parentFile?.mkdirs()
                target.outputStream().use { zin.copyTo(it) }
            }
        }
        // find the folder that really holds conf/ and am/ (directly, or one level down)
        val root = if (valid(tmp)) tmp else tmp.listFiles()?.firstOrNull { it.isDirectory && valid(it) }
        if (root == null) {
            tmp.deleteRecursively()
            return "ئەم zip ـە مۆدێلی Vosk نییە (am/ و conf/ ی تێدا نییە)"
        }
        dest.deleteRecursively()
        if (!root.renameTo(dest)) {
            tmp.deleteRecursively()
            return "نەتوانرا مۆدێلەکە دابنرێت"
        }
        tmp.deleteRecursively()
        return null
    }

    /** Imports a Vosk model zip chosen by the user. null = ok, otherwise an error message. Call on a worker thread. */
    fun importModel(ctx: Context, uri: Uri): String? {
        reset()
        return try {
            val name = displayName(ctx, uri).lowercase()
            if (!name.endsWith(".zip")) return "zip ی مۆدێلی Vosk هەڵبژێرە ($name)"
            val ins = ctx.contentResolver.openInputStream(uri) ?: return "فایلەکە نەکرایەوە"
            ins.use { unzip(it, modelDir(ctx.filesDir)) }
        } catch (e: Throwable) {
            Log.e(TAG, "import failed", e)
            "هێنان سەرنەکەوت: ${e.message}"
        }
    }

    /** Downloads the small English model once (the only time listening needs the internet). null = ok. Call on a worker thread. */
    fun download(ctx: Context, progress: (Int) -> Unit): String? {
        reset()
        val http = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .build()
        val zip = File(ctx.cacheDir, "vosk_en.zip")
        return try {
            http.newCall(Request.Builder().url(MODEL_URL).build()).execute().use { r ->
                if (!r.isSuccessful) return "داگرتن سەرنەکەوت: HTTP " + r.code
                val body = r.body ?: return "وەڵامی بەتاڵ"
                val total = body.contentLength()
                var got = 0L
                var last = -1
                body.byteStream().use { ins ->
                    zip.outputStream().use { out ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            got += n
                            if (total > 0) {
                                val p = (got * 100 / total).toInt()
                                if (p != last) { last = p; progress(p) }
                            }
                        }
                    }
                }
            }
            zip.inputStream().use { unzip(it, modelDir(ctx.filesDir)) }
        } catch (e: Throwable) {
            Log.e(TAG, "download failed", e)
            "داگرتن سەرنەکەوت: ${e.message}"
        } finally {
            zip.delete()
        }
    }
}

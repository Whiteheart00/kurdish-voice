package com.hardi.kurdishtranslator

/**
 * Stock game shouts with a ready Kurdish line. A hit skips the text-translation request completely;
 * the Kurdish audio is cached on disk after its first use, so repeats start almost instantly.
 * Script (pack) lines always win over this list.
 */
object Callouts {
    private val map: Map<String, String> = mapOf(
        "cover me" to "پشتیوانیم بکە!",
        "reloading" to "گوللە تێدەکەم!",
        "enemy spotted" to "دوژمن بینرا!",
        "watch out" to "ئاگادار بە!",
        "take cover" to "پەنا بگرە!",
        "follow me" to "دوام بکەوە!",
        "you died" to "تۆ مردیت!",
        "quest updated" to "ئەرک نوێکرایەوە!",
        "we have to move now" to "دەبێت ئێستا بڕۆین!"
    )

    /** Kurdish line for a heard English phrase, or null when it is not a stock callout. */
    fun find(en: String): String? = map[Pack.norm(en).joinToString(" ")]
}

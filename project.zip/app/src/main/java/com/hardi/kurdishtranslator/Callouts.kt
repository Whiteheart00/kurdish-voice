package com.hardi.kurdishtranslator

/**
 * Ready Kurdish lines for stock game shouts AND everyday words (hello, thank you, bye ...).
 * A hit skips the text-translation request completely (works offline, and is instant); the Kurdish audio
 * is cached on disk after its first use, so repeats start almost at once.
 * Script (pack) lines always win over this list.
 */
object Callouts {
    private val raw: Map<String, String> = mapOf(
        // game shouts
        "cover me" to "پشتیوانیم بکە!",
        "reloading" to "گوللە تێدەکەم!",
        "enemy spotted" to "دوژمن بینرا!",
        "watch out" to "ئاگادار بە!",
        "look out" to "ئاگادار بە!",
        "be careful" to "ئاگادار بە!",
        "take cover" to "پەنا بگرە!",
        "follow me" to "دوام بکەوە!",
        "you died" to "تۆ مردیت!",
        "quest updated" to "ئەرک نوێکرایەوە!",
        "we have to move now" to "دەبێت ئێستا بڕۆین!",
        "get down" to "دابەزە!",
        "get out" to "بڕۆ دەرەوە!",
        "stay here" to "لێرە بمێنەوە.",
        "stay back" to "بگەڕێوە دواوە!",
        "behind you" to "لە پشتتەوەیە!",
        "dont move" to "مەجووڵێ!",
        "run" to "ڕابکە!",
        "go" to "بڕۆ!",
        "stop" to "بوەستە!",
        "wait" to "بوەستە.",
        "hold on" to "چاوەڕێ بە.",
        "hurry up" to "پەلە بکە!",
        "hurry" to "پەلە بکە!",
        "quickly" to "خێرا!",
        "come on" to "وەرە!",
        "lets go" to "با بڕۆین!",
        "come here" to "وەرە ئێرە.",
        "come in" to "وەرە ژوورەوە.",
        "help" to "یارمەتیم بدە!",
        "help me" to "یارمەتیم بدە!",
        "look" to "سەیر بکە.",
        "listen" to "گوێ بگرە.",
        "calm down" to "ئارام بگرە.",
        "shut up" to "بێدەنگ بە!",
        "leave me alone" to "بەجێم بهێڵە.",
        "trust me" to "متمانەم پێ بکە.",
        "dont worry" to "نیگەران مەبە.",
        // greetings / goodbyes
        "hello" to "سڵاو.",
        "hi" to "سڵاو.",
        "hey" to "هەی!",
        "hello there" to "سڵاو.",
        "hello everyone" to "سڵاو لە هەمووتان.",
        "welcome" to "بەخێربێیت.",
        "good morning" to "بەیانیت باش.",
        "good afternoon" to "نیوەڕۆت باش.",
        "good evening" to "ئێوارەت باش.",
        "good night" to "شەوت باش.",
        "bye" to "خواحافیز.",
        "bye bye" to "خواحافیز.",
        "goodbye" to "خواحافیز.",
        "see you" to "دەتبینمەوە.",
        "see you later" to "دواتر دەتبینمەوە.",
        "see you soon" to "بەم زووانە دەتبینمەوە.",
        "take care" to "ئاگات لە خۆت بێت.",
        "nice to meet you" to "دڵخۆشم بە ناسینت.",
        "how are you" to "چۆنی؟",
        "whats up" to "چی دەکەیت؟",
        "are you okay" to "باشیت؟",
        "are you ok" to "باشیت؟",
        "are you ready" to "ئامادەیت؟",
        "im ready" to "ئامادەم.",
        "im fine" to "باشم.",
        "im okay" to "باشم.",
        "im good" to "باشم.",
        "im here" to "لێرەم.",
        "im coming" to "دێم.",
        "whats your name" to "ناوت چییە؟",
        // thanks / sorry / polite
        "thank you" to "سوپاس.",
        "thanks" to "سوپاس.",
        "thank you very much" to "زۆر سوپاس.",
        "thank you so much" to "زۆر سوپاس.",
        "thanks a lot" to "زۆر سوپاس.",
        "youre welcome" to "فەرموو.",
        "please" to "تکایە.",
        "sorry" to "ببورە.",
        "im sorry" to "ببورە.",
        "excuse me" to "ببورە.",
        "no problem" to "کێشە نییە.",
        "its okay" to "کێشە نییە.",
        "never mind" to "گرنگ نییە.",
        "congratulations" to "پیرۆزە!",
        "good luck" to "بەختت یار بێت.",
        "happy birthday" to "ڕۆژی لەدایکبوونت پیرۆز بێت.",
        "well done" to "دەستخۆش!",
        "good job" to "دەستخۆش!",
        "nice" to "جوانە.",
        "great" to "نایابە!",
        "perfect" to "تەواو!",
        // yes / no / short answers
        "yes" to "بەڵێ.",
        "yeah" to "بەڵێ.",
        "no" to "نەخێر.",
        "okay" to "باشە.",
        "ok" to "باشە.",
        "alright" to "باشە.",
        "sure" to "بێگومان.",
        "of course" to "بێگومان.",
        "maybe" to "لەوانەیە.",
        "right" to "ڕاستە.",
        "exactly" to "ڕێک وایە.",
        "really" to "بەڕاستی؟",
        "me too" to "منیش.",
        "i know" to "دەزانم.",
        "i dont know" to "نازانم.",
        "i understand" to "تێدەگەم.",
        "i dont understand" to "تێناگەم.",
        "i dont care" to "گرنگ نییە بۆم.",
        "i love you" to "خۆشم دەویت.",
        "i miss you" to "بیرت دەکەم.",
        "just a moment" to "یەک خولەک.",
        "one moment" to "یەک خولەک.",
        "wait a minute" to "یەک خولەک.",
        "let me see" to "با ببینم.",
        // questions
        "what" to "چی؟",
        "why" to "بۆچی؟",
        "where" to "لە کوێ؟",
        "who" to "کێ؟",
        "how" to "چۆن؟",
        "when" to "کەی؟",
        "who are you" to "تۆ کێیت؟",
        "what do you want" to "چیت دەوێت؟",
        "what happened" to "چی ڕوویدا؟",
        "what is that" to "ئەوە چییە؟",
        "where are you going" to "بۆ کوێ دەچیت؟"
    )

    private val map: Map<String, String> by lazy { raw.mapKeys { Pack.norm(it.key).joinToString(" ") } }
    private val lead = setOf("oh", "well", "so", "hey", "yeah", "um", "uh", "ah")

    /** Kurdish line for a heard English phrase, or null when it is not a stock callout / everyday phrase. */
    fun find(en: String): String? {
        val w = Pack.norm(en)
        map[w.joinToString(" ")]?.let { return it }
        // "Oh, thank you." / "Well, okay." — a leading filler word is ignored
        if (w.size >= 2 && w[0] in lead) return map[w.drop(1).joinToString(" ")]
        return null
    }
}

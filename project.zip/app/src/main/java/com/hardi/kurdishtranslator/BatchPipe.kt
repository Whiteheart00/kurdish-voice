package com.hardi.kurdishtranslator

import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * کاتێک نووسینی ئینگلیزی دەوەستێت (چیتر ڕستەی نوێ نایەت)،
 * هەموو دواکەوتووەکان بە یەک پارچە وەردەگێڕدرێن و دەخوێنرێنەوە.
 * بلۆکی UI ی پێشوو دەمێنێتەوە (چەند دێڕ لەژێر یەک کات).
 */
object BatchPipe {
    private const val HARD_MAX = 20          // زۆرترین ڕستە لە یەک flush
    private const val TRANSLATE_CHUNK = 10   // قەبارەی داواکاری تۆڕ
    private const val PAUSE_MS = 1100L       // بێ ڕستەی نوێ = قسە وەستا

    private val lock = Any()
    private val pending = ArrayList<String>(HARD_MAX)
    private val timer = Executors.newSingleThreadScheduledExecutor()
    private var task: ScheduledFuture<*>? = null
    private val worker = Executors.newSingleThreadExecutor()
    private val alive = AtomicBoolean(true)

    /** (english lines, kurdish lines, merged speech chunks) */
    @Volatile var onBatch: ((List<String>, List<String>, List<String>) -> Unit)? = null
    @Volatile var onError: ((String) -> Unit)? = null

    fun reset() {
        synchronized(lock) {
            task?.cancel(false)
            task = null
            pending.clear()
        }
        alive.set(true)
    }

    fun stop() {
        alive.set(false)
        reset()
    }

    /** ڕستەی ئینگلیزی تەواو — تەنها دەچێتە ڕیز؛ وەرگێڕان کاتێک قسە دەوەستێت. */
    fun offer(en: String) {
        if (!alive.get()) return
        val t = en.trim()
        if (t.isEmpty()) return
        var runNow = false
        synchronized(lock) {
            pending.add(t)
            task?.cancel(false)
            if (pending.size >= HARD_MAX) {
                runNow = true
            } else {
                // هەر ڕستەیەکی نوێ تایمەر دووبارە دەکاتەوە — تەنها دوای وەستانی قسە flush
                task = timer.schedule({ flush() }, PAUSE_MS, TimeUnit.MILLISECONDS)
            }
        }
        if (runNow) flush()
    }

    /**
     * لە کۆتایی سێگمێنتی دەنگ (بێدەنگی) بانگ دەکرێت.
     * ئەگەر شتێک لە ڕیزدا بێت، زووتر flush دەکات.
     */
    fun onSpeechPause() {
        if (!alive.get()) return
        synchronized(lock) {
            if (pending.isEmpty()) return
            task?.cancel(false)
            // کەمێک چاوەڕێ بۆ ڕستەی کۆتایی STT کە هێشتا دێت
            task = timer.schedule({ flush() }, 350L, TimeUnit.MILLISECONDS)
        }
    }

    fun flush() {
        val batch: ArrayList<String>
        synchronized(lock) {
            task?.cancel(false)
            task = null
            if (pending.isEmpty()) return
            val n = minOf(pending.size, HARD_MAX)
            batch = ArrayList(pending.subList(0, n))
            pending.subList(0, n).clear()
            if (pending.isNotEmpty()) {
                task = timer.schedule({ flush() }, 60L, TimeUnit.MILLISECONDS)
            }
        }
        if (!alive.get() || batch.isEmpty()) return
        worker.execute {
            if (!alive.get()) return@execute
            try {
                val ku = translateAll(batch)
                val speech = mergeSpeech(ku)
                onBatch?.invoke(batch, ku, speech)
            } catch (e: Throwable) {
                onError?.invoke((e.message ?: e.toString()).take(140))
                try {
                    val out = batch.map { en ->
                        Callouts.find(en) ?: try {
                            Gem.translate(listOf(en))[0]
                        } catch (_: Throwable) {
                            en
                        }
                    }
                    onBatch?.invoke(batch, out, mergeSpeech(out))
                } catch (e2: Throwable) {
                    onError?.invoke((e2.message ?: e2.toString()).take(140))
                }
            }
        }
    }

    private fun translateAll(batch: List<String>): ArrayList<String> {
        val ku = ArrayList<String>(batch.size)
        val needIdx = ArrayList<Int>()
        val needEn = ArrayList<String>()
        for (i in batch.indices) {
            val local = Callouts.find(batch[i])
            if (local != null) {
                ku.add(local)
            } else {
                ku.add("")
                needIdx.add(i)
                needEn.add(batch[i])
            }
        }
        // تۆڕ: پارچەپارچە بە TRANSLATE_CHUNK، بەڵام ئەنجام یەک لیست
        var base = 0
        while (base < needEn.size) {
            val end = minOf(base + TRANSLATE_CHUNK, needEn.size)
            val slice = needEn.subList(base, end)
            val got = Gem.translate(ArrayList(slice))
            for (j in slice.indices) {
                val i = needIdx[base + j]
                val x = got.getOrNull(j)?.trim().orEmpty()
                ku[i] = if (x.isNotEmpty()) x else batch[i]
            }
            base = end
        }
        return ku
    }

    /** یەک یان چەند پارچەی درێژ بۆ TTS — کەمتر دەستپێکردن. */
    private fun mergeSpeech(kus: List<String>): List<String> {
        val out = ArrayList<String>()
        val buf = StringBuilder()
        for (raw in kus) {
            val k = raw.trim()
            if (k.isEmpty()) continue
            val nextLen = if (buf.isEmpty()) k.length else buf.length + 1 + k.length
            // بلۆکی گەورەتر: هەموو دواکەوتووەکان نزیکەی یەک خوێندنەوە
            if (buf.isNotEmpty() && (nextLen > 280 || buf.length >= 220)) {
                out.add(buf.toString())
                buf.setLength(0)
            }
            if (buf.isNotEmpty()) buf.append(' ')
            buf.append(k)
        }
        if (buf.isNotEmpty()) out.add(buf.toString())
        return if (out.isEmpty()) kus.filter { it.isNotBlank() } else out
    }
}

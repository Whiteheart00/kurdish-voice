package com.hardi.kurdishtranslator

import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Gathers consecutive lines so a 3‑minute talk is not split into 80 tiny speaks.
 * Translates in one multi-call, then returns merged speech chunks (fewer TTS starts).
 */
object BatchPipe {
    private const val MAX = 10

    private val lock = Any()
    private val pending = ArrayList<String>(MAX)
    private val timer = Executors.newSingleThreadScheduledExecutor()
    private var task: ScheduledFuture<*>? = null
    private val worker = Executors.newSingleThreadExecutor()
    private val alive = AtomicBoolean(true)

    /** (english lines for UI, kurdish lines for UI, merged kurdish chunks for TTS) */
    @Volatile var onBatch: ((List<String>, List<String>, List<String>) -> Unit)? = null
    @Volatile var onError: ((String) -> Unit)? = null

    fun reset() {
        synchronized(lock) {
            task?.cancel(false)
            task = null
            pending.clear()
        }
        alive.set(true)
    }

    fun stop() {
        alive.set(false)
        reset()
    }

    fun offer(en: String) {
        if (!alive.get()) return
        val t = en.trim()
        if (t.isEmpty()) return

        // very common short lines still go through the queue so they can merge with neighbours
        var runNow = false
        var delay = 700L
        synchronized(lock) {
            pending.add(t)
            val n = pending.size
            task?.cancel(false)
            when {
                n >= MAX -> runNow = true
                n >= 6 -> delay = 280L
                n >= 3 -> delay = 450L
                n >= 2 -> delay = 600L
                else -> delay = 750L   // wait for a second line — avoids one-word speaks
            }
            if (!runNow) {
                task = timer.schedule({ flush() }, delay, TimeUnit.MILLISECONDS)
            }
        }
        if (runNow) flush()
    }

    fun flush() {
        val batch: ArrayList<String>
        synchronized(lock) {
            task?.cancel(false)
            task = null
            if (pending.isEmpty()) return
            val n = minOf(pending.size, MAX)
            batch = ArrayList(pending.subList(0, n))
            pending.subList(0, n).clear()
            if (pending.isNotEmpty()) {
                task = timer.schedule({ flush() }, 80L, TimeUnit.MILLISECONDS)
            }
        }
        if (!alive.get() || batch.isEmpty()) return
        worker.execute {
            if (!alive.get()) return@execute
            try {
                val ku = ArrayList<String>(batch.size)
                val needIdx = ArrayList<Int>()
                val needEn = ArrayList<String>()
                for (i in batch.indices) {
                    val local = Callouts.find(batch[i])
                    if (local != null) {
                        ku.add(local)
                    } else {
                        ku.add("")
                        needIdx.add(i)
                        needEn.add(batch[i])
                    }
                }
                if (needEn.isNotEmpty()) {
                    val got = Gem.translate(needEn)
                    for (j in needIdx.indices) {
                        val i = needIdx[j]
                        val x = got.getOrNull(j)?.trim().orEmpty()
                        ku[i] = if (x.isNotEmpty()) x else batch[i]
                    }
                }
                val speech = mergeSpeech(ku)
                onBatch?.invoke(batch, ku, speech)
            } catch (e: Throwable) {
                onError?.invoke((e.message ?: e.toString()).take(140))
                try {
                    val out = batch.map { en ->
                        Callouts.find(en) ?: try {
                            Gem.translate(listOf(en))[0]
                        } catch (_: Throwable) {
                            en
                        }
                    }
                    onBatch?.invoke(batch, out, mergeSpeech(out))
                } catch (e2: Throwable) {
                    onError?.invoke((e2.message ?: e2.toString()).take(140))
                }
            }
        }
    }

    /** Join short Kurdish lines into fewer continuous utterances (~120 chars). */
    private fun mergeSpeech(kus: List<String>): List<String> {
        val out = ArrayList<String>()
        val buf = StringBuilder()
        for (raw in kus) {
            val k = raw.trim()
            if (k.isEmpty()) continue
            val nextLen = if (buf.isEmpty()) k.length else buf.length + 1 + k.length
            if (buf.isNotEmpty() && (nextLen > 130 || buf.length >= 90)) {
                out.add(buf.toString())
                buf.setLength(0)
            }
            if (buf.isNotEmpty()) buf.append(' ')
            buf.append(k)
        }
        if (buf.isNotEmpty()) out.add(buf.toString())
        return if (out.isEmpty()) kus.filter { it.isNotBlank() } else out
    }
}

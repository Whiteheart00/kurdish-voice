package com.hardi.kurdishtranslator

import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Plan: gather lines, translate only what needs the network, one multi-call (or parallel),
 * then speak in order. Lone lines flush immediately — no artificial wait.
 */
object BatchPipe {
    private const val MAX = 10

    private val lock = Any()
    private val pending = ArrayList<String>(MAX)
    private val timer = Executors.newSingleThreadScheduledExecutor()
    private var task: ScheduledFuture<*>? = null
    private val worker = Executors.newSingleThreadExecutor()
    private val alive = AtomicBoolean(true)

    @Volatile var onBatch: ((List<String>, List<String>) -> Unit)? = null
    @Volatile var onError: ((String) -> Unit)? = null

    fun reset() {
        synchronized(lock) {
            task?.cancel(false)
            task = null
            pending.clear()
        }
        alive.set(true)
    }

    fun stop() {
        alive.set(false)
        reset()
    }

    fun offer(en: String) {
        if (!alive.get()) return
        val t = en.trim()
        if (t.isEmpty()) return

        // Instant local lines never enter the network queue
        Callouts.find(t)?.let { ku ->
            onBatch?.invoke(listOf(t), listOf(ku))
            return
        }

        var runNow = false
        var delay = 0L
        synchronized(lock) {
            pending.add(t)
            val n = pending.size
            task?.cancel(false)
            when {
                n >= MAX -> runNow = true
                n >= 4 -> delay = 120L      // gather a few more quickly
                n >= 2 -> delay = 250L
                else -> runNow = true       // single line: translate NOW
            }
            if (!runNow) {
                task = timer.schedule({ flush() }, delay, TimeUnit.MILLISECONDS)
            }
        }
        if (runNow) flush()
    }

    fun flush() {
        val batch: ArrayList<String>
        synchronized(lock) {
            task?.cancel(false)
            task = null
            if (pending.isEmpty()) return
            val n = minOf(pending.size, MAX)
            batch = ArrayList(pending.subList(0, n))
            pending.subList(0, n).clear()
            if (pending.isNotEmpty()) {
                task = timer.schedule({ flush() }, 40L, TimeUnit.MILLISECONDS)
            }
        }
        if (!alive.get() || batch.isEmpty()) return
        worker.execute {
            if (!alive.get()) return@execute
            try {
                val ku = ArrayList<String>(batch.size)
                val needIdx = ArrayList<Int>()
                val needEn = ArrayList<String>()
                for (i in batch.indices) {
                    val local = Callouts.find(batch[i])
                    if (local != null) {
                        ku.add(local)
                    } else {
                        ku.add("") // placeholder
                        needIdx.add(i)
                        needEn.add(batch[i])
                    }
                }
                if (needEn.isNotEmpty()) {
                    val got = Gem.translate(needEn)
                    for (j in needIdx.indices) {
                        val i = needIdx[j]
                        val t = got.getOrNull(j)?.trim().orEmpty()
                        ku[i] = if (t.isNotEmpty()) t else batch[i]
                    }
                }
                onBatch?.invoke(batch, ku)
            } catch (e: Throwable) {
                onError?.invoke((e.message ?: e.toString()).take(140))
                try {
                    val out = batch.map { en ->
                        Callouts.find(en) ?: try {
                            Gem.translate(listOf(en))[0]
                        } catch (_: Throwable) {
                            en
                        }
                    }
                    onBatch?.invoke(batch, out)
                } catch (e2: Throwable) {
                    onError?.invoke((e2.message ?: e2.toString()).take(140))
                }
            }
        }
    }
}

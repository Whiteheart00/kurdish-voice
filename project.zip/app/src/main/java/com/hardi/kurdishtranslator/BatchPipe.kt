package com.hardi.kurdishtranslator

import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Queues finished English sentences and translates them in batches (up to 10).
 * One network round-trip for many lines → far less delay than 10 sequential calls.
 * Flushes early when only 1–2 lines so a lone sentence is not held back.
 */
object BatchPipe {
    private const val MAX = 10

    private val lock = Any()
    private val pending = ArrayList<String>(MAX)
    private val timer = Executors.newSingleThreadScheduledExecutor()
    private var task: ScheduledFuture<*>? = null
    private val worker = Executors.newSingleThreadExecutor()
    private val alive = AtomicBoolean(true)

    /** Optional hooks set by TranslatorService. */
    @Volatile var onBatch: ((List<String>, List<String>) -> Unit)? = null
    @Volatile var onError: ((String) -> Unit)? = null

    fun reset() {
        synchronized(lock) {
            task?.cancel(false)
            task = null
            pending.clear()
        }
        alive.set(true)
    }

    fun stop() {
        alive.set(false)
        reset()
    }

    fun offer(en: String) {
        if (!alive.get()) return
        val t = en.trim()
        if (t.isEmpty()) return
        var runNow = false
        var delay = 80L
        synchronized(lock) {
            pending.add(t)
            val n = pending.size
            task?.cancel(false)
            when {
                n >= MAX -> runNow = true
                n >= 5 -> delay = 180L
                n >= 2 -> delay = 320L
                else -> delay = 60L   // alone: almost immediate
            }
            if (!runNow) {
                task = timer.schedule({ flush() }, delay, TimeUnit.MILLISECONDS)
            }
        }
        if (runNow) flush()
    }

    fun flush() {
        val batch: ArrayList<String>
        synchronized(lock) {
            task?.cancel(false)
            task = null
            if (pending.isEmpty()) return
            val n = minOf(pending.size, MAX)
            batch = ArrayList(pending.subList(0, n))
            pending.subList(0, n).clear()
            // more waiting: schedule another flush soon
            if (pending.isNotEmpty()) {
                task = timer.schedule({ flush() }, 50L, TimeUnit.MILLISECONDS)
            }
        }
        if (!alive.get() || batch.isEmpty()) return
        worker.execute {
            if (!alive.get()) return@execute
            try {
                val ku = Gem.translate(batch)
                val out = ArrayList<String>(batch.size)
                for (i in batch.indices) {
                    val k = ku.getOrNull(i)?.trim().orEmpty()
                    out.add(if (k.isNotEmpty()) k else batch[i])
                }
                onBatch?.invoke(batch, out)
            } catch (e: Throwable) {
                onError?.invoke((e.message ?: e.toString()).take(140))
                // fallback: one-by-one so nothing is lost
                try {
                    val out = batch.map { en ->
                        try { Gem.translate(listOf(en))[0] } catch (_: Throwable) { en }
                    }
                    onBatch?.invoke(batch, out)
                } catch (e2: Throwable) {
                    onError?.invoke((e2.message ?: e2.toString()).take(140))
                }
            }
        }
    }
}

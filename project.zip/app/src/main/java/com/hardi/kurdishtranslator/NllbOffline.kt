package com.hardi.kurdishtranslator

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import android.content.Context
import android.util.JsonReader
import android.util.JsonToken
import android.util.Log
import java.io.File
import java.io.InputStreamReader
import java.nio.FloatBuffer
import java.nio.LongBuffer
import java.text.Normalizer

/**
 * وەرگێڕانی ئینگلیزی ← کوردی (سۆرانی) بە شێوەی ئۆفلاین، بە NLLB-200-distilled-600M (ONNX).
 *
 * فایلەکان لە GitHub Release دادەبەزن (ناوەکان وەک خۆیان، لە Xenova/nllb-200-distilled-600M):
 *   tokenizer.json
 *   encoder_model_quantized.onnx
 *   decoder_model_merged_quantized.onnx      (decoder ی KV-cache دار)
 *
 * پایپلاین: دەق → Unigram tokenizer → [eng_Latn] + ids + </s> → encoder → decoder (greedy، کۆدی ckb_Arab بە زۆر) → دەق.
 * هەموو شتێک لەسەر مۆبایلەکەیە؛ تەنها داگرتنی یەکەم جار ئینتەرنێت دەوێت.
 */
object NllbOffline {
    private const val TAG = "NllbOffline"

    private const val SRC_LANG = "eng_Latn"
    private const val TGT_LANG = "ckb_Arab"
    private const val EOS = 2L
    private const val PAD = 0
    private const val UNK_FALLBACK = 3

    private const val TOK_MIN = 3_000_000L
    private const val ENC_MIN = 100_000_000L
    private const val DEC_MIN = 100_000_000L

    const val DEFAULT_BASE = "https://github.com/Whiteheart00/kurdish-voice/releases/download/nllb/"
    private const val PREF_ON = "nllb_on"
    private const val PREF_BASE = "nllb_base"

    private lateinit var appCtx: Context
    private val lock = Any()

    fun init(ctx: Context) {
        if (!::appCtx.isInitialized) appCtx = ctx.applicationContext
    }

    private fun prefs() = appCtx.getSharedPreferences("p", Context.MODE_PRIVATE)

    // ---------------------------------------------------------------- files / settings

    fun dir(filesDir: File) = File(filesDir, "nllb_en_ku")
    private fun tokFile(f: File) = File(dir(f), "tokenizer.json")
    private fun encFile(f: File) = File(dir(f), "encoder.onnx")
    private fun decFile(f: File) = File(dir(f), "decoder.onnx")

    fun isInstalled(filesDir: File): Boolean =
        tokFile(filesDir).length() >= TOK_MIN && encFile(filesDir).length() >= ENC_MIN && decFile(filesDir).length() >= DEC_MIN

    fun sizeText() = "≈900MB"

    var enabled: Boolean
        get() = ::appCtx.isInitialized && prefs().getBoolean(PREF_ON, false)
        set(v) { if (::appCtx.isInitialized) prefs().edit().putBoolean(PREF_ON, v).apply() }

    fun base(): String =
        (prefs().getString(PREF_BASE, DEFAULT_BASE) ?: DEFAULT_BASE).ifBlank { DEFAULT_BASE }

    fun setBase(url: String) {
        prefs().edit().putString(PREF_BASE, url.trim()).apply()
    }

    /** true = دەکرێت بەکاربهێنرێت (چالاکە + مۆدێل هەیە). */
    fun ready(): Boolean = enabled && isInstalled(appCtx.filesDir)

    // ---------------------------------------------------------------- download

    /** null = ok، ئەگینا پەیامی هەڵە. لەسەر thread ی کارکەر بانگی بکە. هەموو فایلێک دوای پچڕان بەردەوام دەبێت. */
    fun download(filesDir: File, progress: (Int) -> Unit): String? {
        reset()
        val b = base().let { if (it.endsWith("/")) it else "$it/" }
        if (!b.startsWith("http")) return "لینکی Release دروست نییە (دەبێت https://... بێت)"

        class Item(val remote: String, val dest: File, val min: Long, val weight: Int)

        val items = listOf(
            Item("tokenizer.json", tokFile(filesDir), TOK_MIN, 1),
            Item("encoder_model_quantized.onnx", encFile(filesDir), ENC_MIN, 45),
            Item("decoder_model_merged_quantized.onnx", decFile(filesDir), DEC_MIN, 54)
        )
        val total = items.sumOf { it.weight }
        var done = 0
        val dl = Downloader.dir(filesDir)
        for (item in items) {
            if (item.dest.length() >= item.min) {
                done += item.weight
                progress(done * 100 / total)
                continue
            }
            val part = File(dl, "nllb_${item.remote}.part")
            val done0 = done
            Downloader.fetch(part, b + item.remote) { p ->
                progress((done0 + item.weight * p / 100) * 100 / total)
            }?.let { e -> return "${item.remote}: $e" }
            if (part.length() < item.min) {
                part.delete()
                return "${item.remote}: فایلەکە ناتەواوە یان هەڵەیە — ناوی فایل و Release بپشکنە"
            }
            item.dest.parentFile?.mkdirs()
            item.dest.delete()
            if (!part.renameTo(item.dest)) {
                try {
                    part.copyTo(item.dest, overwrite = true)
                    part.delete()
                } catch (e: Throwable) {
                    return "نەتوانرا ${item.remote} دابنرێت: ${e.message}"
                }
            }
            done += item.weight
            progress(done * 100 / total)
        }
        return null
    }

    fun delete(filesDir: File) {
        reset()
        dir(filesDir).deleteRecursively()
    }

    // ---------------------------------------------------------------- engine

    private class Engine(
        val env: OrtEnvironment,
        val enc: OrtSession,
        val dec: OrtSession,
        val tok: Tok
    )

    private var engine: Engine? = null

    fun reset() {
        synchronized(lock) {
            engine?.let {
                try { it.enc.close() } catch (_: Throwable) {}
                try { it.dec.close() } catch (_: Throwable) {}
            }
            engine = null
        }
    }

    private fun load(filesDir: File): Engine {
        engine?.let { return it }
        if (!isInstalled(filesDir)) throw IllegalStateException("مۆدێلی وەرگێڕانی ئۆفلاین نەهێنراوە")
        val tok = Tok.load(tokFile(filesDir))
        val env = OrtEnvironment.getEnvironment()
        val threads = Runtime.getRuntime().availableProcessors().coerceIn(2, 4)
        val opts = OrtSession.SessionOptions().apply { setIntraOpNumThreads(threads) }
        val enc = env.createSession(encFile(filesDir).absolutePath, opts)
        val dec = env.createSession(decFile(filesDir).absolutePath, opts)
        return Engine(env, enc, dec, tok).also { engine = it }
    }

    /** مۆدێلەکە لە پاشبنەما بار دەکات تا یەکەم وەرگێڕان خێرا بێت. */
    fun warmUp(filesDir: File) {
        try { synchronized(lock) { load(filesDir) } } catch (e: Throwable) { Log.w(TAG, "warmUp: " + e.message) }
    }

    /** English -> Sorani. هەڵە فڕێدەدات ئەگەر مۆدێل نەبوو؛ Gem.translate دەگەڕێتەوە سەر ئۆنلاین. */
    fun enToKu(text: String): String {
        val t = text.trim()
        if (t.isEmpty()) return ""
        synchronized(lock) {
            val e = load(appCtx.filesDir)
            val ids = e.tok.encode(t)
            val src = LongArray(ids.size + 2)
            src[0] = e.tok.idOf(SRC_LANG).toLong()
            for (i in ids.indices) src[i + 1] = ids[i].toLong()
            src[src.size - 1] = EOS
            val tgt = e.tok.idOf(TGT_LANG)
            val outIds = generate(e, src, tgt)
            return e.tok.decode(outIds).trim()
        }
    }

    // ---------------------------------------------------------------- seq2seq (greedy, KV cache)

    private fun generate(e: Engine, src: LongArray, tgtLang: Int): List<Int> {
        val env = e.env
        val n = src.size
        val maxNew = minOf(256, n * 2 + 12)
        val toClose = ArrayList<AutoCloseable>()
        try {
            val idsT = OnnxTensor.createTensor(env, LongBuffer.wrap(src), longArrayOf(1, n.toLong())).also { toClose += it }
            val maskT = OnnxTensor.createTensor(env, LongBuffer.wrap(LongArray(n) { 1L }), longArrayOf(1, n.toLong())).also { toClose += it }

            val encIn = HashMap<String, OnnxTensor>()
            encIn["input_ids"] = idsT
            if ("attention_mask" in e.enc.inputNames) encIn["attention_mask"] = maskT
            val encRes = e.enc.run(encIn).also { toClose += it }
            val hidden = encRes[0] as OnnxTensor

            // past_key_values.* inputs  <->  present.* outputs
            val pastNames = e.dec.inputNames.filter { it.startsWith("past_key_values.") }
            val pastDecoder = HashMap<String, OnnxTensor>()
            val pastEncoder = HashMap<String, OnnxTensor>()
            for (name in pastNames) {
                val shape = (e.dec.inputInfo[name]!!.info as TensorInfo).shape
                val heads = if (shape.size > 1 && shape[1] > 0) shape[1] else 16L
                val dim = if (shape.size > 3 && shape[3] > 0) shape[3] else 64L
                val empty = OnnxTensor.createTensor(env, FloatBuffer.allocate(0), longArrayOf(1, heads, 0, dim))
                if (".encoder." in name) pastEncoder[name] = empty else pastDecoder[name] = empty
            }
            toClose += AutoCloseable { (pastDecoder.values + pastEncoder.values).forEach { try { it.close() } catch (_: Throwable) {} } }

            val result = ArrayList<Int>()
            var cur = longArrayOf(EOS, tgtLang.toLong())      // decoder start + forced target language
            var first = true
            var same = 0
            var lastTok = -1
            for (step in 0 until maxNew) {
                val stepClose = ArrayList<AutoCloseable>()
                try {
                    val curT = OnnxTensor.createTensor(env, LongBuffer.wrap(cur), longArrayOf(1, cur.size.toLong())).also { stepClose += it }
                    val din = HashMap<String, OnnxTensor>()
                    din["input_ids"] = curT
                    if ("encoder_attention_mask" in e.dec.inputNames) din["encoder_attention_mask"] = maskT
                    din["encoder_hidden_states"] = hidden
                    if ("use_cache_branch" in e.dec.inputNames) {
                        din["use_cache_branch"] = OnnxTensor.createTensor(env, booleanArrayOf(!first)).also { stepClose += it }
                    }
                    din.putAll(pastDecoder)
                    din.putAll(pastEncoder)

                    val r = e.dec.run(din).also { stepClose += it }
                    val logits = r["logits"].orElse(null) as? OnnxTensor ?: (r[0] as OnnxTensor)
                    val shape = (logits.info as TensorInfo).shape       // [1, len, vocab]
                    val vocab = shape[2].toInt()
                    val len = shape[1].toInt()
                    val fb = logits.floatBuffer
                    val base = (len - 1) * vocab
                    var best = -1
                    var bv = Float.NEGATIVE_INFINITY
                    for (i in 0 until vocab) {
                        if (i == PAD || i == UNK_FALLBACK) continue
                        val v = fb.get(base + i)
                        if (v > bv) { bv = v; best = i }
                    }
                    if (best < 0 || best.toLong() == EOS) break
                    result += best
                    if (best == lastTok) same++ else { same = 0; lastTok = best }
                    if (same >= 4) break                                  // stuck repeating

                    // keep the new decoder KV; the encoder KV is computed once (first step)
                    for (name in pastNames) {
                        val isEnc = ".encoder." in name
                        if (isEnc && !first) continue
                        val outName = "present." + name.removePrefix("past_key_values.")
                        val t = r[outName].orElse(null) as? OnnxTensor ?: continue
                        val src2 = t.floatBuffer
                        val copy = FloatArray(src2.remaining())
                        src2.get(copy)
                        val nt = OnnxTensor.createTensor(env, FloatBuffer.wrap(copy), (t.info as TensorInfo).shape)
                        val map = if (isEnc) pastEncoder else pastDecoder
                        map[name]?.let { try { it.close() } catch (_: Throwable) {} }
                        map[name] = nt
                    }
                    // merged decoder (KV cache): feed only the new token; plain decoder (no past inputs): feed the whole sequence
                    cur = if (pastNames.isEmpty()) cur + best.toLong() else longArrayOf(best.toLong())
                    first = false
                } finally {
                    stepClose.forEach { try { it.close() } catch (_: Throwable) {} }
                }
            }
            return result
        } finally {
            toClose.forEach { try { it.close() } catch (_: Throwable) {} }
        }
    }

    // ---------------------------------------------------------------- tokenizer (SentencePiece Unigram, read from tokenizer.json)

    private class Tok(
        val pieces: Array<String>,
        val scores: FloatArray,
        val index: HashMap<String, Int>,
        val special: HashMap<String, Int>,
        val unkId: Int,
        val maxLen: Int
    ) {
        private val unkScore = (scores.minOrNull() ?: -10f) - 10f
        private val specialIds = HashSet<Int>(special.values)

        fun idOf(token: String): Int = special[token] ?: index[token] ?: unkId

        fun encode(raw: String): IntArray {
            val norm = Normalizer.normalize(raw, Normalizer.Form.NFKC).trim().replace(Regex("\\s+"), " ")
            if (norm.isEmpty()) return IntArray(0)
            val s = "▁" + norm.replace(' ', '▁')
            val n = s.length
            val best = FloatArray(n + 1) { Float.NEGATIVE_INFINITY }
            val from = IntArray(n + 1)
            val pid = IntArray(n + 1)
            best[0] = 0f
            for (i in 0 until n) {
                if (best[i] == Float.NEGATIVE_INFINITY) continue
                val top = minOf(maxLen, n - i)
                for (l in 1..top) {
                    val id = index[s.substring(i, i + l)] ?: continue
                    val sc = best[i] + scores[id]
                    if (sc > best[i + l]) { best[i + l] = sc; from[i + l] = i; pid[i + l] = id }
                }
                val su = best[i] + unkScore                    // unknown single character
                if (su > best[i + 1]) { best[i + 1] = su; from[i + 1] = i; pid[i + 1] = unkId }
            }
            val out = ArrayList<Int>()
            var p = n
            while (p > 0) { out += pid[p]; p = from[p] }
            out.reverse()
            return out.toIntArray()
        }

        fun decode(ids: List<Int>): String {
            val sb = StringBuilder()
            for (id in ids) {
                if (id in specialIds || id == unkId || id < 0 || id >= pieces.size) continue
                sb.append(pieces[id])
            }
            return sb.toString().replace('▁', ' ')
        }

        companion object {
            /** Streams tokenizer.json (≈17MB) with JsonReader, so it does not need a huge in-memory JSON tree. */
            fun load(f: File): Tok {
                val pieces = ArrayList<String>(262_144)
                val scores = ArrayList<Float>(262_144)
                val special = HashMap<String, Int>()
                var unk = UNK_FALLBACK
                JsonReader(InputStreamReader(f.inputStream().buffered(), Charsets.UTF_8)).use { r ->
                    r.beginObject()
                    while (r.hasNext()) {
                        when (r.nextName()) {
                            "added_tokens" -> {
                                r.beginArray()
                                while (r.hasNext()) {
                                    var id = -1
                                    var content = ""
                                    r.beginObject()
                                    while (r.hasNext()) {
                                        when (r.nextName()) {
                                            "id" -> id = r.nextInt()
                                            "content" -> content = r.nextString()
                                            else -> r.skipValue()
                                        }
                                    }
                                    r.endObject()
                                    if (id >= 0 && content.isNotEmpty()) special[content] = id
                                }
                                r.endArray()
                            }
                            "model" -> {
                                r.beginObject()
                                while (r.hasNext()) {
                                    when (r.nextName()) {
                                        "unk_id" -> if (r.peek() == JsonToken.NULL) r.nextNull() else unk = r.nextInt()
                                        "vocab" -> {
                                            r.beginArray()
                                            while (r.hasNext()) {
                                                r.beginArray()
                                                pieces += r.nextString()
                                                scores += r.nextDouble().toFloat()
                                                r.endArray()
                                            }
                                            r.endArray()
                                        }
                                        else -> r.skipValue()
                                    }
                                }
                                r.endObject()
                            }
                            else -> r.skipValue()
                        }
                    }
                    r.endObject()
                }
                if (pieces.isEmpty()) throw IllegalStateException("tokenizer.json بەتاڵە یان جۆری Unigram نییە")
                val index = HashMap<String, Int>(pieces.size * 2)
                var maxLen = 1
                for (i in pieces.indices) {
                    // control tokens (<s>, </s>, <pad>, <unk>, language codes) must never be matched inside normal text
                    if (i < 4) continue
                    index[pieces[i]] = i
                    if (pieces[i].length > maxLen) maxLen = pieces[i].length
                }
                return Tok(pieces.toTypedArray(), scores.toFloatArray(), index, special, unk, minOf(maxLen, 40))
            }
        }
    }
}

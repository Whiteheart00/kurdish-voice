package com.hardi.kurdishtranslator

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import android.content.Context
import android.util.JsonReader
import android.util.JsonToken
import android.util.Log
import java.io.File
import java.io.InputStreamReader
import java.nio.FloatBuffer
import java.nio.LongBuffer
import java.text.Normalizer

/**
 * وەرگێڕانی ئینگلیزی ← کوردی (سۆرانی) بە شێوەی ئۆفلاین، بە NLLB-200-distilled-600M (ONNX).
 *
 * فایلەکان لە GitHub Release دادەبەزن (ناوەکان وەک خۆیان، لە Xenova/nllb-200-distilled-600M):
 *   tokenizer.json
 *   encoder_model_quantized.onnx
 *   decoder_model_merged_quantized.onnx      (decoder ی KV-cache دار)
 *
 * پایپلاین: دەق → Unigram tokenizer → [eng_Latn] + ids + </s> → encoder → decoder (greedy، کۆدی ckb_Arab بە زۆر) → دەق.
 * هەموو شتێک لەسەر مۆبایلەکەیە؛ تەنها داگرتنی یەکەم جار ئینتەرنێت دەوێت.
 */
object NllbOffline {
    private const val TAG = "NllbOffline"

    private const val SRC_LANG = "eng_Latn"
    private const val TGT_LANG = "ckb_Arab"
    private const val EOS = 2L
    private const val PAD = 0
    private const val UNK_FALLBACK = 3

    private const val TOK_MIN = 3_000_000L
    private const val ENC_MIN = 100_000_000L
    private const val DEC_MIN = 100_000_000L

    const val DEFAULT_BASE = "https://github.com/Whiteheart00/kurdish-voice/releases/download/nllb/"
    private const val PREF_ON = "nllb_on"
    private const val PREF_BASE = "nllb_base"

    private lateinit var appCtx: Context
    private val lock = Any()

    fun init(ctx: Context) {
        if (!::appCtx.isInitialized) appCtx = ctx.applicationContext
    }

    private fun prefs() = appCtx.getSharedPreferences("p", Context.MODE_PRIVATE)

    // ---------------------------------------------------------------- files / settings

    fun dir(filesDir: File) = File(filesDir, "nllb_en_ku")
    private fun tokFile(f: File) = File(dir(f), "tokenizer.json")
    private fun encFile(f: File) = File(dir(f), "encoder.onnx")
    private fun decFile(f: File) = File(dir(f), "decoder.onnx")

    fun isInstalled(filesDir: File): Boolean =
        tokFile(filesDir).length() >= TOK_MIN && encFile(filesDir).length() >= ENC_MIN && decFile(filesDir).length() >= DEC_MIN

    fun sizeText() = "≈900MB"

    var enabled: Boolean
        get() = ::appCtx.isInitialized && prefs().getBoolean(PREF_ON, false)
        set(v) { if (::appCtx.isInitialized) prefs().edit().putBoolean(PREF_ON, v).apply() }

    fun base(): String =
        (prefs().getString(PREF_BASE, DEFAULT_BASE) ?: DEFAULT_BASE).ifBlank { DEFAULT_BASE }

    fun setBase(url: String) {
        prefs().edit().putString(PREF_BASE, url.trim()).apply()
    }

    /** true = دەکرێت بەکاربهێنرێت (چالاکە + مۆدێل هەیە). */
    fun ready(): Boolean = enabled && isInstalled(appCtx.filesDir)

    // ---------------------------------------------------------------- download

    /** null = ok، ئەگینا پەیامی هەڵە. لەسەر thread ی کارکەر بانگی بکە. هەموو فایلێک دوای پچڕان بەردەوام دەبێت. */
    fun download(filesDir: File, progress: (Int) -> Unit): String? {
        reset()
        val b = base().let { if (it.endsWith("/")) it else "$it/" }
        if (!b.startsWith("http")) return "لینکی Release دروست نییە (دەبێت https://... بێت)"

        class Item(val remote: String, val dest: File, val min: Long, val weight: Int)

        val items = listOf(
            Item("tokenizer.json", tokFile(filesDir), TOK_MIN, 1),
            Item("encoder_model_quantized.onnx", encFile(filesDir), ENC_MIN, 45),
            Item("decoder_model_merged_quantized.onnx", decFile(filesDir), DEC_MIN, 54)
        )
        val total = items.sumOf { it.weight }
        var done = 0
        val dl = Downloader.dir(filesDir)
        for (item in items) {
            if (item.dest.length() >= item.min) {
                done += item.weight
                progress(done * 100 / total)
                continue
            }
            val part = File(dl, "nllb_${item.remote}.part")
            val done0 = done
            Downloader.fetch(part, b + item.remote) { p ->
                progress((done0 + item.weight * p / 100) * 100 / total)
            }?.let { e -> return "${item.remote}: $e" }
            if (part.length() < item.min) {
                part.delete()
                return "${item.remote}: فایلەکە ناتەواوە یان هەڵەیە — ناوی فایل و Release بپشکنە"
            }
            item.dest.parentFile?.mkdirs()
            item.dest.delete()
            if (!part.renameTo(item.dest)) {
                try {
                    part.copyTo(item.dest, overwrite = true)
                    part.delete()
                } catch (e: Throwable) {
                    return "نەتوانرا ${item.remote} دابنرێت: ${e.message}"
                }
            }
            done += item.weight
            progress(done * 100 / total)
        }
        return null
    }

    fun delete(filesDir: File) {
        reset()
        dir(filesDir).deleteRecursively()
    }

    // ---------------------------------------------------------------- engine

    private class Engine(
        val env: OrtEnvironment,
        val enc: OrtSession,
        val dec: OrtSession,
        val tok: Tok
    )

    private var engine: Engine? = null

    fun reset() {
        synchronized(lock) {
            engine?.let {
                try { it.enc.close() } catch (_: Throwable) {}
                try { it.dec.close() } catch (_: Throwable) {}
            }
            engine = null
        }
    }

    private fun load(filesDir: File): Engine {
        engine?.let { return it }
        if (!isInstalled(filesDir)) throw IllegalStateException("مۆدێلی وەرگێڕانی ئۆفلاین نەهێنراوە")
        val tok = Tok.load(tokFile(filesDir))
        val env = OrtEnvironment.getEnvironment()
        val threads = Runtime.getRuntime().availableProcessors().coerceIn(2, 4)
        val opts = OrtSession.SessionOptions().apply {
            setIntraOpNumThreads(threads)
            setInterOpNumThreads(1)
            setExecutionMode(OrtSession.SessionOptions.ExecutionMode.SEQUENTIAL)
            setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
        }
        val enc = env.createSession(encFile(filesDir).absolutePath, opts)
        val dec = env.createSession(decFile(filesDir).absolutePath, opts)
        return Engine(env, enc, dec, tok).also { engine = it }
    }

    /** مۆدێلەکە لە پاشبنەما بار دەکات تا یەکەم وەرگێڕان خێرا بێت. */
    fun warmUp(filesDir: File) {
        try { synchronized(lock) { one(load(filesDir), "Hello.") } } catch (e: Throwable) { Log.w(TAG, "warmUp: " + e.message) }
    }

    private val sentSplit = Regex("(?<=[.!?…])\\s+")

    /**
     * English -> Sorani. هەڵە فڕێدەدات ئەگەر مۆدێل نەبوو؛ Gem.translate دەگەڕێتەوە سەر ئۆنلاین.
     * ڕستەی درێژ بە ڕستە ڕستە دەکرێت (NLLB لەسەر یەک ڕستە باشترە) و ئاکامەکە پاک دەکرێتەوە.
     */
    fun enToKu(text: String): String {
        val t = text.trim()
        if (t.isEmpty()) return ""
        synchronized(lock) {
            val e = load(appCtx.filesDir)
            val parts = t.split(sentSplit).map { it.trim() }.filter { it.isNotEmpty() }
            val out = parts.map { one(e, it) }.filter { it.isNotBlank() }
            return kuClean(out.joinToString(" "))
        }
    }

    // game dialogue repeats a lot: the same sentence is never translated twice
    private val cache = object : LinkedHashMap<String, String>(128, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?) = size > 300
    }

    private fun one(e: Engine, t: String): String {
        cache[t]?.let { return it }
        val r = oneRaw(e, t)
        if (r.isNotBlank()) cache[t] = r
        return r
    }

    private fun oneRaw(e: Engine, t: String): String {
        val ids = e.tok.encode(t)
        if (ids.isEmpty()) return ""
        val src = LongArray(ids.size + 2)
        src[0] = e.tok.idOf(SRC_LANG).toLong()
        for (i in ids.indices) src[i + 1] = ids[i].toLong()
        src[src.size - 1] = EOS
        val outIds = generate(e, src, e.tok.idOf(TGT_LANG))
        return e.tok.decode(outIds).trim()
    }

    /** پیتی عەرەبی ← کوردی و خاڵبەندیی کوردی، تا دەنگی کوردی و خوێندنەوە ڕاستتر بێت. */
    private fun kuClean(x: String): String {
        var s = x
            .replace('ك', 'ک').replace('ي', 'ی').replace('ى', 'ی').replace('ۀ', 'ە').replace('ہ', 'ە')
            .replace(',', '،').replace('?', '؟').replace(';', '؛')
            .replace(Regex("\\s+([،؟!.؛:])"), "$1")
            .replace(Regex("([،؟!.؛]){2,}")) { it.value.last().toString() }
            .replace(Regex("\\s+"), " ")
            .trim()
        return s
    }

    // ---------------------------------------------------------------- seq2seq (greedy, KV cache)

    /** no_repeat_ngram_size = 3: a token that would repeat an earlier 3-token run is forbidden. */
    private fun bannedNext(seq: List<Int>): Set<Int> {
        val n = seq.size
        if (n < 3) return emptySet()
        val a = seq[n - 2]
        val b = seq[n - 1]
        var out: HashSet<Int>? = null
        for (i in 0 until n - 2) {
            if (seq[i] == a && seq[i + 1] == b) {
                if (out == null) out = HashSet()
                out.add(seq[i + 2])
            }
        }
        return out ?: emptySet()
    }

    private fun generate(e: Engine, src: LongArray, tgtLang: Int): List<Int> {
        val env = e.env
        val n = src.size
        val maxNew = minOf(256, n * 2 + 12)
        val toClose = ArrayList<AutoCloseable>()
        try {
            val idsT = OnnxTensor.createTensor(env, LongBuffer.wrap(src), longArrayOf(1, n.toLong())).also { toClose += it }
            val maskT = OnnxTensor.createTensor(env, LongBuffer.wrap(LongArray(n) { 1L }), longArrayOf(1, n.toLong())).also { toClose += it }

            val encIn = HashMap<String, OnnxTensor>()
            encIn["input_ids"] = idsT
            if ("attention_mask" in e.enc.inputNames) encIn["attention_mask"] = maskT
            val encRes = e.enc.run(encIn).also { toClose += it }
            val hidden = encRes[0] as OnnxTensor

            // past_key_values.* inputs  <->  present.* outputs
            val pastNames = e.dec.inputNames.filter { it.startsWith("past_key_values.") }
            val pastDecoder = HashMap<String, OnnxTensor>()
            val pastEncoder = HashMap<String, OnnxTensor>()
            for (name in pastNames) {
                val shape = (e.dec.inputInfo[name]!!.info as TensorInfo).shape
                val heads = if (shape.size > 1 && shape[1] > 0) shape[1] else 16L
                val dim = if (shape.size > 3 && shape[3] > 0) shape[3] else 64L
                val empty = OnnxTensor.createTensor(env, FloatBuffer.allocate(0), longArrayOf(1, heads, 0, dim))
                if (".encoder." in name) pastEncoder[name] = empty else pastDecoder[name] = empty
            }
            toClose += AutoCloseable { (pastDecoder.values + pastEncoder.values).forEach { try { it.close() } catch (_: Throwable) {} } }

            val decOut = e.dec.outputNames
            var lg = FloatArray(0)
            val result = ArrayList<Int>()
            val seq = ArrayList<Int>().apply { add(EOS.toInt()); add(tgtLang) }   // for the no-repeat-trigram rule
            var cur = longArrayOf(EOS, tgtLang.toLong())      // decoder start + forced target language
            var first = true
            var same = 0
            var lastTok = -1
            for (step in 0 until maxNew) {
                val stepClose = ArrayList<AutoCloseable>()
                try {
                    val curT = OnnxTensor.createTensor(env, LongBuffer.wrap(cur), longArrayOf(1, cur.size.toLong())).also { stepClose += it }
                    val din = HashMap<String, OnnxTensor>()
                    din["input_ids"] = curT
                    if ("encoder_attention_mask" in e.dec.inputNames) din["encoder_attention_mask"] = maskT
                    din["encoder_hidden_states"] = hidden
                    if ("use_cache_branch" in e.dec.inputNames) {
                        din["use_cache_branch"] = OnnxTensor.createTensor(env, booleanArrayOf(!first)).also { stepClose += it }
                    }
                    din.putAll(pastDecoder)
                    din.putAll(pastEncoder)

                    // after the first step only the logits and the new decoder KV are needed (the encoder KV never changes)
                    val wanted: Set<String>? = if (!first || pastNames.isEmpty()) {
                        val w = LinkedHashSet<String>()
                        w += "logits"
                        for (name in pastNames) if (".encoder." !in name) w += "present." + name.removePrefix("past_key_values.")
                        if (w.all { it in decOut }) w else null
                    } else null
                    val r = (if (wanted != null) e.dec.run(din, wanted) else e.dec.run(din)).also { stepClose += it }
                    val logits = r["logits"].orElse(null) as? OnnxTensor ?: (r[0] as OnnxTensor)
                    val shape = (logits.info as TensorInfo).shape       // [1, len, vocab]
                    val vocab = shape[2].toInt()
                    val len = shape[1].toInt()
                    val fb = logits.floatBuffer
                    if (lg.size < vocab) lg = FloatArray(vocab)
                    fb.position((len - 1) * vocab)
                    fb.get(lg, 0, vocab)
                    var best = -1
                    var bv = Float.NEGATIVE_INFINITY
                    val banned = bannedNext(seq)
                    for (i in 0 until vocab) {
                        if (i == PAD || i == UNK_FALLBACK || i in banned) continue
                        val v = lg[i]
                        if (v > bv) { bv = v; best = i }
                    }
                    if (best < 0 || best.toLong() == EOS) break
                    result += best
                    seq += best
                    if (best == lastTok) same++ else { same = 0; lastTok = best }
                    if (same >= 4) break                                  // stuck repeating

                    // keep the new decoder KV; the encoder KV is computed once (first step)
                    for (name in pastNames) {
                        val isEnc = ".encoder." in name
                        if (isEnc && !first) continue
                        val outName = "present." + name.removePrefix("past_key_values.")
                        val t = r[outName].orElse(null) as? OnnxTensor ?: continue
                        val src2 = t.floatBuffer
                        val copy = FloatArray(src2.remaining())
                        src2.get(copy)
                        val nt = OnnxTensor.createTensor(env, FloatBuffer.wrap(copy), (t.info as TensorInfo).shape)
                        val map = if (isEnc) pastEncoder else pastDecoder
                        map[name]?.let { try { it.close() } catch (_: Throwable) {} }
                        map[name] = nt
                    }
                    // merged decoder (KV cache): feed only the new token; plain decoder (no past inputs): feed the whole sequence
                    cur = if (pastNames.isEmpty()) cur + best.toLong() else longArrayOf(best.toLong())
                    first = false
                } finally {
                    stepClose.forEach { try { it.close() } catch (_: Throwable) {} }
                }
            }
            return result
        } finally {
            toClose.forEach { try { it.close() } catch (_: Throwable) {} }
        }
    }

    // ---------------------------------------------------------------- tokenizer (tokenizer.json: Unigram OR BPE)

    private class Tok(
        val pieces: Array<String>,
        val scores: FloatArray?,                       // Unigram only
        val index: HashMap<String, Int>,
        val special: HashMap<String, Int>,
        val unkId: Int,
        val maxLen: Int,
        val ranks: HashMap<String, Int>?               // BPE only: "a b" -> merge priority
    ) {
        private val unkScore = (scores?.minOrNull() ?: -10f) - 10f
        private val specialIds = HashSet<Int>(special.values)

        fun idOf(token: String): Int = special[token] ?: index[token] ?: unkId

        fun encode(raw: String): IntArray {
            val norm = Normalizer.normalize(raw, Normalizer.Form.NFKC).trim().replace(Regex("\\s+"), " ")
            if (norm.isEmpty()) return IntArray(0)
            return if (ranks != null) encodeBpe(norm) else encodeUnigram(norm)
        }

        private fun encodeBpe(norm: String): IntArray {
            val out = ArrayList<Int>()
            for (w in norm.split(' ')) {
                if (w.isEmpty()) continue
                val syms = ArrayList<String>()
                val word = "▁" + w
                var k = 0
                while (k < word.length) {
                    val cp = word.codePointAt(k)
                    val n = Character.charCount(cp)
                    syms.add(word.substring(k, k + n))
                    k += n
                }
                while (syms.size > 1) {
                    var bestRank = Int.MAX_VALUE
                    var bi = -1
                    for (j in 0 until syms.size - 1) {
                        val r = ranks!![syms[j] + " " + syms[j + 1]] ?: continue
                        if (r < bestRank) { bestRank = r; bi = j }
                    }
                    if (bi < 0) break
                    syms[bi] = syms[bi] + syms[bi + 1]
                    syms.removeAt(bi + 1)
                }
                for (sy in syms) out += (index[sy] ?: unkId)
            }
            return out.toIntArray()
        }

        private fun encodeUnigram(norm: String): IntArray {
            val sc = scores ?: return IntArray(0)
            val s = "▁" + norm.replace(' ', '▁')
            val n = s.length
            val best = FloatArray(n + 1) { Float.NEGATIVE_INFINITY }
            val from = IntArray(n + 1)
            val pid = IntArray(n + 1)
            best[0] = 0f
            for (i in 0 until n) {
                if (best[i] == Float.NEGATIVE_INFINITY) continue
                val top = minOf(maxLen, n - i)
                for (l in 1..top) {
                    val id = index[s.substring(i, i + l)] ?: continue
                    val v = best[i] + sc[id]
                    if (v > best[i + l]) { best[i + l] = v; from[i + l] = i; pid[i + l] = id }
                }
                val su = best[i] + unkScore
                if (su > best[i + 1]) { best[i + 1] = su; from[i + 1] = i; pid[i + 1] = unkId }
            }
            val out = ArrayList<Int>()
            var p = n
            while (p > 0) { out += pid[p]; p = from[p] }
            out.reverse()
            return out.toIntArray()
        }

        fun decode(ids: List<Int>): String {
            val sb = StringBuilder()
            for (id in ids) {
                if (id in specialIds || id == unkId || id < 0 || id >= pieces.size) continue
                sb.append(pieces[id])
            }
            return sb.toString().replace('▁', ' ')
        }

        companion object {
            /** Streams tokenizer.json (≈17MB) with JsonReader; vocab can be a Unigram array or a BPE object (+ merges). */
            fun load(f: File): Tok {
                val upieces = ArrayList<String>(262_144)
                val uscores = ArrayList<Float>(262_144)
                val bvocab = HashMap<String, Int>(300_000)
                var ranks: HashMap<String, Int>? = null
                var isBpe = false
                val special = HashMap<String, Int>()
                var unk = -1
                var unkTok = "<unk>"
                JsonReader(InputStreamReader(f.inputStream().buffered(), Charsets.UTF_8)).use { r ->
                    r.beginObject()
                    while (r.hasNext()) {
                        when (r.nextName()) {
                            "added_tokens" -> {
                                r.beginArray()
                                while (r.hasNext()) {
                                    var id = -1
                                    var content = ""
                                    r.beginObject()
                                    while (r.hasNext()) {
                                        when (r.nextName()) {
                                            "id" -> id = r.nextInt()
                                            "content" -> content = r.nextString()
                                            else -> r.skipValue()
                                        }
                                    }
                                    r.endObject()
                                    if (id >= 0 && content.isNotEmpty()) special[content] = id
                                }
                                r.endArray()
                            }
                            "model" -> {
                                r.beginObject()
                                while (r.hasNext()) {
                                    when (r.nextName()) {
                                        "unk_id" -> if (r.peek() == JsonToken.NULL) r.nextNull() else unk = r.nextInt()
                                        "unk_token" -> if (r.peek() == JsonToken.STRING) unkTok = r.nextString() else r.skipValue()
                                        "vocab" -> {
                                            if (r.peek() == JsonToken.BEGIN_ARRAY) {          // Unigram: [[piece, score], ...]
                                                r.beginArray()
                                                while (r.hasNext()) {
                                                    r.beginArray()
                                                    upieces += r.nextString()
                                                    uscores += r.nextDouble().toFloat()
                                                    r.endArray()
                                                }
                                                r.endArray()
                                            } else {                                          // BPE: {piece: id}
                                                isBpe = true
                                                r.beginObject()
                                                while (r.hasNext()) {
                                                    val name = r.nextName()
                                                    bvocab[name] = r.nextInt()
                                                }
                                                r.endObject()
                                            }
                                        }
                                        "merges" -> {
                                            val rk = HashMap<String, Int>(300_000)
                                            r.beginArray()
                                            var n = 0
                                            while (r.hasNext()) {
                                                val key = if (r.peek() == JsonToken.STRING) r.nextString() else {
                                                    r.beginArray()
                                                    val a = r.nextString()
                                                    val b = r.nextString()
                                                    r.endArray()
                                                    "$a $b"
                                                }
                                                rk[key] = n++
                                            }
                                            r.endArray()
                                            ranks = rk
                                        }
                                        else -> r.skipValue()
                                    }
                                }
                                r.endObject()
                            }
                            else -> r.skipValue()
                        }
                    }
                    r.endObject()
                }
                if (isBpe) {
                    if (bvocab.isEmpty() || ranks == null) throw IllegalStateException("tokenizer.json: BPE vocab/merges بەتاڵە")
                    val size = maxOf(bvocab.values.max(), special.values.maxOrNull() ?: 0) + 1
                    val pieces = Array(size) { "" }
                    for ((t, id) in bvocab) if (id in 0 until size) pieces[id] = t
                    val unkId = if (unk >= 0) unk else (bvocab[unkTok] ?: special[unkTok] ?: UNK_FALLBACK)
                    return Tok(pieces, null, bvocab, special, unkId, 1, ranks)
                }
                if (upieces.isEmpty()) throw IllegalStateException("tokenizer.json: vocab بەتاڵە")
                val index = HashMap<String, Int>(upieces.size * 2)
                var maxLen = 1
                for (i in upieces.indices) {
                    if (i < 4) continue                         // control tokens never match inside normal text
                    index[upieces[i]] = i
                    if (upieces[i].length > maxLen) maxLen = upieces[i].length
                }
                val unkId = if (unk >= 0) unk else UNK_FALLBACK
                return Tok(upieces.toTypedArray(), uscores.toFloatArray(), index, special, unkId, minOf(maxLen, 40), null)
            }
        }
    }
}

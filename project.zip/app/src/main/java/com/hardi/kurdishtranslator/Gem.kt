package com.hardi.kurdishtranslator

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Base64
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.Callable
import java.util.concurrent.ExecutionException
import java.util.concurrent.ExecutorCompletionService
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.TimeUnit

/** Text translation (Gemini REST) + Kurdish speech made OFFLINE by KuVoice (24 kHz mono PCM16). */
object Gem {
    // "-latest" aliases always point to the current model, so they do not get retired like gemini-2.5-flash did.
    private val TEXT_MODELS = listOf("gemini-3.5-flash-lite", "gemini-3.1-flash-lite", "gemini-3.8-flash", "gemini-flash-lite-latest", "gemini-flash-latest")
    @Volatile private var textModel = 0

    private val http = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    private fun post(model: String, body: JSONObject, role: Int): JSONObject {
        val tries = maxOf(1, Bus.keys.size)
        var last: Exception? = null
        repeat(tries) {
            val k = Bus.keyFor(role)
            try {
                val req = Request.Builder()
                    .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                    .header("x-goog-api-key", k)
                    .post(body.toString().toRequestBody("application/json".toMediaType()))
                    .build()
                http.newCall(req).execute().use { r ->
                    val t = r.body?.string() ?: ""
                    if (!r.isSuccessful) {
                        // quota / overload / bad key -> rest this key and let the next one try
                        if (r.code == 429) Bus.cooldown(k, 30_000L)
                        else if (r.code == 400 || r.code == 401 || r.code == 403) Bus.cooldown(k, 10 * 60_000L)
                        else if (r.code >= 500) Bus.cooldown(k, 5_000L)
                        throw RuntimeException("HTTP " + r.code + ": " + t.take(120))
                    }
                    return JSONObject(t)
                }
            } catch (e: Exception) {
                last = e
            }
        }
        throw last ?: RuntimeException("هەڵە")
    }

    /** Runs one generateContent request, trying the text models in turn (busy / retired models are skipped). */
    private fun generate(body: JSONObject): JSONObject {
        var res: JSONObject? = null
        var last: Exception? = null
        var round = 0
        search@ while (round < 2) {
            var transient = false
            for (i in textModel until TEXT_MODELS.size) {
                try {
                    res = post(TEXT_MODELS[i], body, Bus.TEXT)
                    textModel = i
                    break@search
                } catch (e: Exception) {
                    last = e
                    val m = e.message ?: ""
                    when {
                        // 404 = this model is gone / not allowed for this key: never try it again
                        m.contains("HTTP 404") -> if (i == textModel) textModel = minOf(i + 1, TEXT_MODELS.size - 1)
                        // 503 / 500 / 429 / timeout = Google is busy for a moment: try the next model now,
                        // and the whole list again after a short pause
                        m.contains("HTTP 503") || m.contains("HTTP 500") || m.contains("HTTP 429") ||
                            m.contains("high demand") || e is java.io.IOException -> transient = true
                        else -> throw e
                    }
                }
            }
            if (!transient) break
            round++
            try { Thread.sleep(700L * round) } catch (_: InterruptedException) { break }
        }
        if (res == null) throw last ?: RuntimeException("مۆدێلی وەرگێڕان نەدۆزرایەوە")
        return res
    }

    private fun firstText(res: JSONObject): String =
        res.getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
            .getJSONArray("parts").getJSONObject(0).getString("text")

    /** English lines -> Sorani. Without a Gemini key (or when Gemini fails) Google Translate is used, which needs no key. */
    fun translate(lines: List<String>): List<String> {
        // offline NLLB model first (when downloaded + switched on); any failure falls through to the online routes below
        if (NllbOffline.ready()) {
            try {
                return lines.map { offlineOne(it) }
            } catch (e: Throwable) {
                android.util.Log.w("Gem", "offline NLLB failed, using online", e)
                Bus.say("⚠️ وەرگێڕانی ئۆفلاین سەرکەوتوو نەبوو: " + e.javaClass.simpleName + " — " + (e.message ?: "").take(110))
            }
        }
        return translateOnline(lines)
    }

    private fun offlineOne(s: String): String =
        Names.applyKu(NllbOffline.enToKu(s).replace("\t", " ").replace("\n", " ").trim())

    /** Instant draft from the local NLLB model, or null when it is not installed / switched on / fails. */
    fun translateOffline(line: String): String? {
        if (!NllbOffline.ready()) return null
        return try { offlineOne(line).ifBlank { null } } catch (e: Throwable) {
            android.util.Log.w("Gem", "offline draft failed", e)
            null
        }
    }

    /**
     * Online only (Gemini, then Google Translate). [context] = the lines that came just before, so the model can
     * pick the right phrasing; they are NOT translated. Result has exactly one line per input line.
     */
    fun translateOnline(lines: List<String>, context: List<String> = emptyList()): List<String> {
        if (Bus.keys.isEmpty()) return googleLines(lines)
        if (lines.size == 1) return hedged(lines, context)
        return try {
            geminiTranslate(lines, context)
        } catch (e: Exception) {
            android.util.Log.w("Gem", "Gemini failed, using Google: " + e.message)
            googleLines(lines)
        }
    }

    private val hedgePool = Executors.newCachedThreadPool()
    private const val HEDGE_MS = 2200L   // Gemini slower than this: Google Translate starts too, the first answer wins

    /** One sentence: Gemini first; if it is slow or fails, Google Translate races it, so the text never takes long. */
    private fun hedged(lines: List<String>, context: List<String> = emptyList()): List<String> {
        val cs = ExecutorCompletionService<List<String>>(hedgePool)
        val fg = cs.submit(Callable { geminiTranslate(lines, context) })
        var fo: Future<List<String>>? = null
        var pending = 1
        var done: Future<List<String>>? = cs.poll(HEDGE_MS, TimeUnit.MILLISECONDS)
        if (done == null) { fo = cs.submit(Callable { googleLines(lines) }); pending++ }
        var err: Exception? = null
        while (pending > 0) {
            val d = done ?: cs.take()
            done = null
            pending--
            try {
                val r = d.get()
                fg.cancel(true); fo?.cancel(true)
                return r
            } catch (e: ExecutionException) {
                err = e
                android.util.Log.w("Gem", "translate: " + (e.cause?.message ?: e.message))
                if (fo == null) { fo = cs.submit(Callable { googleLines(lines) }); pending++ }
            }
        }
        throw err ?: RuntimeException("هەڵە")
    }

    private fun googleLines(lines: List<String>): List<String> =
        lines.map { Names.applyKu(GoogleFree.enToKu(it).replace("\t", " ").replace("\n", " ").trim()) }

    private fun geminiTranslate(lines: List<String>, context: List<String> = emptyList()): List<String> {
        val prompt = "Translate each English line below into natural, spoken Sorani Kurdish (کوردی سۆرانی, Arabic script). " +
            "They are consecutive lines of a video game's dialogue, in story order, so use the neighbouring lines as context. " +
            "Use colloquial gamer Sorani and keep each line short and punchy, keeping its emotion (shouts, commands, whispers). " +
            "Write character and place names as consistent Kurdish-script transliterations. " + Names.promptFor(lines) + "No explanations. " +
            (if (context.isEmpty()) "" else "For context only, these lines came just before (do NOT translate or return them): " + JSONArray(context).toString() + ". ") +
            "The text will be read aloud by a Kurdish voice, so: write every number as Kurdish words (never digits), " +
            "use only Kurdish letters (no Latin letters, emojis, brackets or symbols), use the Kurdish punctuation ، ؟ ! . " +
            "to mark natural pauses, and prefer short, simple sentences that are easy to understand when heard once. " +
            "Return ONLY a JSON array of exactly " + lines.size + " strings, in the same order.\n" + JSONArray(lines).toString()
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        val arr = JSONArray(firstText(generate(body)))
        if (arr.length() != lines.size) throw RuntimeException("ژمارەی ڕستەکان یەک نەبوو")
        return List(arr.length()) { Names.applyKu(arr.getString(it).replace("\t", " ").replace("\n", " ").trim()) }
    }

    /**
     * Kurdish speech (WAV, 16 kHz mono) -> (Kurdish text, English translation), or null when there is no clear Kurdish speech.
     * Needs the internet (Gemini listens to the audio).
     */
    fun kuToEn(wav: ByteArray): Pair<String, String>? {
        if (Bus.keys.isEmpty()) throw RuntimeException("کوردی ← ئینگلیزی کلیلی Gemini دەوێت (گوێگرتنی کوردی)")
        val prompt = "The audio is Sorani Kurdish speech (کوردی سۆرانی) from a person, game or video, possibly with background music or effects. " +
            "Transcribe exactly what is said in Kurdish (Arabic script) and translate it into natural, short, spoken English. " +
            "If there is no clear human Kurdish speech (only music, effects, noise, silence, or another language), return empty strings. Never invent anything that was not said. " +
            "Return ONLY JSON like {\"ku\":\"...\",\"en\":\"...\"}."
        val parts = JSONArray()
            .put(JSONObject().put("text", prompt))
            .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "audio/wav").put("data", Base64.encodeToString(wav, Base64.NO_WRAP))))
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", parts)))
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        val o = JSONObject(firstText(generate(body)))
        val ku = o.optString("ku", "").trim()
        val en = o.optString("en", "").trim()
        return if (en.length < 2) null else Pair(ku, en)
    }

    /** Kurdish text -> speech, fully offline (Piper/ONNX model imported by the user). No AI, no internet. */
    fun tts(filesDir: File, text: String, speed: Float): ByteArray = KuVoice.synth(filesDir, text, speed)

    private fun key(s: String, pawan: Boolean = false): String {
        val tag = if (pawan) "pawan1|" + PawanTts.voice() + "|" else "piper2|" + String.format(java.util.Locale.US, "%.2f", Bus.speed) + "|"
        return MessageDigest.getInstance("MD5").digest((tag + s).toByteArray()).joinToString("") { "%02x".format(it) }
    }

    /** Is this line already on disk for the voice that is active right now (Pawan or offline)? */
    fun cached(dir: File, ku: String): Boolean =
        File(File(dir, "tts"), key(ku, PawanTts.usable()) + ".pcm").exists()

    private fun save(d: File, k: String, b: ByteArray) {
        val tmp = File(d, k + "." + Thread.currentThread().id + ".tmp")
        tmp.writeBytes(b)
        if (!tmp.renameTo(File(d, k + ".pcm"))) tmp.delete()
    }

    /**
     * Audio for a Kurdish line: from the disk cache, otherwise generated and cached.
     * With Pawan on (and online + logged in) the voice comes from tts.pawan.krd; if that fails, the offline voice is used.
     */
    fun pcmFor(dir: File, ku: String): ByteArray {
        val d = File(dir, "tts")
        d.mkdirs()
        if (PawanTts.usable()) {
            val k = key(ku, true)
            val f = File(d, "$k.pcm")
            if (f.exists()) return PawanTts.adjust(f.readBytes())
            try {
                val b = PawanTts.synth(ku)
                save(d, k, b)          // the raw voice is cached; the tuning is applied on every read
                return PawanTts.adjust(b)
            } catch (e: Throwable) {
                android.util.Log.w("Gem", "Pawan failed, using offline voice: " + e.message)
                Bus.say("⚠️ Pawan: " + (e.message ?: "هەڵە") + (if (KuVoice.isInstalled(dir)) " — دەنگی ئۆفلاین بەکاردێت" else ""))
                if (!KuVoice.isInstalled(dir)) throw e
            }
        }
        val k = key(ku)
        val f = File(d, "$k.pcm")
        if (f.exists()) return f.readBytes()
        val b = tts(dir, ku, Bus.speed)
        save(d, k, b)
        return b
    }

    /** Pawan بەکاردێت: دەق (ماڵپەڕەکە خۆی دەیخوێنێتەوە) — ئەگەرنا PCM ی ئۆفلاین. */
    fun voiceFor(dir: File, ku: String): Any {
        if (!PawanTts.usable()) return pcmFor(dir, ku)
        if (pawanDirect()) return PawanTts.Line(ku)
        // another phone volume was chosen (accessibility / alarm / ...): the site's audio is played by the app itself.
        // A line already on disk starts at once; a new one is played LIVE while it still arrives.
        if (File(File(dir, "tts"), key(ku, true) + ".pcm").exists()) {
            return try { pcmFor(dir, ku) } catch (e: Throwable) { PawanTts.Line(ku) }
        }
        return live(dir, ku)
    }

    // lines are made one after the other (the site has one page), in story order
    private val liveGen = Executors.newSingleThreadExecutor()

    private fun live(dir: File, ku: String): Any {
        val lv = PawanTts.Live(ku)
        liveGen.execute {
            try {
                if (lv.epoch != PawanTts.liveEpoch) { lv.fail("وەستێنرا"); return@execute }
                val raw = PawanTts.synthLive(ku) { lv.put(it) }
                val d = File(dir, "tts")
                d.mkdirs()
                save(d, key(ku, true), raw)      // the raw voice is cached; the next time it starts at once
                lv.end()
            } catch (e: Throwable) {
                lv.fail(e.message ?: "Pawan")
            }
        }
        return lv
    }

    /** The site can play by itself only on the media volume (a web page cannot choose another one). */
    fun pawanDirect(): Boolean = PawanTts.usable() && Bus.outUsage == AudioAttributes.USAGE_ASSISTANT

    fun playOnce(pcm: ByteArray) {
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(Bus.outUsage)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(24000)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(pcm.size)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        t.write(pcm, 0, pcm.size)
        t.play()
        Thread.sleep(pcm.size / 48L + 400)
        t.release()
    }

    @Volatile private var manual: AudioTrack? = null

    /** Plays one sentence when the user taps its ▶ button. It has its own player, so the automatic reading is not touched. */
    fun playManual(pcm: ByteArray) {
        stopManual()
        Bus.speakUntil = System.currentTimeMillis() + pcm.size / 48L + 500L
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(Bus.outUsage)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(24000)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(pcm.size)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        manual = t
        try {
            t.write(pcm, 0, pcm.size)
            t.play()
            val end = System.currentTimeMillis() + pcm.size / 48L + 300
            while (manual === t && System.currentTimeMillis() < end) Thread.sleep(40)
        } finally {
            if (manual === t) manual = null
            try { t.stop() } catch (_: Exception) {}
            t.release()
        }
    }

    /** Tapping another ▶ stops the sentence that is still playing from a previous tap. */
    fun stopManual() {
        val t = manual
        manual = null
        try { t?.stop() } catch (_: Exception) {}
    }
}

package com.hardi.kurdishtranslator

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Base64
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

/** Plain REST calls: text translation and text-to-speech (24 kHz mono PCM16). */
object Gem {
    const val TEXT_MODEL = "gemini-2.5-flash"
    const val TTS_MODEL = "gemini-2.5-flash-preview-tts"

    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()

    private fun post(model: String, body: JSONObject): JSONObject {
        val req = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .header("x-goog-api-key", Bus.key)
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        http.newCall(req).execute().use { r ->
            val t = r.body?.string() ?: ""
            if (!r.isSuccessful) throw RuntimeException("HTTP " + r.code + ": " + t.take(120))
            return JSONObject(t)
        }
    }

    fun translate(lines: List<String>): List<String> {
        val prompt = "Translate each English line below into natural, spoken Sorani Kurdish (کوردی سۆرانی, Arabic script). " +
            "They are consecutive lines of a video game's dialogue, in story order, so use the neighbouring lines as context. " +
            "Write character and place names as consistent Kurdish-script transliterations. No explanations. " +
            "Return ONLY a JSON array of exactly " + lines.size + " strings, in the same order.\n" + JSONArray(lines).toString()
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        val res = post(TEXT_MODEL, body)
        val txt = res.getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
            .getJSONArray("parts").getJSONObject(0).getString("text")
        val arr = JSONArray(txt)
        if (arr.length() != lines.size) throw RuntimeException("ژمارەی ڕستەکان یەک نەبوو")
        return List(arr.length()) { arr.getString(it).replace("\t", " ").replace("\n", " ").trim() }
    }

    fun tts(text: String): ByteArray {
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", text)))))
            .put(
                "generationConfig",
                JSONObject()
                    .put("responseModalities", JSONArray().put("AUDIO"))
                    .put(
                        "speechConfig",
                        JSONObject().put(
                            "voiceConfig",
                            JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", "Aoede"))
                        )
                    )
            )
        val res = post(TTS_MODEL, body)
        val d = res.getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
            .getJSONArray("parts").getJSONObject(0).getJSONObject("inlineData").getString("data")
        return Base64.decode(d, Base64.DEFAULT)
    }

    private fun key(s: String): String =
        MessageDigest.getInstance("MD5").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    fun cached(dir: File, ku: String): Boolean = File(File(dir, "tts"), key(ku) + ".pcm").exists()

    /** Audio for a Kurdish line: from the disk cache, otherwise generated and cached. */
    fun pcmFor(dir: File, ku: String): ByteArray {
        val d = File(dir, "tts")
        d.mkdirs()
        val f = File(d, key(ku) + ".pcm")
        if (f.exists()) return f.readBytes()
        val b = tts(ku)
        f.writeBytes(b)
        return b
    }

    fun playOnce(pcm: ByteArray) {
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(24000)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(pcm.size)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        t.write(pcm, 0, pcm.size)
        t.play()
        Thread.sleep(pcm.size / 48L + 400)
        t.release()
    }
}

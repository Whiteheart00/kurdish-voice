package com.hardi.kurdishtranslator

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

/** Text translation (Gemini REST) + Kurdish speech made OFFLINE by KuVoice (24 kHz mono PCM16). */
object Gem {
    const val TEXT_MODEL = "gemini-2.5-flash"

    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()

    private fun post(model: String, body: JSONObject, role: Int): JSONObject {
        val tries = maxOf(1, Bus.keys.size)
        var last: Exception? = null
        repeat(tries) {
            val k = Bus.keyFor(role)
            try {
                val req = Request.Builder()
                    .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                    .header("x-goog-api-key", k)
                    .post(body.toString().toRequestBody("application/json".toMediaType()))
                    .build()
                http.newCall(req).execute().use { r ->
                    val t = r.body?.string() ?: ""
                    if (!r.isSuccessful) {
                        // quota / overload / bad key -> rest this key and let the next one try
                        if (r.code == 429) Bus.cooldown(k, 30_000L)
                        else if (r.code == 400 || r.code == 401 || r.code == 403) Bus.cooldown(k, 10 * 60_000L)
                        else if (r.code >= 500) Bus.cooldown(k, 5_000L)
                        throw RuntimeException("HTTP " + r.code + ": " + t.take(120))
                    }
                    return JSONObject(t)
                }
            } catch (e: Exception) {
                last = e
            }
        }
        throw last ?: RuntimeException("هەڵە")
    }

    fun translate(lines: List<String>): List<String> {
        val prompt = "Translate each English line below into natural, spoken Sorani Kurdish (کوردی سۆرانی, Arabic script). " +
            "They are consecutive lines of a video game's dialogue, in story order, so use the neighbouring lines as context. " +
            "Use colloquial gamer Sorani and keep each line short and punchy, keeping its emotion (shouts, commands, whispers). " +
            "Write character and place names as consistent Kurdish-script transliterations. No explanations. " +
            "Return ONLY a JSON array of exactly " + lines.size + " strings, in the same order.\n" + JSONArray(lines).toString()
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        val res = post(TEXT_MODEL, body, Bus.TEXT)
        val txt = res.getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
            .getJSONArray("parts").getJSONObject(0).getString("text")
        val arr = JSONArray(txt)
        if (arr.length() != lines.size) throw RuntimeException("ژمارەی ڕستەکان یەک نەبوو")
        return List(arr.length()) { arr.getString(it).replace("\t", " ").replace("\n", " ").trim() }
    }

    /** Kurdish text -> speech, fully offline (Piper/ONNX model imported by the user). No AI, no internet. */
    fun tts(filesDir: File, text: String): ByteArray = KuVoice.synth(filesDir, text)

    private fun key(s: String): String =
        MessageDigest.getInstance("MD5").digest(("piper1|" + s).toByteArray()).joinToString("") { "%02x".format(it) }

    fun cached(dir: File, ku: String): Boolean = File(File(dir, "tts"), key(ku) + ".pcm").exists()

    /** Audio for a Kurdish line: from the disk cache, otherwise generated and cached. */
    fun pcmFor(dir: File, ku: String): ByteArray {
        val d = File(dir, "tts")
        d.mkdirs()
        val f = File(d, key(ku) + ".pcm")
        if (f.exists()) return f.readBytes()
        val b = tts(dir, ku)
        val tmp = File(d, key(ku) + "." + Thread.currentThread().id + ".tmp")
        tmp.writeBytes(b)
        if (!tmp.renameTo(f)) tmp.delete()
        return b
    }

    fun playOnce(pcm: ByteArray) {
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(24000)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(pcm.size)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        t.write(pcm, 0, pcm.size)
        t.play()
        Thread.sleep(pcm.size / 48L + 400)
        t.release()
    }
}

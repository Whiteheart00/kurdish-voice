package com.hardi.kurdishtranslator

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

/** Text translation (Gemini REST) + Kurdish speech made OFFLINE by KuVoice (24 kHz mono PCM16). */
object Gem {
    // "-latest" aliases always point to the current model, so they do not get retired like gemini-2.5-flash did.
    private val TEXT_MODELS = listOf("gemini-flash-latest", "gemini-flash-lite-latest", "gemini-2.5-flash-lite", "gemini-2.5-flash")
    @Volatile private var textModel = 0

    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()

    private fun post(model: String, body: JSONObject, role: Int, cli: OkHttpClient = http): JSONObject {
        val tries = maxOf(1, Bus.keys.size)
        var last: Exception? = null
        repeat(tries) {
            val k = Bus.keyFor(role)
            try {
                val req = Request.Builder()
                    .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                    .header("x-goog-api-key", k)
                    .post(body.toString().toRequestBody("application/json".toMediaType()))
                    .build()
                cli.newCall(req).execute().use { r ->
                    val t = r.body?.string() ?: ""
                    if (!r.isSuccessful) {
                        // quota / overload / bad key -> rest this key and let the next one try
                        if (r.code == 429) Bus.cooldown(k, 30_000L)
                        else if (r.code == 400 || r.code == 401 || r.code == 403) Bus.cooldown(k, 10 * 60_000L)
                        else if (r.code >= 500) Bus.cooldown(k, 5_000L)
                        throw RuntimeException("HTTP " + r.code + ": " + t.take(120))
                    }
                    return JSONObject(t)
                }
            } catch (e: Exception) {
                last = e
            }
        }
        throw last ?: RuntimeException("هەڵە")
    }


    private val fast = http.newBuilder().readTimeout(25, TimeUnit.SECONDS).build()
    private val HEAR_MODELS = listOf("gemini-flash-latest", "gemini-flash-lite-latest", "gemini-2.5-flash", "gemini-2.5-flash-lite")
    @Volatile private var hearModel = 0

    class Heard(val en: String, val ku: String)

    private fun wav(pcm: ByteArray, rate: Int = 16000): ByteArray {
        val n = pcm.size
        val bb = java.nio.ByteBuffer.allocate(44 + n).order(java.nio.ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()).putInt(36 + n).put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray()).putInt(16).putShort(1).putShort(1).putInt(rate).putInt(rate * 2).putShort(2).putShort(16)
        bb.put("data".toByteArray()).putInt(n).put(pcm)
        return bb.array()
    }

    /**
     * One speech segment (16 kHz mono PCM16) -> what was said + its Sorani Kurdish text, in ONE request.
     * Returns null when there is no clear human speech in the audio.
     */
    fun hear(pcm: ByteArray): Heard? {
        val prompt = "Listen to this audio. It is a short piece of live speech (a call, a game or a video; there may be music or noise under it). " +
            "If there is NO clear human speech (only music, noise, silence, breathing), return {\"en\":\"\",\"ku\":\"\"}. Never invent words that were not spoken. " +
            "Otherwise return ONLY a JSON object {\"en\":\"<exactly what was said, in its original language>\",\"ku\":\"<the same meaning as natural, spoken Sorani Kurdish (کوردی سۆرانی) in Arabic script>\"}. " +
            "Translate every word, never skip or summarize. If the speech is already Kurdish, write it in Sorani script in both fields. No explanations."
        val b64 = android.util.Base64.encodeToString(wav(pcm), android.util.Base64.NO_WRAP)
        val parts = JSONArray()
            .put(JSONObject().put("text", prompt))
            .put(JSONObject().put("inlineData", JSONObject().put("mimeType", "audio/wav").put("data", b64)))
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", parts)))
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json").put("temperature", 0))
        val models = (listOf(Bus.model) + HEAR_MODELS).distinct().filter { it.startsWith("gemini-") && "audio" !in it && "live" !in it }
        var res: JSONObject? = null
        var last: Exception? = null
        for (round in 0 until 2) {
            for (i in models.indices) {
                val idx = (hearModel + i) % models.size
                try {
                    res = post(models[idx], body, Bus.LIVE, fast)
                    hearModel = idx
                    break
                } catch (e: Exception) {
                    last = e
                }
            }
            if (res != null) break
            try { Thread.sleep(500L) } catch (_: InterruptedException) { break }
        }
        if (res == null) throw last ?: RuntimeException("مۆدێلی گوێگرتن نەدۆزرایەوە")
        val cand = res.optJSONArray("candidates")?.optJSONObject(0) ?: return null
        val txt = cand.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)?.optString("text") ?: return null
        val clean = txt.replace("```json", "").replace("```", "").trim()
        val o = try {
            if (clean.startsWith("[")) JSONArray(clean).optJSONObject(0) else JSONObject(clean)
        } catch (e: Exception) { null } ?: return null
        val ku = o.optString("ku").replace("\n", " ").trim()
        if (ku.isEmpty()) return null
        return Heard(o.optString("en").replace("\n", " ").trim(), ku)
    }

    fun translate(lines: List<String>): List<String> {
        val prompt = "Translate each English line below into natural, spoken Sorani Kurdish (کوردی سۆرانی, Arabic script). " +
            "They are consecutive lines of a video game's dialogue, in story order, so use the neighbouring lines as context. " +
            "Use colloquial gamer Sorani and keep each line short and punchy, keeping its emotion (shouts, commands, whispers). " +
            "Write character and place names as consistent Kurdish-script transliterations. No explanations. " +
            "Return ONLY a JSON array of exactly " + lines.size + " strings, in the same order.\n" + JSONArray(lines).toString()
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        var res: JSONObject? = null
        var last: Exception? = null
        var round = 0
        search@ while (round < 4) {
            var transient = false
            for (i in textModel until TEXT_MODELS.size) {
                try {
                    res = post(TEXT_MODELS[i], body, Bus.TEXT)
                    textModel = i
                    break@search
                } catch (e: Exception) {
                    last = e
                    val m = e.message ?: ""
                    when {
                        // 404 = this model is gone / not allowed for this key: never try it again
                        m.contains("HTTP 404") -> if (i == textModel) textModel = minOf(i + 1, TEXT_MODELS.size - 1)
                        // 503 / 500 / 429 / timeout = Google is busy for a moment: try the next model now,
                        // and the whole list again after a short pause
                        m.contains("HTTP 503") || m.contains("HTTP 500") || m.contains("HTTP 429") ||
                            m.contains("high demand") || e is java.io.IOException -> transient = true
                        else -> throw e
                    }
                }
            }
            if (!transient) break
            round++
            try { Thread.sleep(700L * round) } catch (_: InterruptedException) { break }
        }
        if (res == null) throw last ?: RuntimeException("مۆدێلی وەرگێڕان نەدۆزرایەوە")
        val txt = res.getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
            .getJSONArray("parts").getJSONObject(0).getString("text")
        val arr = JSONArray(txt)
        if (arr.length() != lines.size) throw RuntimeException("ژمارەی ڕستەکان یەک نەبوو")
        return List(arr.length()) { arr.getString(it).replace("\t", " ").replace("\n", " ").trim() }
    }

    /** Kurdish text -> speech, fully offline (Piper/ONNX model imported by the user). No AI, no internet. */
    fun tts(filesDir: File, text: String, speed: Float): ByteArray = KuVoice.synth(filesDir, text, speed)

    private fun key(s: String): String =
        MessageDigest.getInstance("MD5").digest(("piper1|" + String.format(java.util.Locale.US, "%.2f", Bus.speed) + "|" + s).toByteArray()).joinToString("") { "%02x".format(it) }

    fun cached(dir: File, ku: String): Boolean = File(File(dir, "tts"), key(ku) + ".pcm").exists()

    /** Audio for a Kurdish line: from the disk cache, otherwise generated and cached. */
    fun pcmFor(dir: File, ku: String): ByteArray {
        val d = File(dir, "tts")
        d.mkdirs()
        val f = File(d, key(ku) + ".pcm")
        if (f.exists()) return f.readBytes()
        val b = tts(dir, ku, Bus.speed)
        val tmp = File(d, key(ku) + "." + Thread.currentThread().id + ".tmp")
        tmp.writeBytes(b)
        if (!tmp.renameTo(f)) tmp.delete()
        return b
    }

    fun playOnce(pcm: ByteArray) {
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(24000)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(pcm.size)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        t.write(pcm, 0, pcm.size)
        t.play()
        Thread.sleep(pcm.size / 48L + 400)
        t.release()
    }

    @Volatile private var manual: AudioTrack? = null

    /** Plays one sentence when the user taps its ▶ button. It has its own player, so the automatic reading is not touched. */
    fun playManual(pcm: ByteArray) {
        stopManual()
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(24000)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(pcm.size)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        manual = t
        try {
            t.write(pcm, 0, pcm.size)
            t.play()
            val end = System.currentTimeMillis() + pcm.size / 48L + 300
            while (manual === t && System.currentTimeMillis() < end) Thread.sleep(40)
        } finally {
            if (manual === t) manual = null
            try { t.stop() } catch (_: Exception) {}
            t.release()
        }
    }

    /** Tapping another ▶ stops the sentence that is still playing from a previous tap. */
    fun stopManual() {
        val t = manual
        manual = null
        try { t?.stop() } catch (_: Exception) {}
    }
}

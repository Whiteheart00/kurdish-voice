package com.hardi.kurdishtranslator

/**
 * Adaptive CPU budget: STT + TTS together without thrashing.
 * Stronger phones get 2 TTS workers so next line synths while current plays.
 */
object Cpu {
    private val cores: Int = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)

    val low: Boolean get() = cores <= 6

    val ttsThreads: Int get() = if (low) 1 else 2

    val sttThreads: Int get() = if (cores <= 4) 1 else 2

    /** Parallel offline synth: 2 on mid/high phones → next sentence ready while current plays. */
    val ttsPoolSize: Int get() = if (low) 1 else 2

    val netPoolSize: Int get() = if (low) 2 else 4
}

package com.hardi.kurdishtranslator

/**
 * Adaptive CPU budget so offline STT + offline TTS can run together without thrashing.
 * Fewer ONNX threads = less contention, often *faster* wall-clock on phones.
 */
object Cpu {
    private val cores: Int = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)

    /** True on typical phones where 4+ ONNX threads fight the recogniser. */
    val low: Boolean get() = cores <= 6

    /** Piper / KuVoice ONNX intra-op threads (1–2). */
    val ttsThreads: Int get() = if (low) 1 else 2

    /** Whisper ONNX intra-op threads (cap 2). */
    val sttThreads: Int get() = if (cores <= 4) 1 else 2

    /** Parallel TTS synthesizers (always 1 offline — shares cores with STT). */
    val ttsPoolSize: Int get() = 1

    /** Parallel online translation requests. */
    val netPoolSize: Int get() = if (low) 2 else 3
}

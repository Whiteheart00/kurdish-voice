# وەرگێڕی زیندووی کوردی (ئەندرۆید)

دەنگی یاری/ڤیدیۆ لە ناو مۆبایلەکەوە دەگرێت (نەک لە مایکەوە)، بە Gemini Live وەریدەگێڕێت بۆ کوردی سۆرانی و دەیپەخشێت.

APK بە GitHub Actions دروست دەبێت (workflow ـی `.github/workflows/build.yml`).
دوای تەواوبوون: Actions → دوایین run → Artifacts → KurdishTranslator-APK.

پێداویستی: Android 10+، کلیلی Gemini API.

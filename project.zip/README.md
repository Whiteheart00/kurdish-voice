# وەرگێڕی زیندووی کوردی (ئەندرۆید)

ئەپەکە دەنگی مایکرۆفۆن یان دەنگی ناو مۆبایل دەگرێت و بۆ کوردی سۆرانی وەریدەگێڕێت. لە ڕێکخستنەکاندا دەتوانیت Gemini یان OpenAI Realtime هەڵبژێریت.

- Gemini: کلیلی API لە https://aistudio.google.com/
- OpenAI: کلیلی API لە https://platform.openai.com/api-keys و مۆدێلی `gpt-realtime`
- APK بە GitHub Actions دروست دەکرێت: Actions → دوایین run → Artifacts → KurdishTranslator-APK.
- پێویستی: Android 10+ و API key ـی بەردەوام/چالاک. بەکارهێنانی OpenAI API بە پێی نرخەکانی API هەژمار دەکرێت و لە ChatGPT Plus جیاوازە.

ئاگاداری پاراستن: دانانی API key لە ئەپی مۆبایل بۆ تاقیکردنەوە گونجاوە، بەڵام بۆ دابەشکردنی گشتی پێشنیار دەکرێت key لە backend ـێکی پارێزراوەوە بەکاربهێنرێت.

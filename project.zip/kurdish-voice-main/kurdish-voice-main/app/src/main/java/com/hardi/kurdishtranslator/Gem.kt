package com.hardi.kurdishtranslator

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Base64
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

/** Text translation (Gemini REST) + Kurdish speech made OFFLINE by KuVoice (24 kHz mono PCM16). */
object Gem {
    // "-latest" aliases always point to the current model, so they do not get retired like gemini-2.5-flash did.
    private val TEXT_MODELS = listOf("gemini-3.5-flash-lite", "gemini-3.1-flash-lite", "gemini-3.8-flash", "gemini-flash-lite-latest", "gemini-flash-latest")
    @Volatile private var textModel = 0

    private val http = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private fun post(model: String, body: JSONObject, role: Int): JSONObject {
        val tries = maxOf(1, Bus.keys.size)
        var last: Exception? = null
        repeat(tries) {
            val k = Bus.keyFor(role)
            try {
                val req = Request.Builder()
                    .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                    .header("x-goog-api-key", k)
                    .post(body.toString().toRequestBody("application/json".toMediaType()))
                    .build()
                http.newCall(req).execute().use { r ->
                    val t = r.body?.string() ?: ""
                    if (!r.isSuccessful) {
                        // quota / overload / bad key -> rest this key and let the next one try
                        if (r.code == 429) Bus.cooldown(k, 30_000L)
                        else if (r.code == 400 || r.code == 401 || r.code == 403) Bus.cooldown(k, 10 * 60_000L)
                        else if (r.code >= 500) Bus.cooldown(k, 5_000L)
                        throw RuntimeException("HTTP " + r.code + ": " + t.take(120))
                    }
                    return JSONObject(t)
                }
            } catch (e: Exception) {
                last = e
            }
        }
        throw last ?: RuntimeException("هەڵە")
    }

    /** Runs one generateContent request, trying the text models in turn (busy / retired models are skipped). */
    private fun generate(body: JSONObject): JSONObject {
        var res: JSONObject? = null
        var last: Exception? = null
        var round = 0
        search@ while (round < 2) {
            var transient = false
            for (i in textModel until TEXT_MODELS.size) {
                try {
                    res = post(TEXT_MODELS[i], body, Bus.TEXT)
                    textModel = i
                    break@search
                } catch (e: Exception) {
                    last = e
                    val m = e.message ?: ""
                    when {
                        // 404 = this model is gone / not allowed for this key: never try it again
                        m.contains("HTTP 404") -> if (i == textModel) textModel = minOf(i + 1, TEXT_MODELS.size - 1)
                        // 503 / 500 / 429 / timeout = Google is busy for a moment: try the next model now,
                        // and the whole list again after a short pause
                        m.contains("HTTP 503") || m.contains("HTTP 500") || m.contains("HTTP 429") ||
                            m.contains("high demand") || e is java.io.IOException -> transient = true
                        else -> throw e
                    }
                }
            }
            if (!transient) break
            round++
            try { Thread.sleep(700L * round) } catch (_: InterruptedException) { break }
        }
        if (res == null) throw last ?: RuntimeException("مۆدێلی وەرگێڕان نەدۆزرایەوە")
        return res
    }

    private fun firstText(res: JSONObject): String =
        res.getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
            .getJSONArray("parts").getJSONObject(0).getString("text")

    fun translate(lines: List<String>): List<String> {
        val prompt = "Translate each English line below into natural, spoken Sorani Kurdish (کوردی سۆرانی, Arabic script). " +
            "They are consecutive lines of a video game's dialogue, in story order, so use the neighbouring lines as context. " +
            "Use colloquial gamer Sorani and keep each line short and punchy, keeping its emotion (shouts, commands, whispers). " +
            "Write character and place names as consistent Kurdish-script transliterations. No explanations. " +
            "The text will be read aloud by a Kurdish voice, so: write every number as Kurdish words (never digits), " +
            "use only Kurdish letters (no Latin letters, emojis, brackets or symbols), use the Kurdish punctuation ، ؟ ! . " +
            "to mark natural pauses, and prefer short, simple sentences that are easy to understand when heard once. " +
            "Return ONLY a JSON array of exactly " + lines.size + " strings, in the same order.\n" + JSONArray(lines).toString()
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        val arr = JSONArray(firstText(generate(body)))
        if (arr.length() != lines.size) throw RuntimeException("ژمارەی ڕستەکان یەک نەبوو")
        return List(arr.length()) { arr.getString(it).replace("\t", " ").replace("\n", " ").trim() }
    }

    /**
     * Kurdish speech (WAV, 16 kHz mono) -> (Kurdish text, English translation), or null when there is no clear Kurdish speech.
     * Needs the internet (Gemini listens to the audio).
     */
    fun kuToEn(wav: ByteArray): Pair<String, String>? {
        val prompt = "The audio is Sorani Kurdish speech (کوردی سۆرانی) from a person, game or video, possibly with background music or effects. " +
            "Transcribe exactly what is said in Kurdish (Arabic script) and translate it into natural, short, spoken English. " +
            "If there is no clear human Kurdish speech (only music, effects, noise, silence, or another language), return empty strings. Never invent anything that was not said. " +
            "Return ONLY JSON like {\"ku\":\"...\",\"en\":\"...\"}."
        val parts = JSONArray()
            .put(JSONObject().put("text", prompt))
            .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "audio/wav").put("data", Base64.encodeToString(wav, Base64.NO_WRAP))))
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", parts)))
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        val o = JSONObject(firstText(generate(body)))
        val ku = o.optString("ku", "").trim()
        val en = o.optString("en", "").trim()
        return if (en.length < 2) null else Pair(ku, en)
    }

    /** Kurdish text -> speech, fully offline (Piper/ONNX model imported by the user). No AI, no internet. */
    fun tts(filesDir: File, text: String, speed: Float): ByteArray = KuVoice.synth(filesDir, text, speed)

    private fun key(s: String): String =
        MessageDigest.getInstance("MD5").digest(("piper2|" + String.format(java.util.Locale.US, "%.2f", Bus.speed) + "|" + s).toByteArray()).joinToString("") { "%02x".format(it) }

    fun cached(dir: File, ku: String): Boolean = File(File(dir, "tts"), key(ku) + ".pcm").exists()

    /** Audio for a Kurdish line: from the disk cache, otherwise generated and cached. */
    fun pcmFor(dir: File, ku: String): ByteArray {
        val d = File(dir, "tts")
        d.mkdirs()
        val f = File(d, key(ku) + ".pcm")
        if (f.exists()) return f.readBytes()
        val b = tts(dir, ku, Bus.speed)
        val tmp = File(d, key(ku) + "." + Thread.currentThread().id + ".tmp")
        tmp.writeBytes(b)
        if (!tmp.renameTo(f)) tmp.delete()
        return b
    }

    fun playOnce(pcm: ByteArray) {
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(Bus.outUsage)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(24000)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(pcm.size)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        t.write(pcm, 0, pcm.size)
        t.play()
        Thread.sleep(pcm.size / 48L + 400)
        t.release()
    }

    @Volatile private var manual: AudioTrack? = null

    /** Plays one sentence when the user taps its ▶ button. It has its own player, so the automatic reading is not touched. */
    fun playManual(pcm: ByteArray) {
        stopManual()
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(Bus.outUsage)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(24000)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(pcm.size)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        manual = t
        try {
            t.write(pcm, 0, pcm.size)
            t.play()
            val end = System.currentTimeMillis() + pcm.size / 48L + 300
            while (manual === t && System.currentTimeMillis() < end) Thread.sleep(40)
        } finally {
            if (manual === t) manual = null
            try { t.stop() } catch (_: Exception) {}
            t.release()
        }
    }

    /** Tapping another ▶ stops the sentence that is still playing from a previous tap. */
    fun stopManual() {
        val t = manual
        manual = null
        try { t?.stop() } catch (_: Exception) {}
    }
}
